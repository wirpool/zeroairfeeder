/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "feeder_config.h"
#include "fr24_status.h"
#include "signup_script.h"
#include "supervised_process.h"

#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <vector>

namespace feeder {

// Where FeederSystem finds its programs. The device defaults are the
// installed paths; mock mode (desktop simulator, or ZEROFEED24_MOCK=1) uses
// stand-ins from the mock directory and a scratch state directory.
struct SystemPaths {
    bool mock = false;
    std::string ctl;          // zerofeed24-ctl (downloads fr24feed, as the user)
    std::string fr24_dir;     // where it puts fr24feed: ~/.local/share/zerofeed24/fr24feed
    std::string fr24feed;     // FR24's fr24feed binary, in fr24_dir
    std::string fr24_version; // file with its version, written by the helper
    std::string readsb;       // the bundled readsb
    std::string runtime_dir;  // per-user, private: ini, monitor file, aircraft.json
    std::string legacy_ini;   // /etc/fr24feed.ini of an earlier fr24feed install (key import)

    static SystemPaths from_env(const std::string& install_dir, const std::string& mock_dir,
                                bool default_mock);
};

// What the feeder looks like right now (polled every second).
struct SystemState {
    bool fr24_installed = false;
    std::string fr24_version;
    bool installing = false;       // the install job is running

    bool feeding = false;          // started by the user, until stopped or the app closes
    bool readsb_running = false;
    bool fr24_running = false;
    int readsb_restarts = 0;
    int fr24_restarts = 0;
    std::string readsb_error;      // its last line before it last exited
    std::string fr24_error;

    Fr24Status fr24;               // fr24feed's monitor file
    bool fr24_fresh = false;       // ... rewritten in the last 30 s by a running fr24feed
    AircraftSummary aircraft;      // readsb's aircraft.json
    std::string legacy_key;        // a key found in /etc/fr24feed.ini, "" if none
};

// A finished job (install, signup), for the UI.
struct JobResult {
    std::string name;
    bool ok = false;
    std::string message;      // the last meaningful line, or the error
    std::string output;       // everything it printed
    std::string sharing_key;  // signup: the new key
};

// Runs the feeder for the app: readsb and fr24feed as child processes while
// feeding is on, never longer than the app itself (they stop with stop_feeding(),
// with the destructor, and through PR_SET_PDEATHSIG if the app dies). Also polls
// their status and runs the two jobs, the fr24feed download (zerofeed24-ctl,
// as the user, into the user's data directory) and the signup wizard. All methods are
// thread-safe; none blocks for long.
class FeederSystem {
public:
    explicit FeederSystem(SystemPaths paths);
    ~FeederSystem();
    FeederSystem(const FeederSystem&) = delete;
    FeederSystem& operator=(const FeederSystem&) = delete;

    SystemState state() const;

    // Writes fr24feed.ini in the runtime directory and starts both programs.
    // "" on success, else why not (the UI shows it).
    std::string start_feeding(const FeederConfig& cfg);
    void stop_feeding();

    // The programs' last output lines, oldest first.
    std::string log_text() const;

    bool submit_install();
    bool submit_signup(SignupAnswers answers);
    void cancel_job();
    bool busy() const;
    std::string busy_name() const;
    std::string live_output() const;
    std::optional<JobResult> take_result();

    // The helper's command line for the fr24feed download.
    std::vector<std::string> install_command() const;

    const SystemPaths& paths() const { return paths_; }

private:
    struct Job {
        std::string name;
        std::optional<SignupAnswers> signup;
    };

    void poll_loop();
    void poll_once();
    void job_loop();
    JobResult run_job(const Job& job);
    bool submit(Job job);
    std::string read_version() const;

    SystemPaths paths_;
    SupervisedProcess readsb_{"readsb"};
    SupervisedProcess fr24feed_{"fr24feed"};
    std::atomic<bool> feeding_{false};

    mutable std::mutex mutex_;
    std::condition_variable cv_;
    SystemState state_;
    std::optional<Job> pending_;
    std::string busy_name_;
    std::string live_;
    std::deque<JobResult> results_;
    std::atomic<bool> cancel_{false};
    std::atomic<bool> running_{true};
    std::thread poll_thread_;
    std::thread job_thread_;
};

// The last line worth showing from a helper's output: an "ERROR: ..." line,
// sudo's own complaint, else the last non-empty line.
std::string summarize_output(const std::string& output);

// The per-user runtime directory: $XDG_RUNTIME_DIR/zerofeed24, else
// /tmp/zerofeed24-<uid>; created 0700.
std::string runtime_dir();

// The per-user data directory: $XDG_DATA_HOME/zerofeed24, else
// ~/.local/share/zerofeed24 (/tmp/zerofeed24-data-<uid> without HOME).
std::string data_dir();

// Kills a leftover of ours: the process in `pid_file`, only if it still runs
// `exe` (checked through /proc/<pid>/exe). For a crash that skipped cleanup.
void kill_stale(const std::string& pid_file, const std::string& exe);

} // namespace feeder
