#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# Stand-in for `fr24feed --signup --adsb --config-file=<file>` in the tests and
# the desktop simulator.
# It prints the prompts of fr24feed 1.0.57's ADS-B signup wizard (texts taken
# from the binary) and reads the answers from the terminal, as fr24feed does.
#
#   MOCK_EXPECT_EMAIL / _LAT / _LON / _ALT / _MLAT  answers it insists on (optional)
#   MOCK_MODE=ok        (default) accept and print a sharing key
#   MOCK_MODE=reject    the server refuses the location, "try again?"
#   MOCK_MODE=password  ends with a password prompt after saving (systemctl)
#   MOCK_MODE=nomarker  prompts without the "$:" input marker (idle path)
#   MOCK_MODE=bademail  keeps rejecting the e-mail address
#   MOCK_DELAY=<s>      pause between steps (simulator demo)
set -u

cfg=""
for a in "$@"; do case "$a" in --config-file=*) cfg="${a#--config-file=}" ;; esac; done
mode="${MOCK_MODE:-ok}"
delay="${MOCK_DELAY:-0}"
tty_in=/dev/tty
[ -r "$tty_in" ] || tty_in=/dev/stdin

marker() { if [ "$mode" = nomarker ]; then printf '\n'; else printf '\n$:'; fi; }
ask() { # prompt-text -> reply in $REPLY
    printf '%s' "$1"
    marker
    IFS= read -r REPLY < "$tty_in" || { echo "MOCK: no input"; exit 4; }
    sleep "$delay"
}
expect() { # what got expected
    if [ -n "$2" ] && [ "$1" != "$2" ]; then
        echo "MOCK MISMATCH: got '$1' expected '$2'"
        exit 3
    fi
}

echo "Welcome to the FR24 Decoder/Feeder sign up wizard!"
echo "Before you continue please make sure that:"
echo " 1 - Your ADS-B receiver is connected to this computer or is accessible over network"
echo "To terminate - press Ctrl+C at any point"
echo

while :; do
    ask "Step 1.1 - Enter your email address (username@domain.tld)"
    if [ "$mode" = bademail ]; then echo "Invalid email $REPLY provided, please try again"; continue; fi
    break
done
expect "$REPLY" "${MOCK_EXPECT_EMAIL:-}"

echo "Step 1.2 - If you used to feed FR24 with ADS-B data before, enter your sharing key."
echo "If you don't remember your sharing key, "
echo "you can find it in your account on the website under \"My data sharing\"."
echo "https://www.flightradar24.com/account/data-sharing"
ask "Enter your sharing key or press ENTER/RETURN to continue."
expect "x$REPLY" "x"

printf 'Step 1.3 - Would you like to participate in MLAT calculations? (yes/no)$:'
IFS= read -r REPLY < "$tty_in"
expect "$REPLY" "${MOCK_EXPECT_MLAT:-}"

echo "IMPORTANT: For MLAT calculations the antenna's location should be entered very precise!"
ask "Step 3.A - Enter antenna's latitude (DD.DDDD)"
expect "$REPLY" "${MOCK_EXPECT_LAT:-}"
lat="$REPLY"
ask "Step 3.B - Enter antenna's longitude (DDD.DDDD)"
expect "$REPLY" "${MOCK_EXPECT_LON:-}"
lon="$REPLY"
ask "Step 3.C - Enter antenna's altitude above the sea level (in feet)"
expect "$REPLY" "${MOCK_EXPECT_ALT:-}"
alt="$REPLY"
echo "Using latitude: $lat, longitude:$lon, altitude: ${alt}ft above sea level"
echo "Validating email/location information..."
sleep "$delay"

if [ "$mode" = reject ]; then
    echo "ERROR"
    echo "Your location is not allowed."
    printf 'Would you like to try again? (yes/no)$:'
    IFS= read -r REPLY < "$tty_in"
    exit 1
fi

echo "The closest airport found is ICAO:LIML IATA:LIN near Milan."
echo "Latitude: $lat"
echo "Longitude: $lon"
echo "Would you like to continue using these settings?"
printf 'Enter your choice (yes/no)$:'
IFS= read -r REPLY < "$tty_in"
expect "$REPLY" "yes"

echo " (in order to run MLAT please use DVB-T stick with dump1090 utility bundled with fr24feed)"
echo "Step 4.1 - Receiver selection:"
echo " 1 - DVBT Stick (USB)"
echo " -----------------------------------------------------"
echo " 4 - ModeS Beast (USB/Network)"
printf 'Enter your receiver type (1-6)$:'
IFS= read -r REPLY < "$tty_in"; expect "$REPLY" "4"
echo "Step 4.2 - Please select connection type:"
echo " 1 - Network connection"
echo " 2 - USB directly to this computer"
printf 'Enter your connection type (1-2)$:'
IFS= read -r REPLY < "$tty_in"; expect "$REPLY" "1"
ask "Step 4.3A - Please enter your receiver's IP address/hostname"
expect "$REPLY" "127.0.0.1"
ask "Step 4.3B - Please enter your receiver's data port number"
expect "$REPLY" "30005"
printf 'Step 5.1 - Would you like to enable RAW data feed on port 30334 (yes/*no*)$:'
IFS= read -r REPLY < "$tty_in"; expect "$REPLY" "no"
printf 'Step 5.2 - Would you like to enable Basestation data feed on port 30003 (yes/no)$:'
IFS= read -r REPLY < "$tty_in"; expect "$REPLY" "no"
echo "Submitting form data..."
sleep "$delay"
echo "Congratulations! You are now registered and ready to share ADS-B data with Flightradar24."
echo "+ Your sharing key (0a1b2c3d4e5f6a7b) has been configured and emailed to you for backup purposes."
echo "Saving settings to $cfg...OK"
if [ -n "$cfg" ]; then
    printf 'receiver="beast-tcp"\nfr24key="0a1b2c3d4e5f6a7b"\nhost="127.0.0.1:30005"\n' > "$cfg"
fi
# Like fr24feed: try to enable its service (the app puts a stand-in first in PATH).
systemctl enable fr24feed >/dev/null 2>&1 || echo "Failed to enable fr24feed service!"
if [ "$mode" = password ]; then
    printf '==== AUTHENTICATING FOR org.freedesktop.systemd1.manage-unit-files ====\nPassword: '
    IFS= read -r REPLY < "$tty_in"
fi
exit 0
