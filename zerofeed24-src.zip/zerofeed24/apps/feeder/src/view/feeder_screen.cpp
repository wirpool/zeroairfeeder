/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_screen.h"

#include "asset_manager.h"
#include "bindings.h"
#include "docs.h"
#include "feeder_config.h"
#include "i18n.h"
#include "linux_input.h"
#include "theme.h"

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>

namespace feeder::view {
namespace {

using T = toolkit::i18n::Text;
const char* tr(const T& t) { return toolkit::i18n::pick(t); }

constexpr int32_t kHeaderHeight = 18;
constexpr uint32_t kTickMs = 300;
constexpr size_t kMaxValueChars = 26;

// Cut a value that would wrap its table row ("…" at the end), on a UTF-8
// character boundary.
std::string fit(const std::string& s, size_t max_chars) {
    size_t chars = 0, i = 0;
    while (i < s.size()) {
        const auto c = static_cast<unsigned char>(s[i]);
        const size_t len = c < 0x80 ? 1 : (c >> 5) == 0x6 ? 2 : (c >> 4) == 0xe ? 3 : 4;
        if (chars == max_chars) return s.substr(0, i) + "\xE2\x80\xA6";
        i += len;
        ++chars;
    }
    return s;
}

void set_cell(lv_obj_t* table, uint32_t row, uint32_t col, const std::string& text) {
    const char* cur = lv_table_get_cell_value(table, row, col);
    if (!cur || std::strcmp(cur, text.c_str()) != 0) lv_table_set_cell_value(table, row, col, text.c_str());
}

std::string about_text() {
    std::string text = tr({
        "# ZeroFeed24\n"
        "Shares the aircraft your RTL-SDR dongle receives with Flightradar24, "
        "using FR24's official fr24feed and the readsb decoder.\n\n"
        "readsb and fr24feed run only while the app is open and feeding is on.\n\n"
        "Version " APP_VERSION ". MIT licence. Built on the ZeroRadio toolkit by "
        "Andrea Salvatore (IU4APC).\n",
        "# ZeroFeed24\n"
        "Condivide con Flightradar24 gli aerei ricevuti dalla chiavetta RTL-SDR, "
        "con il programma ufficiale fr24feed di FR24 e il decoder readsb.\n\n"
        "readsb e fr24feed girano solo ad app aperta e con l'invio acceso.\n\n"
        "Versione " APP_VERSION ". Licenza MIT. Basato sul toolkit di ZeroRadio di "
        "Andrea Salvatore (IU4APC).\n"});
    const std::string credits = toolkit::read_doc("CREDITS.md");
    if (!credits.empty()) text += "\n" + credits;
    return text;
}

} // namespace

FeederScreen::FeederScreen(FeederViewModel& vm, app::AssetManager& assets)
    : screen::BaseScreen(vm, vm, assets), vm_(vm) {
    init();
}

FeederScreen::~FeederScreen() {
    if (timer_) lv_timer_delete(timer_);
}

lv_obj_t* FeederScreen::make_table(lv_obj_t* parent, int32_t name_w, int32_t value_w,
                                   bool highlight) {
    auto* table = lv_table_create(parent);
    reactive::bind_theme(table, vm_.dark_mode_subject(), reactive::ThemeRole::Table);
    lv_obj_set_width(table, LV_PCT(100));
    lv_table_set_column_count(table, 2);
    lv_table_set_column_width(table, 0, name_w);
    lv_table_set_column_width(table, 1, value_w);
    lv_obj_set_style_pad_ver(table, 1, LV_PART_ITEMS);
    lv_obj_set_style_pad_hor(table, 5, LV_PART_ITEMS);
    lv_obj_set_style_border_width(table, 0, 0);
    if (font_semi_) lv_obj_set_style_text_font(table, font_semi_, LV_PART_ITEMS);
    lv_obj_remove_flag(table, LV_OBJ_FLAG_CLICKABLE);
    if (highlight) {
        lv_obj_add_event_cb(table, table_draw_cb, LV_EVENT_DRAW_TASK_ADDED, this);
        lv_obj_add_flag(table, LV_OBJ_FLAG_SEND_DRAW_TASK_EVENTS);
    }
    return table;
}

void FeederScreen::build_content(lv_obj_t* content) {
    lv_obj_set_flex_flow(content, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_all(content, 0, 0);
    lv_obj_set_style_pad_row(content, 0, 0);

    font_ = assets().load_font("inter-regular.ttf", 12);
    font_semi_ = assets().load_font("inter-semibold.ttf", 12);
    font_bold_ = assets().load_font("inter-bold.ttf", 14);
    const lv_font_t* fallback = &lv_font_montserrat_12;

    // --- header ---
    auto* header = lv_obj_create(content);
    lv_obj_remove_style_all(header);
    lv_obj_set_size(header, LV_PCT(100), kHeaderHeight);
    lv_obj_clear_flag(header, LV_OBJ_FLAG_SCROLLABLE);

    header_page_ = lv_label_create(header);
    lv_obj_set_style_text_font(header_page_, font_ ? font_ : fallback, 0);
    reactive::bind_theme(header_page_, vm_.dark_mode_subject(), reactive::ThemeRole::Text);
    lv_obj_align(header_page_, LV_ALIGN_LEFT_MID, 4, 0);
    lv_label_set_text(header_page_, "");

    header_title_ = lv_label_create(header);
    lv_obj_set_style_text_font(header_title_, font_semi_ ? font_semi_ : fallback, 0);
    reactive::bind_theme(header_title_, vm_.dark_mode_subject(), reactive::ThemeRole::Text);
    lv_label_set_text(header_title_, "ZeroFeed24");
    lv_obj_align(header_title_, LV_ALIGN_CENTER, 0, 0);

    dot_ = lv_obj_create(header);
    lv_obj_remove_style_all(dot_);
    lv_obj_set_size(dot_, 8, 8);
    lv_obj_set_style_radius(dot_, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_bg_opa(dot_, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_color(dot_, lv_color_hex(0x888888), 0);
    lv_obj_align(dot_, LV_ALIGN_RIGHT_MID, -6, 0);

    battery_ = std::make_unique<::view::widgets::BatteryBadge>(header);
    lv_obj_align(battery_->obj(), LV_ALIGN_RIGHT_MID, -20, 0);

    // --- body ---
    auto* body = lv_obj_create(content);
    lv_obj_remove_style_all(body);
    lv_obj_set_width(body, LV_PCT(100));
    lv_obj_set_flex_grow(body, 1);
    lv_obj_clear_flag(body, LV_OBJ_FLAG_SCROLLABLE);

    status_view_ = lv_obj_create(body);
    lv_obj_remove_style_all(status_view_);
    lv_obj_set_size(status_view_, LV_PCT(100), LV_PCT(100));
    lv_obj_clear_flag(status_view_, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(status_view_, LV_FLEX_FLOW_COLUMN);

    headline_ = lv_label_create(status_view_);
    lv_obj_set_width(headline_, LV_PCT(100));
    lv_label_set_long_mode(headline_, LV_LABEL_LONG_DOT);
    lv_obj_set_style_text_font(headline_, font_bold_ ? font_bold_ : fallback, 0);
    lv_obj_set_style_pad_hor(headline_, 6, 0);
    lv_obj_set_style_pad_ver(headline_, 1, 0);
    lv_label_set_text(headline_, "");

    status_table_ = make_table(status_view_, 104, 216, /*highlight=*/false);
    lv_obj_set_flex_grow(status_table_, 1);
    lv_table_set_row_count(status_table_, FeederViewModel::kStatusRows);

    account_table_ = make_table(body, 150, 170, /*highlight=*/true);
    lv_obj_set_height(account_table_, LV_PCT(100));
    lv_table_set_row_count(account_table_, static_cast<uint32_t>(FeederViewModel::AccountRow::Count));

    setup_table_ = make_table(body, 150, 170, /*highlight=*/true);
    lv_obj_set_height(setup_table_, LV_PCT(100));
    lv_table_set_row_count(setup_table_, static_cast<uint32_t>(FeederViewModel::SetupRow::Count));

    vm_.report_input(platform::keypad_search_ran(), platform::keypad_count(), platform::input_report());
    vm_.tick();
    show_view(vm_.page());
    update_header();
    update_status();
    timer_ = lv_timer_create(tick_cb, kTickMs, this);
}

void FeederScreen::tick_cb(lv_timer_t* timer) {
    if (auto* self = static_cast<FeederScreen*>(lv_timer_get_user_data(timer))) self->tick();
}

lv_color_t FeederScreen::tone_color(FeederViewModel::Tone tone) const {
    const bool dark = vm_.is_dark_mode();
    switch (tone) {
        case FeederViewModel::Tone::Good: return ::view::readable(0x63e2b7, dark);
        case FeederViewModel::Tone::Warn: return ::view::readable(0xf2c97d, dark);
        case FeederViewModel::Tone::Bad: return ::view::readable(0xff6b6b, dark);
        case FeederViewModel::Tone::Neutral: break;
    }
    return ::view::palette(dark).text;
}

void FeederScreen::tick() {
    graveyard_.clear();
    vm_.tick();

    const auto req = vm_.take_request();
    if (req != FeederViewModel::Request::None) queued_.push_back(req);
    if (!dialog_open() && !queued_.empty()) {
        const auto next = queued_.front();
        queued_.pop_front();
        open(next);
    }
    update_job_panel();

    show_view(vm_.page());
    update_header();
    switch (vm_.page()) {
        case FeederViewModel::Page::Status: update_status(); break;
        case FeederViewModel::Page::Account:
            update_list(account_table_, static_cast<int>(FeederViewModel::AccountRow::Count),
                        vm_.account_cursor(), &FeederViewModel::account_name,
                        &FeederViewModel::account_value);
            account_sel_ = vm_.account_cursor();
            break;
        case FeederViewModel::Page::Setup:
            update_list(setup_table_, static_cast<int>(FeederViewModel::SetupRow::Count),
                        vm_.setup_cursor(), &FeederViewModel::setup_name, &FeederViewModel::setup_value);
            setup_sel_ = vm_.setup_cursor();
            break;
    }
    // The START/STOP label follows the service state.
    if (vm_.sys().feeding != last_feeding_) {
        last_feeding_ = vm_.sys().feeding;
        vm_.bump_nav_refresh();
    }
}

void FeederScreen::show_view(FeederViewModel::Page page) {
    const auto set = [](lv_obj_t* o, bool visible) {
        if (visible) lv_obj_remove_flag(o, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(o, LV_OBJ_FLAG_HIDDEN);
    };
    set(status_view_, page == FeederViewModel::Page::Status);
    set(account_table_, page == FeederViewModel::Page::Account);
    set(setup_table_, page == FeederViewModel::Page::Setup);
}

void FeederScreen::update_header() {
    const char* name = vm_.nav_page_name(static_cast<int>(vm_.page()));
    lv_label_set_text(header_page_, name ? name : "");
    const auto& s = vm_.sys();
    uint32_t color = 0x888888;                    // off
    if (s.feeding) {
        if (s.fr24_fresh && s.fr24.connected() && s.readsb_running) color = 0x63e2b7;
        else if (s.readsb_running && s.fr24_running) color = 0xf2c97d; // starting / reconnecting
        else color = 0xff6b6b;                    // a program keeps stopping
    }
    lv_obj_set_style_bg_color(dot_, lv_color_hex(color), 0);
}

void FeederScreen::update_status() {
    FeederViewModel::Tone tone = FeederViewModel::Tone::Neutral;
    const std::string head = vm_.headline(tone);
    if (std::strcmp(lv_label_get_text(headline_), head.c_str()) != 0)
        lv_label_set_text(headline_, head.c_str());
    lv_obj_set_style_text_color(headline_, tone_color(tone), 0);
    for (int r = 0; r < FeederViewModel::kStatusRows; ++r) {
        set_cell(status_table_, static_cast<uint32_t>(r), 0, vm_.status_name(r));
        set_cell(status_table_, static_cast<uint32_t>(r), 1, fit(vm_.status_value(r), 40));
    }
}

void FeederScreen::update_list(lv_obj_t* table, int rows, int cursor,
                               std::string (FeederViewModel::*name)(int) const,
                               std::string (FeederViewModel::*value)(int) const) {
    for (int r = 0; r < rows; ++r) {
        set_cell(table, static_cast<uint32_t>(r), 0, (vm_.*name)(r));
        set_cell(table, static_cast<uint32_t>(r), 1, fit((vm_.*value)(r), kMaxValueChars));
    }
    // Redraw when only the cursor moved (the highlight comes from the draw hook).
    const int idx = table == account_table_ ? 0 : 1;
    if (last_cursor_[idx] != cursor) {
        last_cursor_[idx] = cursor;
        lv_obj_invalidate(table);
    }
}

void FeederScreen::table_draw_cb(lv_event_t* event) {
    auto* self = static_cast<FeederScreen*>(lv_event_get_user_data(event));
    auto* task = lv_event_get_draw_task(event);
    if (!self || !task) return;
    auto* base = static_cast<lv_draw_dsc_base_t*>(lv_draw_task_get_draw_dsc(task));
    if (!base) return;
    auto* target = static_cast<lv_obj_t*>(lv_event_get_current_target(event));
    const int sel = target == self->account_table_ ? self->account_sel_ : self->setup_sel_;
    const bool is_sel = static_cast<int>(base->id1) == sel;
    const lv_draw_task_type_t type = lv_draw_task_get_type(task);
    if (type == LV_DRAW_TASK_TYPE_FILL && is_sel && base->part == LV_PART_ITEMS) {
        auto* fd = static_cast<lv_draw_fill_dsc_t*>(lv_draw_task_get_draw_dsc(task));
        fd->color = ::view::palette(false).primary;
        fd->opa = LV_OPA_COVER;
    } else if (type == LV_DRAW_TASK_TYPE_LABEL && is_sel) {
        auto* ld = static_cast<lv_draw_label_dsc_t*>(lv_draw_task_get_draw_dsc(task));
        ld->color = lv_color_black();
    }
}

// --- dialogs ----------------------------------------------------------------

bool FeederScreen::dialog_open() const {
    return (text_dialog_ && text_dialog_->is_open()) ||
           (location_dialog_ && location_dialog_->is_open()) || (panel_ && panel_->is_open()) ||
           (viewer_ && viewer_->is_open());
}

void FeederScreen::open(FeederViewModel::Request request) {
    using R = FeederViewModel::Request;
    const bool dark = vm_.is_dark_mode();
    const auto& cfg = vm_.config();
    bury(text_dialog_);
    bury(location_dialog_);
    bury(viewer_);
    if (request != R::JobPanel) bury(panel_);

    switch (request) {
        case R::EditKey: {
            TextEntryDialog::Options o;
            o.title = tr({"Sharing key (16 letters or digits)", "Chiave di condivisione (16 caratteri)"});
            o.initial = cfg.sharing_key;
            o.hint = tr({"flightradar24.com > Account > Data sharing.  Enter OK  Esc cancel",
                         "flightradar24.com > Account > Condivisione dati.  Invio OK  Esc annulla"});
            o.max_len = 24;
            o.accept = [](char c) {
                return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                       c == '-' || c == ' ';
            };
            o.validate = [](const std::string& text) -> std::string {
                const std::string key = normalize_key(text);
                if (valid_sharing_key(key)) return {};
                char buf[96];
                std::snprintf(buf, sizeof(buf),
                              tr({"A sharing key has 16 letters or digits (this one: %zu)",
                                  "La chiave ha 16 lettere o cifre (questa: %zu)"}),
                              key.size());
                return buf;
            };
            text_dialog_ = std::make_unique<TextEntryDialog>(
                assets(), dark, std::move(o), [this](const std::string& v) { vm_.set_key(v); });
            break;
        }
        case R::EditEmail: {
            TextEntryDialog::Options o;
            o.title = tr({"FR24 account e-mail", "E-mail dell'account FR24"});
            o.initial = cfg.email;
            o.hint = tr({"Tab types @   Enter OK   Esc cancel", "Tab scrive @   Invio OK   Esc annulla"});
            o.max_len = 80;
            o.tab_types_at = true;
            o.accept = [](char c) { return c > 0x20 && c < 0x7f; };
            o.validate = [](const std::string& text) -> std::string {
                return valid_email(text) ? std::string{}
                                         : tr({"Not an e-mail address", "Indirizzo e-mail non valido"});
            };
            text_dialog_ = std::make_unique<TextEntryDialog>(
                assets(), dark, std::move(o), [this](const std::string& v) { vm_.set_email(v); });
            break;
        }
        case R::EditAltitude: {
            TextEntryDialog::Options o;
            o.title = tr({"Antenna altitude, metres above sea level",
                          "Altitudine dell'antenna, metri sul livello del mare"});
            if (cfg.has_altitude)
                o.initial = std::to_string(static_cast<int>(std::lround(feet_to_metres(cfg.altitude_ft))));
            o.hint = tr({"Ground altitude + antenna height.  Enter OK  Esc cancel",
                         "Quota del terreno + altezza antenna.  Invio OK  Esc annulla"});
            o.max_len = 5;
            o.accept = [](char c) { return (c >= '0' && c <= '9') || c == '-'; };
            o.validate = [](const std::string& text) -> std::string {
                char* end = nullptr;
                const long m = std::strtol(text.c_str(), &end, 10);
                if (text.empty() || *end != '\0' || !valid_altitude_ft(metres_to_feet(static_cast<double>(m))))
                    return tr({"Metres, e.g. 120 (-450 to 9000)", "Metri, es. 120 (da -450 a 9000)"});
                return {};
            };
            text_dialog_ = std::make_unique<TextEntryDialog>(
                assets(), dark, std::move(o),
                [this](const std::string& v) { vm_.set_altitude_m(std::atoi(v.c_str())); });
            break;
        }
        case R::EditLocation:
            location_dialog_ = std::make_unique<toolkit::LocationDialog>(
                assets(), dark, [this](const toolkit::location::Place& p) { vm_.set_location(p); });
            break;
        case R::ConfirmSignup: {
            char body[512];
            std::snprintf(body, sizeof(body),
                          tr({"Flightradar24's own wizard registers a new feeder for\n%s\nat %.4f, %.4f, "
                              "%d ft, MLAT %s.\nThe sharing key appears here and FR24 e-mails it to "
                              "you. Needs internet.",
                              "Il wizard ufficiale di Flightradar24 registra un nuovo feeder per\n%s\na "
                              "%.4f, %.4f, %d ft, MLAT %s.\nLa chiave compare qui e FR24 te la invia per "
                              "e-mail. Serve internet."}),
                          cfg.email.c_str(), cfg.lat, cfg.lon, cfg.altitude_ft, cfg.mlat ? "on" : "off");
            open_panel(PanelKind::ConfirmSignup, tr({"Sign up with Flightradar24?", "Registrarsi su Flightradar24?"}),
                       body, tr({"Enter: sign up    Esc: cancel", "Invio: registrati    Esc: annulla"}));
            break;
        }
        case R::JobPanel:
            job_panel_hidden_ = false;
            bury(panel_);
            open_panel(PanelKind::Job, vm_.job_title(), vm_.job_body(), "");
            update_job_panel();
            break;
        case R::ShowError:
            open_panel(PanelKind::Error, vm_.error_title(), vm_.error_text(),
                       tr({"Enter/Esc: close", "Invio/Esc: chiudi"}));
            if (panel_) panel_->set_accent(tone_color(FeederViewModel::Tone::Bad));
            break;
        case R::ShowLog:
            viewer_ = std::make_unique<::view::widgets::TextViewer>(
                assets(), dark,
                std::vector<::view::widgets::TextViewer::Page>{
                    {"Log: readsb, fr24feed", vm_.log_text(), {}}});
            break;
        case R::ShowAbout:
            viewer_ = std::make_unique<::view::widgets::TextViewer>(
                assets(), dark,
                std::vector<::view::widgets::TextViewer::Page>{
                    {"About", about_text(), {}},
                    {"Changelog", toolkit::read_doc("CHANGELOG.md"), {}}});
            break;
        case R::None: break;
    }
}

void FeederScreen::open_panel(PanelKind kind, const std::string& title, const std::string& body,
                              const std::string& footer) {
    bury(panel_);
    panel_kind_ = kind;
    panel_ = std::make_unique<PanelDialog>(assets(), vm_.is_dark_mode(), title, body, footer,
                                           [this](uint32_t key) { on_panel_key(key); });
}

void FeederScreen::on_panel_key(uint32_t key) {
    if (!panel_) return;
    const bool enter = key == LV_KEY_ENTER;
    const bool esc = key == LV_KEY_ESC;
    switch (panel_kind_) {
        case PanelKind::ConfirmSignup:
            if (enter) {
                panel_->close();
                vm_.confirm_signup();
            } else if (esc) {
                panel_->close();
            }
            break;
        case PanelKind::Job:
            if (vm_.job_outcome()) {
                if (enter || esc) panel_->close();
            } else if (esc) {
                if (vm_.system_busy_name() == "signup") {
                    vm_.cancel_job();
                } else {
                    // apt cannot be interrupted safely: hide, keep going.
                    job_panel_hidden_ = true;
                    panel_->close();
                    vm_.show_status(tr({"Still installing in the background",
                                        "L'installazione continua in background"}));
                }
            }
            break;
        case PanelKind::Error:
            if (enter || esc) panel_->close();
            break;
        case PanelKind::None: break;
    }
}

void FeederScreen::update_job_panel() {
    if (panel_kind_ != PanelKind::Job || !panel_ || !panel_->is_open()) return;
    panel_->set_title(vm_.job_title());
    panel_->set_body(vm_.job_body());
    if (const auto outcome = vm_.job_outcome()) {
        panel_->set_accent(tone_color(*outcome ? FeederViewModel::Tone::Good : FeederViewModel::Tone::Bad));
        panel_->set_footer(tr({"Enter/Esc: close", "Invio/Esc: chiudi"}));
    } else {
        panel_->set_footer(vm_.system_busy_name() == "signup"
                               ? tr({"Working...   Esc: cancel", "In corso...   Esc: annulla"})
                               : tr({"Working...   Esc: hide", "In corso...   Esc: nascondi"}));
    }
}

} // namespace feeder::view
