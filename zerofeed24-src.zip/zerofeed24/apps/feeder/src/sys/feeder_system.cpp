/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_system.h"

#include "child_process.h"
#include "signup_runner.h"

#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

namespace feeder {
namespace {

namespace fs = std::filesystem;
constexpr auto kPollPeriod = std::chrono::seconds(1);
constexpr size_t kLiveLimit = 6000;

bool executable(const std::string& path) { return !path.empty() && ::access(path.c_str(), X_OK) == 0; }

// Seconds since the file was last written, or -1 if missing.
long long age_s(const std::string& path) {
    struct stat st {};
    if (::stat(path.c_str(), &st) != 0) return -1;
    return static_cast<long long>(std::time(nullptr)) - static_cast<long long>(st.st_mtime);
}

std::string mock_state_dir() {
    if (const char* s = std::getenv("ZEROFEED24_MOCK_STATE"); s && s[0] != '\0') return s;
    return "/tmp/zerofeed24-mock-" + std::to_string(::getuid());
}

std::string trim(const std::string& s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    return s.substr(a, s.find_last_not_of(" \t\r\n") - a + 1);
}

} // namespace

std::string runtime_dir() {
    std::string dir;
    if (const char* rt = std::getenv("XDG_RUNTIME_DIR"); rt && rt[0] != '\0') {
        dir = std::string(rt) + "/zerofeed24";
    } else {
        dir = "/tmp/zerofeed24-" + std::to_string(::getuid());
    }
    ::mkdir(dir.c_str(), 0700);
    return dir;
}

std::string data_dir() {
    if (const char* d = std::getenv("XDG_DATA_HOME"); d && d[0] != '\0') return std::string(d) + "/zerofeed24";
    if (const char* h = std::getenv("HOME"); h && h[0] != '\0') return std::string(h) + "/.local/share/zerofeed24";
    return "/tmp/zerofeed24-data-" + std::to_string(::getuid());
}

void kill_stale(const std::string& pid_file, const std::string& exe) {
    std::ifstream in(pid_file);
    long pid = 0;
    if (!(in >> pid) || pid <= 1) return;
    std::error_code ec;
    const auto target = fs::read_symlink("/proc/" + std::to_string(pid) + "/exe", ec);
    if (ec) return;
    const auto want = fs::weakly_canonical(exe, ec);
    if (ec || target != want) return;
    ::kill(static_cast<pid_t>(pid), SIGTERM);
}

SystemPaths SystemPaths::from_env(const std::string& install_dir, const std::string& mock_dir,
                                  bool default_mock) {
    SystemPaths p;
    p.mock = default_mock;
    if (const char* m = std::getenv("ZEROFEED24_MOCK"); m && m[0] != '\0') p.mock = std::string(m) != "0";
    p.runtime_dir = feeder::runtime_dir();
    if (p.mock) {
        const std::string state = mock_state_dir();
        ::mkdir(state.c_str(), 0700);
        p.ctl = mock_dir + "/mock-ctl.sh";
        p.fr24_dir = state + "/fr24feed";
        p.readsb = mock_dir + "/mock-readsb.sh";
        p.legacy_ini = state + "/etc-fr24feed.ini";
    } else {
        p.ctl = install_dir + "/bin/zerofeed24-ctl";
        p.fr24_dir = data_dir() + "/fr24feed";
        p.readsb = install_dir + "/bin/readsb";
        p.legacy_ini = "/etc/fr24feed.ini";
    }
    if (const char* c = std::getenv("ZEROFEED24_CTL"); c && c[0] != '\0') p.ctl = c;
    p.fr24feed = p.fr24_dir + "/fr24feed";
    p.fr24_version = p.fr24_dir + "/version";
    return p;
}

std::string summarize_output(const std::string& output) {
    std::istringstream in(output);
    std::string line, last, flagged;
    while (std::getline(in, line)) {
        const auto first = line.find_first_not_of(" \t");
        if (first == std::string::npos) continue;
        line = line.substr(first);
        last = line;
        if (line.rfind("ERROR", 0) == 0 || line.rfind("sudo:", 0) == 0 || line.rfind("E: ", 0) == 0 ||
            line.rfind("curl:", 0) == 0 || line.rfind("gpgv:", 0) == 0 || line.rfind("Failed", 0) == 0)
            flagged = line;
    }
    return flagged.empty() ? last : flagged;
}

FeederSystem::FeederSystem(SystemPaths paths) : paths_(std::move(paths)) {
    // A fr24feed of ours left over by a crash (it would hold port 8754).
    kill_stale(paths_.runtime_dir + "/fr24feed.pid", paths_.fr24feed);
    poll_once();
    poll_thread_ = std::thread([this] { poll_loop(); });
    job_thread_ = std::thread([this] { job_loop(); });
}

FeederSystem::~FeederSystem() {
    running_ = false;
    cancel_ = true;
    cv_.notify_all();
    if (poll_thread_.joinable()) poll_thread_.join();
    if (job_thread_.joinable()) job_thread_.join();
    stop_feeding(); // the feeder never outlives the app
}

SystemState FeederSystem::state() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return state_;
}

std::string FeederSystem::start_feeding(const FeederConfig& cfg) {
    if (!valid_sharing_key(cfg.sharing_key)) return "no sharing key";
    if (!executable(paths_.fr24feed)) return "fr24feed is not installed";
    if (!executable(paths_.readsb)) return "readsb is missing: " + paths_.readsb;

    stop_feeding();
    const std::string& rt = paths_.runtime_dir;
    const std::string json_dir = rt + "/readsb";
    ::mkdir(json_dir.c_str(), 0700);
    // Never show a previous session's numbers.
    ::unlink((rt + "/decoder.txt").c_str());
    ::unlink((json_dir + "/aircraft.json").c_str());

    const std::string ini = rt + "/fr24feed.ini";
    {
        std::ofstream out(ini, std::ios::trunc);
        out << render_fr24feed_ini(cfg, rt);
        out.flush();
        if (!out) return "cannot write " + ini;
    }
    ::chmod(ini.c_str(), 0600); // it holds the sharing key

    std::vector<std::string> readsb = {paths_.readsb};
    const auto args = readsb_args(cfg, json_dir);
    readsb.insert(readsb.end(), args.begin(), args.end());
    readsb_.start(readsb);
    // fr24feed must be able to tell the time is UTC-correct: it complains about
    // a TZ other than GMT (see the sdr-enthusiasts container).
    fr24feed_.start({paths_.fr24feed, "--config-file=" + ini}, {{"TZ", "GMT"}});
    feeding_ = true;
    poll_once();
    return {};
}

void FeederSystem::stop_feeding() {
    feeding_ = false;
    fr24feed_.stop();
    readsb_.stop();
    if (running_) poll_once();
}

std::string FeederSystem::log_text() const {
    std::string out;
    for (const auto* p : {&readsb_, &fr24feed_}) {
        for (const auto& l : p->log_lines()) out += l + "\n";
    }
    return out;
}

std::string FeederSystem::read_version() const {
    std::ifstream in(paths_.fr24_version);
    std::string v;
    std::getline(in, v);
    return trim(v);
}

void FeederSystem::poll_once() {
    SystemState next;
    next.fr24_installed = executable(paths_.fr24feed);
    if (next.fr24_installed) next.fr24_version = read_version();

    next.feeding = feeding_;
    next.readsb_running = readsb_.running();
    next.fr24_running = fr24feed_.running();
    next.readsb_restarts = readsb_.restarts();
    next.fr24_restarts = fr24feed_.restarts();
    next.readsb_error = readsb_.last_exit_line();
    next.fr24_error = fr24feed_.last_exit_line();

    if (next.feeding) {
        const std::string monitor = paths_.runtime_dir + "/decoder.txt";
        next.fr24 = parse_decoder_txt(read_text_file(monitor));
        const long long age = age_s(monitor);
        next.fr24_fresh = next.fr24_running && next.fr24.present && age >= 0 && age <= 30;
        const std::string json = paths_.runtime_dir + "/readsb/aircraft.json";
        if (next.readsb_running && age_s(json) >= 0 && age_s(json) <= 10)
            next.aircraft = parse_aircraft_json(read_text_file(json));
    }

    const auto legacy = parse_ini(read_text_file(paths_.legacy_ini));
    if (const auto it = legacy.find("fr24key"); it != legacy.end()) {
        const std::string key = normalize_key(it->second);
        if (valid_sharing_key(key)) next.legacy_key = key;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    next.installing = busy_name_ == "install" || (pending_ && pending_->name == "install");
    state_ = std::move(next);
}

void FeederSystem::poll_loop() {
    while (running_) {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait_for(lock, kPollPeriod, [this] { return !running_.load(); });
        }
        if (!running_) break;
        poll_once();
    }
}

std::vector<std::string> FeederSystem::install_command() const {
    return {paths_.ctl, "install-fr24feed", "--dest", paths_.fr24_dir};
}

bool FeederSystem::submit(Job job) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (pending_ || !busy_name_.empty()) return false;
    pending_ = std::move(job);
    cv_.notify_all();
    return true;
}

bool FeederSystem::submit_install() { return submit({"install", std::nullopt}); }

bool FeederSystem::submit_signup(SignupAnswers answers) {
    return submit({"signup", std::move(answers)});
}

void FeederSystem::cancel_job() { cancel_ = true; }

bool FeederSystem::busy() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return pending_.has_value() || !busy_name_.empty();
}

std::string FeederSystem::busy_name() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!busy_name_.empty()) return busy_name_;
    return pending_ ? pending_->name : std::string{};
}

std::string FeederSystem::live_output() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return live_;
}

std::optional<JobResult> FeederSystem::take_result() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (results_.empty()) return std::nullopt;
    JobResult r = std::move(results_.front());
    results_.pop_front();
    return r;
}

void FeederSystem::job_loop() {
    while (running_) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this] { return pending_.has_value() || !running_.load(); });
            if (!running_) return;
            job = std::move(*pending_);
            pending_.reset();
            busy_name_ = job.name;
            live_.clear();
        }
        cancel_ = false;
        JobResult result = run_job(job);
        {
            std::lock_guard<std::mutex> lock(mutex_);
            busy_name_.clear();
            results_.push_back(std::move(result));
        }
        poll_once();
    }
}

JobResult FeederSystem::run_job(const Job& job) {
    JobResult result;
    result.name = job.name;
    if (job.signup) {
        if (!executable(paths_.fr24feed)) {
            result.message = "fr24feed is not installed";
            return result;
        }
        // FR24's wizard, as the app's user, saving into a fresh file of ours.
        const std::string& rt = paths_.runtime_dir;
        const std::string key_file = rt + "/signup.ini";
        { std::ofstream(key_file, std::ios::trunc); }
        ::chmod(key_file.c_str(), 0600);
        // At its end the wizard tries `systemctl enable/restart fr24feed`; there
        // is no such service here, and a non-root systemctl could ask for a
        // password. A stand-in that does nothing comes first in PATH.
        const std::string nosys = rt + "/nosystemctl";
        ::mkdir(nosys.c_str(), 0700);
        {
            std::ofstream s(nosys + "/systemctl", std::ios::trunc);
            s << "#!/bin/sh\nexit 1\n";
        }
        ::chmod((nosys + "/systemctl").c_str(), 0700);
        const char* path = std::getenv("PATH");
        const std::string new_path = nosys + ":" + (path ? path : "/usr/bin:/bin");
        const SignupResult r = run_signup(
            {paths_.fr24feed, "--signup", "--adsb", "--config-file=" + key_file}, *job.signup, cancel_,
            [this](const std::string& tail) {
                std::lock_guard<std::mutex> lock(mutex_);
                live_ = tail;
            },
            key_file, {{"PATH", new_path}, {"TZ", "GMT"}});
        ::unlink(key_file.c_str());
        result.ok = r.ok;
        result.message = r.ok ? r.sharing_key : r.error;
        result.output = r.transcript;
        result.sharing_key = r.sharing_key;
        return result;
    }
    // install: the helper downloads fr24feed from Flightradar24's repository
    // into the user's data directory and checks its signature.
    const CommandResult r = run_command(install_command(), 900, &cancel_,
                                        [this](const std::string& s) {
                                            std::lock_guard<std::mutex> lock(mutex_);
                                            live_ += s;
                                            if (live_.size() > kLiveLimit)
                                                live_.erase(0, live_.size() - kLiveLimit);
                                        });
    result.ok = r.ok() && executable(paths_.fr24feed);
    result.output = r.output;
    if (r.exit_code == 124) result.message = "timed out";
    else result.message = summarize_output(r.output);
    if (!r.ok() && result.message.empty()) result.message = "exit code " + std::to_string(r.exit_code);
    return result;
}

} // namespace feeder
