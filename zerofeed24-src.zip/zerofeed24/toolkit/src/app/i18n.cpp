/*
 * SPDX-FileCopyrightText: 2026 One Small Step Apps Ltd
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include "i18n.h"

#include <atomic>

#include <cstdlib>
#include <cstring>
#include <initializer_list>

namespace toolkit::i18n {

Lang parse_locale(const char* name) {
    if (!name || std::strlen(name) < 2) return Lang::En;
    const auto is = [name](const char* code) {
        return std::strncmp(name, code, 2) == 0 && (name[2] == '\0' || name[2] == '_' ||
                                                    name[2] == '-' || name[2] == '.');
    };
    if (is("it")) return Lang::It;
    if (is("fr")) return Lang::Fr;
    if (is("de")) return Lang::De;
    if (is("es")) return Lang::Es;
    if (is("ja")) return Lang::Ja;
    if (is("zh")) return Lang::Zh;
    return Lang::En;
}

namespace {
// -1: follow the environment; else a Lang chosen in the app (ZeroFeed24).
std::atomic<int> g_override{-1};
}

void set_override(std::optional<Lang> lang) {
    g_override = lang ? static_cast<int>(*lang) : -1;
}

Lang current() {
    static const Lang from_env = [] {
        // The first variable that is set wins, as in the C library: LC_ALL
        // overrides LANG even when it names a language without translations.
        for (const char* var : {"ZERORADIO_LANG", "LC_ALL", "LC_MESSAGES", "LANG"}) {
            const char* value = std::getenv(var);
            if (value && value[0] != '\0') return parse_locale(value);
        }
        return Lang::En;
    }();
    const int forced = g_override.load();
    return forced >= 0 ? static_cast<Lang>(forced) : from_env;
}

const char* pick(const Text& text, Lang lang) {
    const char* value = nullptr;
    switch (lang) {
        case Lang::It: value = text.it; break;
        case Lang::Fr: value = text.fr; break;
        case Lang::De: value = text.de; break;
        case Lang::Es: value = text.es; break;
        case Lang::Ja: value = text.ja; break;
        case Lang::Zh: value = text.zh; break;
        case Lang::En: break;
    }
    if (value && value[0] != '\0') return value;
    return text.en ? text.en : "";
}

bool needs_cjk_font(Lang lang) {
    return lang == Lang::Ja || lang == Lang::Zh;
}

const char* pick(const Text& text) {
    return pick(text, current());
}

} // namespace toolkit::i18n
