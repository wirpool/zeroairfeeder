# Changelog

## 1.3.0
- Everything grouped by feeder. FEED: one row per feeder with its own state and numbers (radar ID and aircraft for FR24, kB for Plane Finder, station and packets for AirNav), coloured green/yellow/red/grey, then receiver and GPS.
- KEYS: the same menu for every feeder's key: I have one (type it), Get a new one (FR24 signup asking the e-mail; Plane Finder through a QR code for the phone, with the position to type; AirNav automatic), Show it in full. Feeder titles say "ready" or what is missing.
- SETUP grouped too: each feeder on/off with its options, receiver, antenna, app. Group titles are skipped by the cursor; the header shows SETUP n/13.
- Settings save at once; while feeding they apply when you go back to FEED (or with 8). No more Save rows.
- Start feeding with what is ready: feeders still missing a key, program or position are skipped, say what they miss, and join when ready (e.g. after their program is downloaded).

## 1.2.0
- The app is now called ZeroAirFeeder (package zeroairfeeder, settings in ~/.config/zeroairfeeder).
- Settings regrouped in three pages: FEED, KEYS (only the services' keys, e-mail and share codes, with the FR24 signup) and SETUP (services on/off, position and altitude, MLAT, receiver, program updates, theme, language, log, about). The separate FR24 and SHARE pages are gone.
- SETUP > Update programs installs what is missing and looks for newer fr24feed and rbfeeder.
- Long lists scroll with the cursor; the header shows the row (e.g. SETUP 3/14).

## 1.1.0
- Plane Finder and AirNav RadarBox, besides Flightradar24: a new page turns each service on or off (FR24 too), with Plane Finder's share code and AirNav's sharing key.
- All the services feed from the same readsb at once. Their official programs (pfclient, rbfeeder) are children of the app like fr24feed: they run only while feeding and stop with the app.
- Turning a service on downloads its program, as the user, into ~/.local/share/zeroairfeeder: rbfeeder from AirNav's signed repository (signature and checksums verified), pfclient 5.3.31 checked against its pinned SHA256.
- AirNav with no key: rbfeeder gets one at the first connection and the app saves it.
- FEED page: one row per service (FR24 with radar ID and MLAT, Plane Finder, AirNav), aircraft, receiver, GPS. The green dot means every service that is on is connected.
- New package dependencies: the libraries rbfeeder needs (libcurl, GLib, Jansson, protobuf-c, librtlsdr, libbladeRF) and netbase.

## 1.0.0
- First release.
- Feeds ADS-B from the RTL-SDR dongle to Flightradar24: readsb (bundled) decodes, FR24's official fr24feed sends.
- Feeding runs only while the app is open and only after you start it (key 5): readsb and fr24feed are children of the app and stop with it. Nothing starts at boot or runs in the background.
- The app downloads fr24feed from Flightradar24's repository by itself at its first start, as the user, into ~/.local/share/zeroairfeeder (signature and checksums verified). The package has no maintainer scripts and needs no root or sudo.
- Antenna position and altitude from the GPS of the M5Stack Cap LoRa-1262 (by hand only without a fix).
- FR24 page: sharing key, e-mail, MLAT; sign up for a new key through FR24's own signup wizard.
- FEED page: link state, radar ID, aircraft sent and heard, receiver, GPS, MLAT.
- SETUP page: receiver gain and PPM, theme, log of readsb and fr24feed.
- English and Italian: SETUP > Language follows the system or forces one of them, at once.
