#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# Stand-in for AirNav's rbfeeder (simulator and tests): --config <ini> "feeds":
# it writes the log_file named in the ini with rbfeeder 1.0.17's messages, and
# with no key it makes one and saves it back in the ini, as rbfeeder does.
set -u
cfg=""
while [ $# -gt 0 ]; do
    case "$1" in
        --config|-c) cfg="${2:-}"; shift 2 ;;
        --version) echo "RBFeeder v1.0.17 (build 20260808100000)"; exit 0 ;;
        *) shift ;;
    esac
done
if [ -z "$cfg" ] || [ ! -r "$cfg" ]; then echo "Configuration file not found"; exit 1; fi
get() { sed -n "s/^$1=//p" "$cfg" | head -n 1; }
log="$(get log_file)"; key="$(get key)"
say() { local l; l="[$(date '+%Y-%m-%d %H:%M:%S')]  $*"; echo "$l"; [ -n "$log" ] && echo "$l" >> "$log"; }
trap 'say "Exit success!"; exit 0' TERM INT
say "Starting RBFeeder Version 1.0.17 (build 20260808100000)"
say "Using configuration file: $cfg"
say "External host connected!"
sleep 1 & wait $!
if [ -z "$key" ]; then
    key="0f1e2d3c4b5a69788796a5b4c3d2e1f0"
    sed -i "s/^key=.*/key=$key/" "$cfg"
    say "Your new key is $key. Please save this key for future use. You will have to know this key to link this receiver to your account in RadarBox24.com. This key is also saved in configuration file ($cfg)"
fi
say "Connection established."
say "Connection with RadarBox24 server OK! Key accepted by server."
say "This is your station serial number: EXTRPI012345"
total=0
while :; do
    sleep 2 & wait $!
    total=$((total + 37))
    say "Packets sent in the last 2 seconds: 37, Total packets sent since startup: $total"
done
