/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "child_process.h"
#include "signup_script.h"

#include <atomic>
#include <functional>
#include <string>
#include <vector>

namespace feeder {

struct SignupResult {
    bool ok = false;
    std::string sharing_key; // the new key, when ok
    std::string error;       // why not, when !ok
    std::string transcript;  // the wizard's last lines
};

// Runs FR24's signup wizard, `argv` (fr24feed --signup --adsb
// --config-file=<key_file>), on a pseudo-terminal and answers it with
// SignupScript. Blocks until the wizard ends, fails, times out or `cancel` is
// set. The wizard saves the new key in `key_file`: a valid key there is
// success, whatever happened after it was saved. `progress` gets the last
// lines as they change (from this thread).
SignupResult run_signup(const std::vector<std::string>& argv, const SignupAnswers& answers,
                        const std::atomic<bool>& cancel,
                        const std::function<void(const std::string&)>& progress,
                        const std::string& key_file, const ChildProcess::Env& env = {},
                        int timeout_s = 300, int idle_ms = 700);

} // namespace feeder
