/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "base_screen.h"
#include "battery_badge.h"
#include "dialogs.h"
#include "feeder_viewmodel.h"
#include "location_dialog.h"
#include "text_viewer.h"

#include "lvgl.h"

#include <deque>
#include <memory>
#include <string>
#include <vector>

namespace feeder::view {

// The one screen of the app: a header (page, app name, feed dot, battery) over
// the STATUS / ACCOUNT / SETUP views that follow the NavBar page. A 300 ms
// timer runs the viewmodel tick, opens the dialogs it asks for and refreshes
// the visible view. At most one dialog is open at a time.
class FeederScreen : public screen::BaseScreen {
public:
    FeederScreen(FeederViewModel& vm, app::AssetManager& assets);
    ~FeederScreen() override;

protected:
    void build_content(lv_obj_t* content) override;
    bool show_title_bar() const override { return false; }
    bool overlay_nav_bar() const override { return false; }

private:
    enum class PanelKind { None, ConfirmSignup, Job, Error };

    static void tick_cb(lv_timer_t* timer);
    static void table_draw_cb(lv_event_t* event);
    void tick();
    void update_header();
    void update_status();
    void update_list(lv_obj_t* table, int rows, int cursor,
                     std::string (FeederViewModel::*name)(int) const,
                     std::string (FeederViewModel::*value)(int) const);
    void show_view(FeederViewModel::Page page);

    bool dialog_open() const;
    void open(FeederViewModel::Request request);
    void open_panel(PanelKind kind, const std::string& title, const std::string& body,
                    const std::string& footer);
    void on_panel_key(uint32_t key);
    void update_job_panel();
    template <typename P>
    void bury(std::unique_ptr<P>& p) {
        if (p) graveyard_.push_back(std::shared_ptr<void>(std::move(p)));
    }

    lv_obj_t* make_table(lv_obj_t* parent, int32_t name_w, int32_t value_w, bool highlight);
    lv_color_t tone_color(FeederViewModel::Tone tone) const;

    FeederViewModel& vm_;

    lv_obj_t* header_page_ = nullptr;
    lv_obj_t* header_title_ = nullptr;
    lv_obj_t* dot_ = nullptr;
    std::unique_ptr<::view::widgets::BatteryBadge> battery_;

    lv_obj_t* status_view_ = nullptr;
    lv_obj_t* headline_ = nullptr;
    lv_obj_t* status_table_ = nullptr;
    lv_obj_t* account_table_ = nullptr;
    lv_obj_t* setup_table_ = nullptr;
    int account_sel_ = -1;
    int setup_sel_ = -1;

    const lv_font_t* font_ = nullptr;
    const lv_font_t* font_semi_ = nullptr;
    const lv_font_t* font_bold_ = nullptr;

    std::unique_ptr<TextEntryDialog> text_dialog_;
    std::unique_ptr<toolkit::LocationDialog> location_dialog_;
    std::unique_ptr<PanelDialog> panel_;
    std::unique_ptr<::view::widgets::TextViewer> viewer_;
    PanelKind panel_kind_ = PanelKind::None;
    bool job_panel_hidden_ = false;
    std::deque<FeederViewModel::Request> queued_;
    std::vector<std::shared_ptr<void>> graveyard_; // closed dialogs, freed next tick

    bool last_feeding_ = false;
    int last_cursor_[2] = {-1, -1};

    lv_timer_t* timer_ = nullptr;
};

} // namespace feeder::view
