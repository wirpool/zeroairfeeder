#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# Stand-in for FR24's fr24feed (simulator and tests): --signup runs the mock
# wizard, --config-file=<ini> "feeds": it writes the monitor file named in the
# ini every 2 s (connecting, then connected) and its pid, like fr24feed 1.0.57.
set -u
MOCK_DIR="$(cd "$(dirname "$0")" && pwd)"
cfg=""; signup=0
for a in "$@"; do
    case "$a" in
        --config-file=*) cfg="${a#--config-file=}" ;;
        --signup) signup=1 ;;
        --version) echo "1.0.57-1"; exit 0 ;;
    esac
done
if [ "$signup" = 1 ]; then
    exec bash "$MOCK_DIR/mock-signup-wizard.sh" --config-file="$cfg"
fi
if [ -z "$cfg" ] || [ ! -r "$cfg" ]; then echo "[main][e]Config file $cfg does not exist!"; exit 1; fi
get() { sed -n "s/^$1=\"\{0,1\}\([^\"]*\)\"\{0,1\}\$/\1/p" "$cfg" | head -n 1; }
monitor="$(get monitor-file)"; pidfile="$(get write-pid)"; key="$(get fr24key)"
[ -n "$pidfile" ] && echo $$ > "$pidfile"
trap 'echo "[main][i]Terminating on user request"; exit 0' TERM INT
echo "[main][i]FR24 Feeder/Decoder"
echo "[main][i]Version: 1.0.57-1/generic"
echo "[reader][i]Connecting to Beast receiver via (tcp://127.0.0.1:30005)"
start=$(date +%s)
while :; do
    now=$(date +%s)
    status=connecting
    [ $((now - start)) -ge 4 ] && status=connected
    if [ -n "$monitor" ]; then
        {
            echo "time_update_utc_s=$now"
            echo "feed_status=$status"
            echo "feed_current_mode=UDP"
            echo "feed_alias=T-LIML207"
            echo "feed_num_ac_tracked=17"
            echo "rx_connected=1"
            echo "num_messages=$(( (now - start) * 120 ))"
            echo "mlat-ok=NO"
            echo "fr24key=$key"
            echo "build_version=1.0.57-1"
        } > "$monitor.tmp" && mv -f "$monitor.tmp" "$monitor"
    fi
    [ "$status" = connected ] && echo "[feed][i]sent 17,0 AC"
    sleep 2 & wait $!
done
