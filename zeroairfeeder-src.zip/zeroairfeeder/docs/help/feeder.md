# ZeroAirFeeder

Shares the aircraft your RTL-SDR dongle hears with Flightradar24, and if you like with Plane Finder and AirNav RadarBox too. While feeding, readsb decodes ADS-B from the dongle and each feeder that is on gets it through its own official program: fr24feed (Flightradar24), pfclient (Plane Finder), rbfeeder (AirNav). They run only while the app is open and you started feeding: closing the app stops them all, and nothing starts by itself.

## First time
1. Plug the RTL-SDR dongle and a 1090 MHz antenna into the USB-A port, fit the Cap LoRa-1262 (with GPS) and connect to Wi-Fi. Put the CardputerZero where the sky is visible until the GPS row says "fix".
2. SETUP: turn on the feeders you want (Flightradar24 is on already). The app downloads their programs by itself.
3. KEYS: Enter on each feeder's key and pick what you need (see below).
4. FEED: key 5 starts feeding, again to stop. Each feeder's row says what it is doing or what it still needs.

## Keys (KEYS page)
Every feeder works the same way: Enter (or Left/Right) on its key opens a menu, choose with 1-3 or Up/Down + Enter.
- 1 I have one: type it. FR24: flightradar24.com > Account > Data sharing. Plane Finder: planefinder.net > Your Receivers. AirNav: your key from airnavradar.com.
- 2 Get a new one. FR24: the app asks your e-mail and runs FR24's own signup; the key appears on screen and FR24 e-mails it to you. Plane Finder: a QR code opens the share code page on your phone, with the position to type in; then type the code. AirNav: automatic, AirNav gives a key at the first connection and the app saves it.
- 3 Show it in full: to link the feeder to your account on the service's website.
The feeder titles say "ready" when nothing is missing.

## Pages (key 4)
- FEED: one row per feeder (green: feeding, yellow: starting or something missing, red: a problem, grey: off), then the receiver and the GPS. Key 5 start/stop, 6 log, 7 theme, 8 close. Feeders that are not ready are skipped and join as soon as they are.
- KEYS: per feeder its key or share code (and the FR24 e-mail).
- SETUP, grouped: each feeder on/off (and FR24's MLAT), receiver gain and PPM, antenna position and altitude, app (update programs, theme, language, log, about). Up/Down (F/X) move, Left/Right (Z/C) change, Enter acts. The header shows where you are (e.g. SETUP 3/13).

## Notes
- Settings are saved at once. While feeding, changes apply when you go back to FEED (or at once with key 8).
- Without a GPS fix you can set position and altitude by hand in SETUP; the GPS replaces them as soon as it has a fix.
- Typing an e-mail: Tab types @. Shift + 2 also works if your keyboard sends it.
- MLAT (FR24 only) needs a fixed antenna and a precise position. Leave it off on the move.
- SETUP > Update programs: installs what is missing and looks for newer fr24feed and rbfeeder.
- Only one program can use the dongle: close ZeroAirFeeder before using ZeroRadio's SDR, ADS-B or other apps.
