/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

// ZeroFeed24: feed ADS-B data from the CardputerZero's RTL-SDR dongle to
// Flightradar24. readsb and FR24's fr24feed run as children of the app, only
// after the user starts feeding, and stop when the app closes: nothing of
// ZeroFeed24 runs in the background. Position and altitude come from the GPS
// of the M5Stack Cap LoRa-1262.

#include "asset_manager.h"
#include "feeder_screen.h"
#include "feeder_system.h"
#include "feeder_viewmodel.h"
#include "gps_source.h"
#include "run_app.h"

#include <memory>

#ifndef ZF_MOCK_DIR
#define ZF_MOCK_DIR "apps/feeder/assets/mock"
#endif
#ifndef ZF_INSTALL_DIR
#define ZF_INSTALL_DIR "/usr/share/zerofeed24"
#endif
#ifndef ZF_DEFAULT_MOCK
#define ZF_DEFAULT_MOCK 0
#endif

int main() {
    app::AssetManager assets;

    // Declared first, destroyed last: its destructor stops readsb and fr24feed.
    feeder::FeederSystem system(
        feeder::SystemPaths::from_env(ZF_INSTALL_DIR, ZF_MOCK_DIR, ZF_DEFAULT_MOCK != 0));
    feeder::FeederViewModel view_model(system, feeder::GpsSource::create(system.paths().mock));

    std::unique_ptr<feeder::view::FeederScreen> screen;
    const int rc = toolkit::run_app(view_model, assets, [&]() -> lv_obj_t* {
        screen = std::make_unique<feeder::view::FeederScreen>(view_model, assets);
        return screen->root();
    });
    return rc;
}
