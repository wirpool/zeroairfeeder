/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include "fr24_status.h"

#include "feeder_config.h"

#include <nlohmann/json.hpp>

#include <cstdlib>

namespace feeder {

std::string Fr24Status::get(const std::string& key) const {
    const auto it = values.find(key);
    return it == values.end() ? std::string{} : it->second;
}

Fr24Status parse_decoder_txt(const std::string& text) {
    Fr24Status st;
    if (text.empty()) return st;
    st.values = parse_ini(text);
    st.present = !st.values.empty();
    const std::string t = st.get("time_update_utc_s");
    if (!t.empty()) {
        char* end = nullptr;
        const long long v = std::strtoll(t.c_str(), &end, 10);
        if (end != t.c_str() && *end == '\0' && v > 0) st.updated_utc = v;
    }
    return st;
}

bool is_fresh(const Fr24Status& status, int64_t now_utc, int max_age_s) {
    if (!status.present || status.updated_utc <= 0) return false;
    const int64_t age = now_utc - status.updated_utc;
    return age >= -max_age_s && age <= max_age_s; // tolerate a small clock skew
}

AircraftSummary parse_aircraft_json(const std::string& text) {
    AircraftSummary out;
    if (text.empty()) return out;
    const auto doc = nlohmann::json::parse(text, nullptr, /*allow_exceptions=*/false);
    if (doc.is_discarded() || !doc.is_object()) return out;
    out.present = true;
    if (const auto it = doc.find("now"); it != doc.end() && it->is_number()) out.now = it->get<double>();
    if (const auto it = doc.find("messages"); it != doc.end() && it->is_number())
        out.messages = it->get<double>();
    const auto list = doc.find("aircraft");
    if (list == doc.end() || !list->is_array()) return out;
    for (const auto& ac : *list) {
        if (!ac.is_object()) continue;
        double seen = 0.0;
        if (const auto s = ac.find("seen"); s != ac.end() && s->is_number()) seen = s->get<double>();
        if (seen > 60.0) continue;
        ++out.aircraft;
        const auto lat = ac.find("lat");
        const auto lon = ac.find("lon");
        if (lat != ac.end() && lon != ac.end() && lat->is_number() && lon->is_number())
            ++out.with_position;
    }
    return out;
}

} // namespace feeder
