#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
#
# SPDX-License-Identifier: MIT
#
# Stand-in for zerofeed24-ctl in the desktop simulator (ZEROFEED24_MOCK=1):
# "installs" a launcher for mock-fr24feed.sh as fr24feed in the mock state
# directory.
#   MOCK_INSTALL_FAIL=1   fail like a device without internet
set -u
STATE="${ZEROFEED24_MOCK_STATE:-/tmp/zerofeed24-mock-$(id -u)}"
DEST="$STATE/fr24feed"
[ "${2:-}" = "--dest" ] && [ -n "${3:-}" ] && DEST="$3"
HERE="$(cd "$(dirname "$0")" && pwd)"
case "${1:-}" in
    install-fr24feed)
        echo "Downloading the Flightradar24 package index..."; sleep "${MOCK_DELAY:-0.6}"
        if [ "${MOCK_INSTALL_FAIL:-0}" = 1 ]; then
            echo "curl: (6) Could not resolve host: repo-feed.flightradar24.com" >&2
            exit 6
        fi
        echo "Downloading fr24feed 1.0.57-1..."; sleep "${MOCK_DELAY:-0.6}"
        echo "Installing fr24feed 1.0.57-1..."
        mkdir -p "$DEST"
        printf '#!/bin/sh\nexec bash "%s/mock-fr24feed.sh" "$@"\n' "$HERE" > "$DEST/fr24feed"
        chmod 0755 "$DEST/fr24feed"
        echo "1.0.57-1" > "$DEST/version"
        echo "OK: fr24feed 1.0.57-1 installed" ;;
    *) echo "usage: $0 install-fr24feed [--dest DIR]" >&2; exit 64 ;;
esac
