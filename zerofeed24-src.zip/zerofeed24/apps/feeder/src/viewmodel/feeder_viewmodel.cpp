/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_viewmodel.h"

#include "geo.h"
#include "i18n.h"
#include "nav_hints.h"
#include "ui_const.h"

#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace feeder {
namespace {

using T = toolkit::i18n::Text;
const char* tr(const T& t) { return toolkit::i18n::pick(t); }

std::string format_text(const char* format, ...) __attribute__((format(printf, 1, 2)));
std::string format_text(const char* format, ...) {
    char buf[320];
    va_list ap;
    va_start(ap, format);
    std::vsnprintf(buf, sizeof(buf), format, ap);
    va_end(ap);
    return buf;
}

std::string ui_prefs_path() {
    const auto p = settings_path();
    return p.empty() ? std::string{} : (p.parent_path() / "ui").string();
}

// The last `n` non-empty lines of `text`.
std::string last_lines(const std::string& text, size_t n) {
    std::vector<std::string> lines;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        if (line.find_first_not_of(" \t") != std::string::npos) lines.push_back(line);
    }
    std::string out;
    const size_t from = lines.size() > n ? lines.size() - n : 0;
    for (size_t i = from; i < lines.size(); ++i) {
        if (!out.empty()) out += "\n";
        out += lines[i];
    }
    return out;
}

const T kNotSet{"not set", "non impostato"};

// A GPS position counts as new when it moved this far (metres) or the altitude
// changed this much: small wander is not worth a write.
constexpr double kMoveM = 30.0;
constexpr double kAltStepM = 5.0;

// Phosphor-Fill glyphs not in the toolkit's ui_const.h.
constexpr const char* kIconPlay = "";
constexpr const char* kIconStop = "";
constexpr const char* kIconLog = "";  // article
constexpr const char* kIconSave = ""; // floppy disk

} // namespace

FeederViewModel::FeederViewModel(FeederSystem& system, std::unique_ptr<GpsSource> gps)
    : system_(system), gps_(std::move(gps)) {
    set_nav_provider(this);
    set_title("ZeroFeed24");
    load_ui_prefs();
    apply_language();
    if (auto loaded = load_settings(settings_path())) cfg_ = *loaded;
}

FeederViewModel::Page FeederViewModel::page() const {
    return static_cast<Page>(
        lv_subject_get_int(const_cast<FeederViewModel*>(this)->toolbar_page_subject()));
}

FeederViewModel::Request FeederViewModel::take_request() {
    const Request r = request_;
    request_ = Request::None;
    return r;
}

void FeederViewModel::tick() {
    sys_ = system_.state();
    if (gps_) gps_status_ = gps_->status();
    apply_gps();

    if (first_tick_) {
        first_tick_ = false;
        // A key from an earlier fr24feed setup on this device.
        if (cfg_.sharing_key.empty() && !sys_.legacy_key.empty()) {
            cfg_.sharing_key = sys_.legacy_key;
            persist();
            show_status(tr({"Sharing key read from /etc/fr24feed.ini", "Chiave letta da /etc/fr24feed.ini"}));
        }
        // fr24feed is not in the package (it is Flightradar24's): the app
        // downloads it by itself at the first start, into the user's data
        // directory, and checks Flightradar24's signature.
        if (!sys_.fr24_installed && !sys_.installing) install_fr24feed();
    }

    while (auto r = system_.take_result()) handle_result(*r);
}

void FeederViewModel::report_input(bool searched, size_t keypads, const std::string& report) {
    if (!searched) return; // SDL simulator or remote-fb: their own keyboard
    no_keyboard_ = keypads == 0;
    input_file_ = system_.paths().runtime_dir + "/input.txt";
    std::ofstream out(input_file_, std::ios::trunc);
    out << "keypads: " << keypads << "\n" << report;
    std::fprintf(stderr, "zerofeed24: %zu keyboard(s)\n%s", keypads, report.c_str());
}

// The GPS fix becomes the antenna position (and its altitude, in feet for FR24).
void FeederViewModel::apply_gps() {
    if (!gps_status_.fix) return;
    const auto fix = *gps_status_.fix;
    bool changed_pos = !cfg_.has_location || cfg_.location_label != "GPS";
    if (!changed_pos) {
        changed_pos = toolkit::geo::range_nm({cfg_.lat, cfg_.lon}, fix) * 1852.0 > kMoveM;
    }
    bool changed_alt = false;
    if (gps_status_.altitude_m) {
        const double now_m = *gps_status_.altitude_m;
        changed_alt = !cfg_.has_altitude ||
                      std::fabs(feet_to_metres(cfg_.altitude_ft) - now_m) > kAltStepM;
    }
    if (!changed_pos && !changed_alt) return;
    if (changed_pos && valid_lat(fix.lat) && valid_lon(fix.lon)) {
        cfg_.has_location = true;
        cfg_.lat = fix.lat;
        cfg_.lon = fix.lon;
        cfg_.location_label = "GPS";
    }
    if (changed_alt) {
        const int feet = metres_to_feet(*gps_status_.altitude_m);
        if (valid_altitude_ft(feet)) {
            cfg_.has_altitude = true;
            cfg_.altitude_ft = feet;
        }
    }
    persist();
    if (!shared_location_saved_) {
        // Also the position ZeroRadio's ADS-B and AIS apps centre on.
        shared_location_saved_ = true;
        char label[48];
        std::snprintf(label, sizeof(label), "GPS %.3f, %.3f", fix.lat, fix.lon);
        toolkit::location::save({fix, label});
    }
}

// --- jobs and feeding ---------------------------------------------------------

void FeederViewModel::show_error(std::string title, std::string text) {
    error_title_ = std::move(title);
    error_text_ = std::move(text);
    request_ = Request::ShowError;
}

void FeederViewModel::handle_result(const JobResult& r) {
    if (r.name == "install") {
        panel_outcome_ = r.ok;
        if (r.ok) {
            panel_result_ = format_text(tr({"fr24feed %s is installed.", "fr24feed %s è installato."}),
                                        system_.state().fr24_version.c_str());
        } else {
            panel_result_ = std::string(tr({"fr24feed could not be installed: ",
                                            "Impossibile installare fr24feed: "})) + r.message;
            panel_result_ += "\n";
            panel_result_ += tr({"Check the internet connection, then SETUP > fr24feed > Enter.",
                                 "Controlla la connessione a internet, poi SETUP > fr24feed > Invio."});
        }
        show_status(r.ok ? tr({"fr24feed installed", "fr24feed installato"})
                         : tr({"fr24feed not installed", "fr24feed non installato"}));
    } else if (r.name == "signup") {
        panel_outcome_ = r.ok;
        if (r.ok) {
            cfg_.sharing_key = r.sharing_key;
            persist();
            panel_result_ = format_text(tr({"Your sharing key: %s\nFR24 also e-mailed it to %s.\n"
                                            "It is saved. Press 5 on the FEED page to start feeding.",
                                            "La tua chiave di condivisione: %s\nFR24 l'ha inviata anche a "
                                            "%s.\nÈ salvata. Premi 5 nella pagina FEED per avviare l'invio."}),
                                        r.sharing_key.c_str(), cfg_.email.c_str());
            if (sys_.feeding) start_feeding(); // pick up the new key
        } else {
            panel_result_ = std::string(tr({"Signup failed: ", "Registrazione non riuscita: "})) + r.message;
        }
    }
}

std::string FeederViewModel::job_body() const {
    if (panel_outcome_) return panel_result_;
    const std::string live = last_lines(system_.live_output(), 7);
    return live.empty() ? tr({"Working...", "In corso..."}) : live;
}

std::string FeederViewModel::log_text() const {
    const std::string text = system_.log_text();
    if (!text.empty()) return text;
    return tr({"Nothing yet: readsb and fr24feed write here while feeding.",
               "Ancora niente: readsb e fr24feed scrivono qui durante l'invio."});
}

void FeederViewModel::install_fr24feed() {
    if (!system_.submit_install()) {
        show_status(tr({"Busy, try again in a moment", "Occupato, riprova tra poco"}));
        return;
    }
    panel_title_ = tr({"Installing fr24feed", "Installazione di fr24feed"});
    panel_outcome_.reset();
    panel_result_.clear();
    request_ = Request::JobPanel;
}

std::string FeederViewModel::field_missing_text(Field f) const {
    switch (f) {
        case Field::Key:
            return tr({"Set the sharing key first (FR24), or sign up for one",
                       "Imposta prima la chiave (FR24), o registrati per averne una"});
        case Field::Email: return tr({"Set your e-mail first (FR24)", "Imposta prima l'e-mail (FR24)"});
        case Field::Location:
            return tr({"Waiting for the GPS position (or set it by hand on FR24)",
                       "In attesa della posizione GPS (o impostala a mano in FR24)"});
        case Field::Altitude:
            return tr({"Waiting for the GPS altitude (or set it by hand on FR24)",
                       "In attesa dell'altitudine GPS (o impostala a mano in FR24)"});
        case Field::None: break;
    }
    return {};
}

bool FeederViewModel::start_feeding() {
    const std::string error = system_.start_feeding(cfg_);
    if (!error.empty()) {
        show_error(tr({"Could not start feeding", "Impossibile avviare l'invio"}), error);
        return false;
    }
    pending_restart_ = false;
    return true;
}

void FeederViewModel::toggle_feeding() {
    if (sys_.feeding) {
        system_.stop_feeding();
        sys_ = system_.state();
        pending_restart_ = false;
        show_status(tr({"Feeding stopped", "Invio dati fermato"}));
        bump_nav_refresh();
        return;
    }
    if (sys_.installing) {
        show_status(tr({"Wait: fr24feed is being installed", "Attendi: sto installando fr24feed"}));
        return;
    }
    if (!sys_.fr24_installed) {
        show_status(tr({"fr24feed is missing: SETUP > fr24feed > Enter",
                        "Manca fr24feed: SETUP > fr24feed > Invio"}));
        return;
    }
    if (const Field f = missing_for_feeding(cfg_); f != Field::None) {
        show_status(field_missing_text(f));
        return;
    }
    if (start_feeding()) {
        sys_ = system_.state();
        show_status(cfg_.has_location ? tr({"Feeding started", "Invio dati avviato"})
                                      : tr({"Feeding started (no GPS position yet)",
                                            "Invio avviato (ancora senza posizione GPS)"}));
        bump_nav_refresh();
    }
}

void FeederViewModel::save() {
    if (!persist()) {
        show_status(tr({"Could not write the settings file", "Impossibile scrivere il file delle impostazioni"}));
        return;
    }
    if (sys_.feeding && pending_restart_) {
        if (start_feeding()) show_status(tr({"Saved, feeding restarted", "Salvato, invio riavviato"}));
        return;
    }
    show_status(tr({"Saved", "Salvato"}));
}

void FeederViewModel::confirm_signup() {
    SignupAnswers a;
    a.email = cfg_.email;
    a.lat = cfg_.lat;
    a.lon = cfg_.lon;
    a.altitude_ft = cfg_.altitude_ft;
    a.mlat = cfg_.mlat;
    persist();
    if (!system_.submit_signup(a)) {
        show_status(tr({"Busy, try again in a moment", "Occupato, riprova tra poco"}));
        return;
    }
    panel_title_ = tr({"Signing up with Flightradar24", "Registrazione su Flightradar24"});
    panel_outcome_.reset();
    panel_result_.clear();
    request_ = Request::JobPanel;
}

void FeederViewModel::activate() {
    if (page() == Page::Account) {
        switch (static_cast<AccountRow>(account_cursor_)) {
            case AccountRow::Key: request_ = Request::EditKey; break;
            case AccountRow::Email: request_ = Request::EditEmail; break;
            case AccountRow::Location:
            case AccountRow::Altitude:
                if (gps_status_.fix) {
                    show_status(tr({"Position and altitude come from the GPS",
                                    "Posizione e altitudine arrivano dal GPS"}));
                } else {
                    request_ = static_cast<AccountRow>(account_cursor_) == AccountRow::Location
                                   ? Request::EditLocation
                                   : Request::EditAltitude;
                }
                break;
            case AccountRow::Mlat: change_value(1); break;
            case AccountRow::Signup:
                if (!sys_.fr24_installed) {
                    show_status(tr({"fr24feed is missing: SETUP > fr24feed > Enter",
                                    "Manca fr24feed: SETUP > fr24feed > Invio"}));
                } else if (const Field f = missing_for_signup(cfg_); f != Field::None) {
                    show_status(field_missing_text(f));
                } else {
                    request_ = Request::ConfirmSignup;
                }
                break;
            case AccountRow::Save: save(); break;
            case AccountRow::Count: break;
        }
    } else if (page() == Page::Setup) {
        switch (static_cast<SetupRow>(setup_cursor_)) {
            case SetupRow::Fr24feed:
                // Installs fr24feed, or looks for a newer one (the helper keeps
                // the current one when there is none).
                if (sys_.installing) request_ = Request::JobPanel;
                else install_fr24feed();
                break;
            case SetupRow::Gain:
            case SetupRow::Ppm:
            case SetupRow::Theme:
            case SetupRow::Language: change_value(1); break;
            case SetupRow::Log: request_ = Request::ShowLog; break;
            case SetupRow::About: request_ = Request::ShowAbout; break;
            case SetupRow::Count: break;
        }
    }
}

void FeederViewModel::move_cursor(int dir) {
    if (page() == Page::Account) {
        const int n = static_cast<int>(AccountRow::Count);
        account_cursor_ = (account_cursor_ + dir + n) % n;
    } else if (page() == Page::Setup) {
        const int n = static_cast<int>(SetupRow::Count);
        setup_cursor_ = (setup_cursor_ + dir + n) % n;
    }
}

void FeederViewModel::change_value(int dir) {
    if (page() == Page::Account) {
        if (static_cast<AccountRow>(account_cursor_) == AccountRow::Mlat) {
            cfg_.mlat = !cfg_.mlat;
            changed();
            if (cfg_.mlat)
                show_status(tr({"MLAT needs a fixed antenna and a precise position",
                                "La MLAT richiede un'antenna fissa e una posizione precisa"}));
        }
    } else if (page() == Page::Setup) {
        switch (static_cast<SetupRow>(setup_cursor_)) {
            case SetupRow::Gain: {
                const auto& g = gain_choices();
                int i = 0;
                for (int k = 0; k < static_cast<int>(g.size()); ++k)
                    if (g[static_cast<size_t>(k)] == cfg_.gain) i = k;
                const int n = static_cast<int>(g.size());
                cfg_.gain = g[static_cast<size_t>((i + dir + n) % n)];
                changed();
                break;
            }
            case SetupRow::Ppm:
                if (valid_ppm(cfg_.ppm + dir)) {
                    cfg_.ppm += dir;
                    changed();
                }
                break;
            case SetupRow::Theme:
                toggle_dark_mode();
                save_ui_prefs();
                bump_nav_refresh();
                break;
            case SetupRow::Language: {
                static const char* kOrder[] = {"auto", "en", "it"};
                int i = 0;
                for (int k = 0; k < 3; ++k)
                    if (language_ == kOrder[k]) i = k;
                language_ = kOrder[(i + (dir < 0 ? 2 : 1)) % 3];
                apply_language();
                save_ui_prefs();
                bump_nav_refresh();
                break;
            }
            default: break;
        }
    }
}

void FeederViewModel::changed() {
    persist();
    if (sys_.feeding) pending_restart_ = true;
}

bool FeederViewModel::persist() { return save_settings(settings_path(), cfg_); }

// --- dialog results ---------------------------------------------------------

void FeederViewModel::set_key(const std::string& key) {
    const std::string k = normalize_key(key);
    if (!valid_sharing_key(k)) return;
    cfg_.sharing_key = k;
    changed();
}

void FeederViewModel::set_email(const std::string& email) {
    if (!valid_email(email)) return;
    cfg_.email = email;
    persist(); // only used to sign up
}

void FeederViewModel::set_location(const toolkit::location::Place& place) {
    if (gps_status_.fix) return; // the GPS wins
    if (!valid_lat(place.pos.lat) || !valid_lon(place.pos.lon)) return;
    cfg_.has_location = true;
    cfg_.lat = place.pos.lat;
    cfg_.lon = place.pos.lon;
    cfg_.location_label = place.label;
    changed();
}

void FeederViewModel::set_altitude_m(int metres) {
    if (gps_status_.altitude_m) return; // the GPS wins
    const int feet = metres_to_feet(metres);
    if (!valid_altitude_ft(feet)) return;
    cfg_.has_altitude = true;
    cfg_.altitude_ft = feet;
    persist(); // only used to sign up
}

// --- texts ------------------------------------------------------------------

std::string FeederViewModel::masked_key() const {
    if (!valid_sharing_key(cfg_.sharing_key)) return tr(kNotSet);
    return cfg_.sharing_key.substr(0, 4) + "\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2" +
           cfg_.sharing_key.substr(12);
}

std::string FeederViewModel::gps_text() const {
    const auto& g = gps_status_;
    if (g.fix) return format_text(tr({"fix, %d satellites", "fix, %d satelliti"}), g.satellites);
    if (g.receiver) return format_text(tr({"searching, %d satellites", "in ricerca, %d satelliti"}), g.satellites);
    if (g.searching) return tr({"starting the Cap LoRa GPS...", "avvio del GPS del Cap LoRa..."});
    return tr({"no GPS found (Cap LoRa-1262)", "nessun GPS (Cap LoRa-1262)"});
}

std::string FeederViewModel::headline(Tone& tone) const {
    tone = Tone::Warn;
    if (no_keyboard_) {
        tone = Tone::Bad;
        return tr({"Keyboard not found: see ", "Tastiera non trovata: vedi "}) + input_file_;
    }
    if (sys_.installing) return tr({"Installing fr24feed...", "Installazione di fr24feed..."});
    if (!sys_.fr24_installed)
        return tr({"fr24feed missing: SETUP > fr24feed", "Manca fr24feed: SETUP > fr24feed"});
    if (!sys_.feeding) {
        if (!valid_sharing_key(cfg_.sharing_key))
            return tr({"No sharing key yet (FR24)", "Manca la chiave di condivisione (FR24)"});
        tone = Tone::Neutral;
        return tr({"Feeding is off: press 5 to start", "Invio spento: premi 5 per avviare"});
    }
    if (!sys_.readsb_running && sys_.readsb_restarts > 0) {
        tone = Tone::Bad;
        return tr({"No receiver: is the dongle in?", "Nessun ricevitore: la chiavetta è inserita?"});
    }
    if (!sys_.fr24_running && sys_.fr24_restarts > 0) {
        tone = Tone::Bad;
        return tr({"fr24feed stopped (see the log)", "fr24feed si è fermato (vedi il log)"});
    }
    if (!sys_.fr24_fresh) return tr({"Starting...", "Avvio in corso..."});
    if (sys_.fr24.connected()) {
        tone = Tone::Good;
        return tr({"Feeding Flightradar24", "Invio dati a Flightradar24"});
    }
    const std::string st = sys_.fr24.feed_status();
    return std::string("FR24: ") + (st.empty() ? tr({"connecting", "connessione"}) : st);
}

std::string FeederViewModel::status_name(int row) const {
    static const T kNames[kStatusRows] = {
        {"FR24 link", "Collegamento"}, {"Radar ID", "ID radar"}, {"Aircraft", "Aerei"},
        {"Receiver", "Ricevitore"},    {"GPS", "GPS"},           {"MLAT", "MLAT"},
    };
    return (row >= 0 && row < kStatusRows) ? tr(kNames[row]) : "";
}

std::string FeederViewModel::status_value(int row) const {
    const bool live = sys_.fr24_fresh;
    const std::string dash = "\xE2\x80\x94"; // —
    switch (row) {
        case 0: {
            if (!live) return dash;
            std::string s = sys_.fr24.feed_status();
            if (s.empty()) s = tr({"connecting", "connessione"});
            if (!sys_.fr24.feed_mode().empty()) s += " (" + sys_.fr24.feed_mode() + ")";
            if (!sys_.fr24.feed_message().empty()) s += " " + sys_.fr24.feed_message();
            return s;
        }
        case 1: return live && !sys_.fr24.radar_id().empty() ? sys_.fr24.radar_id() : dash;
        case 2: {
            if (!sys_.aircraft.present && !live) return dash;
            const std::string sent = live && !sys_.fr24.tracked().empty() ? sys_.fr24.tracked() : "0";
            return format_text(tr({"%s sent, %d heard, %d with pos.", "%s inviati, %d ricevuti, %d con pos."}),
                               sent.c_str(), sys_.aircraft.aircraft, sys_.aircraft.with_position);
        }
        case 3: {
            if (!sys_.feeding) return tr({"off", "spento"});
            if (!sys_.readsb_running) {
                if (sys_.readsb_restarts == 0) return tr({"starting", "in avvio"});
                // readsb's own words, e.g. "sdrOpen() failed, exiting!" or
                // "no supported devices found": the dongle is missing or busy.
                return tr({"no RTL-SDR dongle (or in use)", "nessuna chiavetta RTL-SDR (o occupata)"});
            }
            if (!sys_.aircraft.present) return tr({"starting", "in avvio"});
            return format_text(tr({"on, %.0f messages", "acceso, %.0f messaggi"}), sys_.aircraft.messages);
        }
        case 4: return gps_text();
        case 5: {
            if (!cfg_.mlat) return tr({"off", "spenta"});
            if (!live) return tr({"on", "accesa"});
            return sys_.fr24.mlat_ok() ? tr({"on, ok", "accesa, ok"}) : tr({"on, waiting", "accesa, in attesa"});
        }
        default: return {};
    }
}

std::string FeederViewModel::account_name(int row) const {
    static const T kNames[static_cast<int>(AccountRow::Count)] = {
        {"Sharing key", "Chiave"},
        {"E-mail", "E-mail"},
        {"Position", "Posizione"},
        {"Altitude", "Altitudine"},
        {"MLAT", "MLAT"},
        {"Get a new key", "Ottieni una chiave"},
        {"Save", "Salva"},
    };
    return (row >= 0 && row < static_cast<int>(AccountRow::Count)) ? tr(kNames[row]) : "";
}

std::string FeederViewModel::account_value(int row) const {
    switch (static_cast<AccountRow>(row)) {
        case AccountRow::Key: return masked_key();
        case AccountRow::Email: return cfg_.email.empty() ? tr(kNotSet) : cfg_.email;
        case AccountRow::Location: {
            if (!cfg_.has_location) return gps_status_.receiver ? tr({"waiting for GPS", "attesa GPS"}) : tr(kNotSet);
            const std::string coords = format_text("%.4f, %.4f", cfg_.lat, cfg_.lon);
            if (cfg_.location_label == "GPS") return "GPS " + coords;
            return coords;
        }
        case AccountRow::Altitude: {
            if (!cfg_.has_altitude)
                return gps_status_.receiver ? tr({"waiting for GPS", "attesa GPS"}) : tr(kNotSet);
            std::string s = format_text("%.0f m (%d ft)", std::round(feet_to_metres(cfg_.altitude_ft)),
                                        cfg_.altitude_ft);
            if (cfg_.location_label == "GPS" && gps_status_.altitude_m) s += " GPS";
            return s;
        }
        case AccountRow::Mlat: return cfg_.mlat ? tr({"on", "attiva"}) : tr({"off", "spenta"});
        case AccountRow::Signup: return tr({"sign up (Enter)", "registrati (Invio)"});
        case AccountRow::Save:
            if (sys_.feeding && pending_restart_) return tr({"restart to apply", "riavvia per applicare"});
            return tr({"saved", "salvato"});
        case AccountRow::Count: break;
    }
    return {};
}

std::string FeederViewModel::setup_name(int row) const {
    static const T kNames[static_cast<int>(SetupRow::Count)] = {
        {"fr24feed", "fr24feed"}, {"Receiver gain", "Guadagno"}, {"PPM correction", "Correzione PPM"},
        {"Theme", "Tema"},        {"Language", "Lingua"},        {"Log", "Log"},
        {"About", "Informazioni"},
    };
    return (row >= 0 && row < static_cast<int>(SetupRow::Count)) ? tr(kNames[row]) : "";
}

std::string FeederViewModel::setup_value(int row) const {
    switch (static_cast<SetupRow>(row)) {
        case SetupRow::Fr24feed:
            if (sys_.installing) return tr({"installing...", "installazione..."});
            if (sys_.fr24_installed)
                return (sys_.fr24_version.empty() ? std::string("installed") : sys_.fr24_version);
            return tr({"install (Enter)", "installa (Invio)"});
        case SetupRow::Gain:
            return (cfg_.gain == "auto" ? std::string("auto") : cfg_.gain + " dB") + "  < >";
        case SetupRow::Ppm: return std::to_string(cfg_.ppm) + "  < >";
        case SetupRow::Theme: return is_dark_mode() ? tr({"dark", "scuro"}) : tr({"light", "chiaro"});
        case SetupRow::Language:
            if (language_ == "en") return "English  < >";
            if (language_ == "it") return "Italiano  < >";
            return std::string(tr({"system", "di sistema"})) + "  < >";
        case SetupRow::Log:
        case SetupRow::About: return tr({"Enter", "Invio"});
        case SetupRow::Count: break;
    }
    return {};
}

// --- theme --------------------------------------------------------------------

void FeederViewModel::load_ui_prefs() {
    const std::string path = ui_prefs_path();
    if (path.empty()) return;
    const auto kv = parse_ini(read_text_file(path));
    if (const auto it = kv.find("dark"); it != kv.end()) set_dark_mode(it->second != "no");
    if (const auto it = kv.find("lang"); it != kv.end() &&
        (it->second == "en" || it->second == "it" || it->second == "auto"))
        language_ = it->second;
}

void FeederViewModel::save_ui_prefs() const {
    const std::string path = ui_prefs_path();
    if (path.empty()) return;
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(path).parent_path(), ec);
    std::ofstream out(path, std::ios::trunc);
    out << "dark=" << (is_dark_mode() ? "yes" : "no") << "\n";
    out << "lang=" << language_ << "\n";
}

// The language picked in SETUP (or the system's) for every text, from now on.
void FeederViewModel::apply_language() {
    using toolkit::i18n::Lang;
    if (language_ == "en") toolkit::i18n::set_override(Lang::En);
    else if (language_ == "it") toolkit::i18n::set_override(Lang::It);
    else toolkit::i18n::set_override(std::nullopt);
    set_help_doc(toolkit::i18n::current() == Lang::It ? "docs/help/feeder.it.md" : "docs/help/feeder.md");
}

// --- NavBar -----------------------------------------------------------------

void FeederViewModel::nav_fill(int page, NavProvider::NavSlot out[5]) const {
    out[0] = {"#", true, true};
    switch (static_cast<Page>(page)) {
        case Page::Status:
            out[1] = {sys_.feeding ? kIconStop : kIconPlay, false, true};
            out[2] = {kIconLog, false, true};
            out[3] = {is_dark_mode() ? ::view::ICON_SUN : ::view::ICON_MOON, false, true};
            out[4] = {::view::ICON_SIGN_OUT, false, true};
            break;
        case Page::Account:
        case Page::Setup:
            out[1] = {::view::ICON_CARET_UP, false, true};
            out[2] = {::view::ICON_CARET_DOWN, false, true};
            out[3] = {::view::ICON_CHECK, false, true};
            out[4] = {kIconSave, false, true};
            break;
    }
}

void FeederViewModel::nav_activate(int page, int slot) {
    switch (static_cast<Page>(page)) {
        case Page::Status:
            if (slot == 1) toggle_feeding();
            else if (slot == 2) request_ = Request::ShowLog;
            else if (slot == 3) {
                toggle_dark_mode();
                save_ui_prefs();
                bump_nav_refresh();
            } else if (slot == 4) request_quit();
            break;
        case Page::Account:
        case Page::Setup:
            if (slot == 1) move_cursor(-1);
            else if (slot == 2) move_cursor(1);
            else if (slot == 3) activate();
            else if (slot == 4) save();
            break;
    }
}

const char* FeederViewModel::nav_page_name(int page) const {
    switch (static_cast<Page>(page)) {
        case Page::Status: return "FEED";
        case Page::Account: return "FR24";
        case Page::Setup: return "SETUP";
    }
    return nullptr;
}

toolkit::i18n::Text FeederViewModel::nav_hint(int page, int slot) const {
    namespace h = toolkit::hints;
    const T kQuit{"Close ZeroFeed24: feeding stops with it", "Chiudi ZeroFeed24: l'invio si ferma con l'app",
                  "Ferme ZeroFeed24 : l’envoi s’arrête avec l’app",
                  "Schließt ZeroFeed24: das Senden endet mit der App",
                  "Cierra ZeroFeed24: el envío se detiene con la app"};
    const T kSave{"Save the settings (and restart feeding with them)",
                  "Salva le impostazioni (e riavvia l'invio con queste)",
                  "Enregistre les réglages (et relance l’envoi avec eux)",
                  "Speichert die Einstellungen (und startet das Senden neu)",
                  "Guarda los ajustes (y reinicia el envío con ellos)"};
    switch (static_cast<Page>(page)) {
        case Page::Status:
            switch (slot) {
                case 1: return {"Start or stop feeding Flightradar24 (only while the app is open)",
                                "Avvia o ferma l'invio a Flightradar24 (solo ad app aperta)",
                                "Démarre ou arrête l’envoi à Flightradar24 (app ouverte seulement)",
                                "Startet oder stoppt das Senden an Flightradar24 (nur bei offener App)",
                                "Inicia o detiene el envío a Flightradar24 (solo con la app abierta)"};
                case 2: return {"Show the last lines of readsb and fr24feed",
                                "Mostra le ultime righe di readsb e fr24feed",
                                "Affiche les dernières lignes de readsb et fr24feed",
                                "Zeigt die letzten Zeilen von readsb und fr24feed",
                                "Muestra las últimas líneas de readsb y fr24feed"};
                case 3: return h::kTheme;
                case 4: return kQuit;
            }
            break;
        case Page::Account:
            switch (slot) {
                case 1: return h::kListUp;
                case 2: return h::kListDown;
                case 3: return {"Edit the selected field, or run the selected action",
                                "Modifica il campo selezionato, o esegui l'azione selezionata",
                                "Modifie le champ choisi, ou lance l’action choisie",
                                "Bearbeitet das gewählte Feld oder führt die Aktion aus",
                                "Edita el campo elegido, o ejecuta la acción elegida"};
                case 4: return kSave;
            }
            break;
        case Page::Setup:
            switch (slot) {
                case 1: return h::kSettingPrev;
                case 2: return h::kSettingNext;
                case 3: return h::kSettingChange;
                case 4: return kSave;
            }
            break;
    }
    return {};
}

} // namespace feeder
