# Changelog

## 1.0.0
- First release.
- Feeds ADS-B from the RTL-SDR dongle to Flightradar24: readsb (bundled) decodes, FR24's official fr24feed sends.
- Feeding runs only while the app is open and only after you start it (key 5): readsb and fr24feed are children of the app and stop with it. Nothing starts at boot or runs in the background.
- The app downloads fr24feed from Flightradar24's repository by itself at its first start, as the user, into ~/.local/share/zerofeed24 (signature and checksums verified). The package has no maintainer scripts and needs no root or sudo.
- Antenna position and altitude from the GPS of the M5Stack Cap LoRa-1262 (by hand only without a fix).
- FR24 page: sharing key, e-mail, MLAT; sign up for a new key through FR24's own signup wizard.
- FEED page: link state, radar ID, aircraft sent and heard, receiver, GPS, MLAT.
- SETUP page: receiver gain and PPM, theme, log of readsb and fr24feed.
- English and Italian: SETUP > Language follows the system or forces one of them, at once.
