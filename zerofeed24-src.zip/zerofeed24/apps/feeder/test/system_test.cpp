/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

// FeederSystem end to end on the mock programs (assets/mock): the install job,
// the signup through the pseudo-terminal, feeding as child processes and,
// above all, that nothing keeps running once feeding stops or the system
// object (the app) goes away.

#include "feeder_config.h"
#include "feeder_system.h"
#include "test_util.h"

#include <chrono>
#include <csignal>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sys/stat.h>
#include <sys/wait.h>
#include <thread>
#include <unistd.h>

#ifndef MOCK_DIR
#error "MOCK_DIR must point to assets/mock"
#endif

using namespace feeder;
using namespace std::chrono_literals;

namespace {

template <typename Pred>
bool wait_for(Pred pred, std::chrono::milliseconds limit = 15000ms) {
    const auto end = std::chrono::steady_clock::now() + limit;
    while (std::chrono::steady_clock::now() < end) {
        if (pred()) return true;
        std::this_thread::sleep_for(50ms);
    }
    return pred();
}

std::optional<JobResult> wait_result(FeederSystem& sys) {
    std::optional<JobResult> r;
    wait_for([&] { return (r = sys.take_result()).has_value(); }, 30000ms);
    return r;
}

// Is a process with this pid alive (and not a zombie)?
bool alive(pid_t pid) {
    if (pid <= 1 || ::kill(pid, 0) != 0) return false;
    std::ifstream st("/proc/" + std::to_string(pid) + "/stat");
    std::string s;
    std::getline(st, s);
    const auto p = s.rfind(')');
    return p != std::string::npos && p + 2 < s.size() && s[p + 2] != 'Z';
}

pid_t read_pid(const std::string& file) {
    std::ifstream in(file);
    long pid = 0;
    in >> pid;
    return static_cast<pid_t>(pid);
}

} // namespace

int main() {
    char tmpl[] = "/tmp/zerofeed24-systest-XXXXXX";
    const char* dir = ::mkdtemp(tmpl);
    CHECK(dir != nullptr);
    if (!dir) return test_result("system_test");
    const std::string state = std::string(dir) + "/state";
    const std::string rt = std::string(dir) + "/rt";
    ::mkdir(rt.c_str(), 0700);
    ::setenv("ZEROFEED24_MOCK_STATE", state.c_str(), 1);
    ::setenv("XDG_RUNTIME_DIR", rt.c_str(), 1);
    ::setenv("MOCK_DELAY", "0", 1);
    ::setenv("ZEROFEED24_MOCK", "1", 1);
    ::unsetenv("ZEROFEED24_CTL");
    ::unsetenv("MOCK_MODE");
    for (const char* v : {"MOCK_EXPECT_EMAIL", "MOCK_EXPECT_LAT", "MOCK_EXPECT_LON", "MOCK_EXPECT_ALT",
                          "MOCK_EXPECT_MLAT"})
        ::unsetenv(v);

    const SystemPaths paths = SystemPaths::from_env("/usr/share/zerofeed24", MOCK_DIR, false);
    CHECK(paths.mock);
    CHECK_EQ(paths.runtime_dir, rt + "/zerofeed24");
    CHECK_EQ(paths.fr24feed, state + "/fr24feed/fr24feed");
    const SystemPaths real = [] {
        ::setenv("ZEROFEED24_MOCK", "0", 1);
        ::setenv("XDG_DATA_HOME", "/home/pi/.local/share", 1);
        auto p = SystemPaths::from_env("/usr/share/zerofeed24", MOCK_DIR, true);
        ::setenv("ZEROFEED24_MOCK", "1", 1);
        ::unsetenv("XDG_DATA_HOME");
        return p;
    }();
    CHECK(!real.mock);
    CHECK_EQ(real.fr24feed, std::string("/home/pi/.local/share/zerofeed24/fr24feed/fr24feed"));
    CHECK_EQ(real.readsb, std::string("/usr/share/zerofeed24/bin/readsb"));
    CHECK_EQ(real.ctl, std::string("/usr/share/zerofeed24/bin/zerofeed24-ctl"));

    FeederConfig cfg;
    cfg.sharing_key = "0123456789abcdef";
    cfg.has_location = true;
    cfg.lat = 45.4642;
    cfg.lon = 9.19;

    pid_t fr24_pid = 0;
    {
        FeederSystem sys(paths);
        CHECK(sys.install_command() ==
              std::vector<std::string>({paths.ctl, "install-fr24feed", "--dest", paths.fr24_dir}));
        SystemState st = sys.state();
        CHECK(!st.fr24_installed && !st.feeding && !st.installing);

        // Not installed yet: feeding refuses, with a reason.
        CHECK_EQ(sys.start_feeding(cfg), std::string("fr24feed is not installed"));
        CHECK(!sys.state().feeding);

        // The install job (no internet first, then fine).
        ::setenv("MOCK_INSTALL_FAIL", "1", 1);
        CHECK(sys.submit_install());
        CHECK(!sys.submit_install()); // one job at a time
        auto r = wait_result(sys);
        CHECK(r && !r->ok);
        if (r) CHECK(r->message.find("Could not resolve host") != std::string::npos);
        ::unsetenv("MOCK_INSTALL_FAIL");
        CHECK(sys.submit_install());
        CHECK(sys.state().installing || sys.busy());
        r = wait_result(sys);
        CHECK(r && r->ok);
        CHECK(wait_for([&] { return sys.state().fr24_installed; }));
        CHECK_EQ(sys.state().fr24_version, std::string("1.0.57-1"));

        // The signup: FR24's wizard as our user, key read back from its file.
        SignupAnswers a;
        a.email = "matteo@example.it";
        a.lat = 45.4642;
        a.lon = 9.19;
        a.altitude_ft = 400;
        CHECK(sys.submit_signup(a));
        r = wait_result(sys);
        CHECK(r && r->ok);
        if (r) {
            if (!r->ok) std::fprintf(stderr, "signup: %s\n%s\n", r->message.c_str(), r->output.c_str());
            CHECK_EQ(r->sharing_key, std::string("0a1b2c3d4e5f6a7b"));
        }
        CHECK(!std::filesystem::exists(paths.runtime_dir + "/signup.ini")); // not left behind

        // Feeding: two child processes, the ini, the status.
        FeederConfig nokey = cfg;
        nokey.sharing_key.clear();
        CHECK_EQ(sys.start_feeding(nokey), std::string("no sharing key"));
        CHECK_EQ(sys.start_feeding(cfg), std::string(""));
        CHECK(wait_for([&] {
            const auto s = sys.state();
            return s.feeding && s.readsb_running && s.fr24_running && s.fr24_fresh &&
                   s.fr24.connected() && s.aircraft.present;
        }));
        st = sys.state();
        CHECK_EQ(st.fr24.radar_id(), std::string("T-LIML207"));
        CHECK_EQ(st.aircraft.aircraft, 21);
        const std::string ini = paths.runtime_dir + "/fr24feed.ini";
        CHECK_EQ(read_text_file(ini), render_fr24feed_ini(cfg, paths.runtime_dir));
        CHECK_EQ(std::filesystem::status(ini).permissions() & std::filesystem::perms::all,
                 std::filesystem::perms::owner_read | std::filesystem::perms::owner_write);
        fr24_pid = read_pid(paths.runtime_dir + "/fr24feed.pid");
        CHECK(alive(fr24_pid));
        CHECK(sys.log_text().find("fr24feed: [main][i]FR24 Feeder/Decoder") != std::string::npos);
        CHECK(sys.log_text().find("readsb: readsb version") != std::string::npos);

        // Stop: both gone at once.
        sys.stop_feeding();
        CHECK(wait_for([&] { return !alive(fr24_pid); }, 3000ms));
        st = sys.state();
        CHECK(!st.feeding && !st.readsb_running && !st.fr24_running);

        // A missing dongle: readsb keeps exiting, the reason is kept.
        ::setenv("MOCK_NO_DONGLE", "1", 1);
        CHECK_EQ(sys.start_feeding(cfg), std::string(""));
        CHECK(wait_for([&] { return sys.state().readsb_error.find("no supported devices") != std::string::npos; }));
        ::unsetenv("MOCK_NO_DONGLE");
        sys.stop_feeding();

        // Feeding on when the app closes...
        CHECK_EQ(sys.start_feeding(cfg), std::string(""));
        CHECK(wait_for([&] { return alive(read_pid(paths.runtime_dir + "/fr24feed.pid")); }));
        fr24_pid = read_pid(paths.runtime_dir + "/fr24feed.pid");
    }
    // ... and nothing left once the app (the FeederSystem) is gone.
    CHECK(wait_for([&] { return !alive(fr24_pid); }, 3000ms));

    // The app killed outright: the children die with it (PR_SET_PDEATHSIG).
    {
        const pid_t app = ::fork();
        if (app == 0) {
            FeederSystem sys(paths);
            sys.start_feeding(cfg);
            for (;;) ::pause();
        }
        CHECK(wait_for([&] {
            const pid_t p = read_pid(paths.runtime_dir + "/fr24feed.pid");
            return p != fr24_pid && alive(p);
        }));
        const pid_t child = read_pid(paths.runtime_dir + "/fr24feed.pid");
        ::kill(app, SIGKILL);
        ::waitpid(app, nullptr, 0);
        CHECK(wait_for([&] { return !alive(child); }, 3000ms));
    }

    CHECK_EQ(summarize_output("a\nERROR: bad\nlast\n"), std::string("ERROR: bad"));
    CHECK_EQ(summarize_output("sudo: a password is required\n"), std::string("sudo: a password is required"));
    CHECK_EQ(summarize_output("one\n  two  \n\n"), std::string("two  "));

    std::filesystem::remove_all(dir);
    return test_result("system_test");
}
