/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "signup_runner.h"

#include "child_process.h"
#include "feeder_config.h"

#include <chrono>

namespace feeder {

SignupResult run_signup(const std::vector<std::string>& argv, const SignupAnswers& answers,
                        const std::atomic<bool>& cancel,
                        const std::function<void(const std::string&)>& progress,
                        const std::string& key_file, const ChildProcess::Env& env,
                        int timeout_s, int idle_ms) {
    using clock = std::chrono::steady_clock;
    SignupResult result;
    SignupScript script(answers);
    ChildProcess child;
    std::string error;
    if (!child.start(argv, /*pty=*/true, &error, env)) {
        result.error = "cannot start the signup: " + error;
        return result;
    }

    const auto deadline = clock::now() + std::chrono::seconds(timeout_s);
    auto last_output = clock::now();
    bool idle_sent = false;
    bool eof = false;
    std::string stop_reason;

    const auto send = [&](const std::optional<std::string>& answer) {
        if (answer && !child.write_line(*answer)) stop_reason = "cannot write to the wizard";
    };
    const auto report = [&]() {
        if (progress) progress(script.tail(7, "\n"));
    };

    while (stop_reason.empty()) {
        std::string chunk;
        const int r = child.read(chunk, 150);
        if (r > 0) {
            last_output = clock::now();
            idle_sent = false;
            send(script.on_output(chunk));
            report();
        } else if (r < 0) {
            eof = true;
            break;
        } else if (!idle_sent &&
                   clock::now() - last_output > std::chrono::milliseconds(idle_ms)) {
            idle_sent = true;
            send(script.on_idle());
        }
        if (script.failed()) stop_reason = script.error();
        else if (cancel.load()) stop_reason = "cancelled";
        else if (clock::now() > deadline) stop_reason = "the signup timed out";
    }

    if (!eof) {
        // Let the wizard print its last words (e.g. after "try again: no").
        const auto grace = clock::now() + std::chrono::milliseconds(1500);
        while (clock::now() < grace) {
            std::string chunk;
            const int r = child.read(chunk, 100);
            if (r < 0) break;
            if (r > 0) script.on_output(chunk);
        }
        child.terminate();
    }
    const int code = child.wait();
    result.transcript = script.tail(12, "\n");
    report();

    // The wizard writes the key into its config file: that is what counts.
    const auto kv = parse_ini(read_text_file(key_file));
    const auto it = kv.find("fr24key");
    const std::string key = it == kv.end() ? std::string{} : normalize_key(it->second);
    if (valid_sharing_key(key)) {
        result.ok = true;
        result.sharing_key = key;
        return result;
    }
    if (!stop_reason.empty()) result.error = stop_reason;
    else if (script.failed()) result.error = script.error();
    else if (code != 0)
        result.error = "the signup ended with code " + std::to_string(code) + ": " + script.tail(3);
    else result.error = "the wizard ended without a sharing key: " + script.tail(3);
    return result;
}

} // namespace feeder
