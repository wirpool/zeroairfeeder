#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# Stand-in for zeroairfeeder-ctl in the desktop simulator (ZEROAIRFEEDER_MOCK=1):
# "installs" a launcher for mock-fr24feed.sh, mock-pfclient.sh or
# mock-rbfeeder.sh in the mock state directory.
#   MOCK_INSTALL_FAIL=1   fail like a device without internet
set -u
STATE="${ZEROAIRFEEDER_MOCK_STATE:-/tmp/zeroairfeeder-mock-$(id -u)}"
HERE="$(cd "$(dirname "$0")" && pwd)"
case "${1:-}" in
    install-fr24feed) prog=fr24feed; ver=1.0.57-1; maker=Flightradar24; host=repo-feed.flightradar24.com ;;
    install-pfclient) prog=pfclient; ver=5.3.31; maker="Plane Finder"; host=client.planefinder.net ;;
    install-rbfeeder) prog=rbfeeder; ver=1:1.0.17+trixie; maker=AirNav; host=apt.rb24.com ;;
    *) echo "usage: $0 install-fr24feed|install-rbfeeder|install-pfclient [--dest DIR]" >&2; exit 64 ;;
esac
DEST="$STATE/$prog"
[ "${2:-}" = "--dest" ] && [ -n "${3:-}" ] && DEST="$3"
echo "Downloading the $maker package index..."; sleep "${MOCK_DELAY:-0.6}"
if [ "${MOCK_INSTALL_FAIL:-0}" = 1 ]; then
    echo "curl: (6) Could not resolve host: $host" >&2
    exit 6
fi
echo "Downloading $prog $ver..."; sleep "${MOCK_DELAY:-0.6}"
echo "Installing $prog $ver..."
mkdir -p "$DEST"
printf '#!/bin/sh\nexec bash "%s/mock-%s.sh" "$@"\n' "$HERE" "$prog" > "$DEST/$prog"
chmod 0755 "$DEST/$prog"
echo "$ver" > "$DEST/version"
echo "OK: $prog $ver installed"
