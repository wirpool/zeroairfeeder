# Third-party licences

ZeroAirFeeder is released under the MIT licence (../LICENSE). It contains or ships the
following third-party work, each under its own licence, reproduced here.

| Component | Where | Licence | File |
| --- | --- | --- | --- |
| ZeroRadio toolkit (Andrea Salvatore, One Small Step Apps Ltd) | `toolkit/`, build files | MIT | ../LICENSE (copyright lines kept) |
| CardputerZero Template (M5Stack) | `toolkit/` (template-derived files), toolchain | MIT | ../LICENSE (copyright lines kept) |
| LVGL 9.5 | linked into the app | MIT | lvgl-LICENCE.txt |
| QR-Code generator (Project Nayuki), inside LVGL | linked into the app | MIT | lvgl-qrcode-LICENSE.txt |
| TJpgDec (ChaN), inside LVGL | linked into the app | BSD-style | lvgl-tjpgd-LICENSE.txt |
| nlohmann/json 3.11 | compiled into the app | MIT | nlohmann-json-LICENSE.MIT.txt |
| Inter font | `fonts/inter-*.ttf` | SIL OFL 1.1 | ../fonts/LICENSE.txt |
| Phosphor icons | `fonts/Phosphor-Fill.ttf`, app icon glyph | MIT | ../fonts/LICENSE.txt |
| GeoNames cities15000 | `geodata/cities.tsv` | CC BY 4.0 | attribution: "Contains data from GeoNames (geonames.org)" |
| readsb v3.16.16 (wiedehopf and contributors) | `bin/readsb`, a separate program | GPL-3.0 or later | readsb-COPYING.txt, readsb-LICENSE.txt |

## readsb source code

`bin/readsb` is built, unmodified, from the tag v3.16.16 of
https://github.com/wiedehopf/readsb (build options in `cmake/decoders.cmake` of the
ZeroAirFeeder sources). Its complete source code is at
https://github.com/wiedehopf/readsb/tree/v3.16.16. On request, the ZeroAirFeeder maintainers
provide the same source code for at least three years from the release of this package.

## Not included

fr24feed is Flightradar24's software. It is not part of this package: the app downloads it
from Flightradar24's repository and uses it unmodified, under Flightradar24's own licence
(a copy is saved next to it, in `~/.local/share/zeroairfeeder/fr24feed/licences/`).

pfclient (Plane Finder, Pinkfroot Ltd) and rbfeeder (AirNav Systems) are not part of this
package either: the app downloads them only when you turn Plane Finder or AirNav on, from
client.planefinder.net and apt.rb24.com, and uses them unmodified under their makers' terms
(rbfeeder's copyright file is saved next to it, in `~/.local/share/zeroairfeeder/rbfeeder/`).

System libraries (FreeType, libpng, libjpeg, zlib, fmt, librtlsdr, ...) come from Debian
packages under their own licences.
