# ZeroAirFeeder

Feed ADS-B aircraft data from the **M5Stack CardputerZero** to **Flightradar24**, and
optionally to **Plane Finder** and **AirNav RadarBox**.
Plug an RTL-SDR dongle with a 1090 MHz antenna into the USB-A port, fit the M5Stack Cap
LoRa-1262 (its GPS gives the antenna position), enter your FR24 sharing key (or get one from
the app) and start feeding. Feeding runs only while the app is open.

<p>
<img src="docs/media/feed.png" width="320" alt="FEED page">
<img src="docs/media/keys.png" width="320" alt="KEYS page">
<img src="docs/media/setup.png" width="320" alt="SETUP page">
</p>

Built on the toolkit of [ZeroRadio](https://github.com/andreahaku/zeroradio) (same
look, same keys, same shared position) and on each service's own feeder program.

## How it works

```
                                         ┌──► fr24feed  ──► Flightradar24   (decoder.txt)
RTL-SDR ──► readsb ──Beast 127.0.0.1:30005──► pfclient  ──► Plane Finder    (:30053/ajax/stats)
              │ aircraft.json            └──► rbfeeder  ──► AirNav RadarBox (rbfeeder.log)
              └──► ZeroAirFeeder app ◄── status of each        Cap LoRa-1262 GPS ──► position, altitude
                   (every program is a child of the app; only the services that are on run)
```

- **Nothing runs in the background.** readsb and the services' programs are child processes of the app,
  started only when you press 5 on the FEED page. They stop when you press 5 again or close
  the app, and the kernel stops them if the app is killed (`PR_SET_PDEATHSIG`). No service,
  nothing at boot.
- **readsb** (bundled, GPL-3.0) decodes 1090 MHz from the dongle and serves Beast on
  127.0.0.1:30005 only.
- **fr24feed** is Flightradar24's official program, used unmodified, configured as
  `receiver="beast-tcp"`, `host="127.0.0.1:30005"` (FR24's own setup for an external decoder).
  It runs as your user, with its config, monitor file, pid and logs in
  `$XDG_RUNTIME_DIR/zeroairfeeder/` (checked with fr24feed 1.0.57 on arm64).
- **pfclient** (Plane Finder, optional) and **rbfeeder** (AirNav RadarBox, optional) are
  the services' official programs, used unmodified and run as your user on the same Beast
  output: pfclient with the options of the sdr-enthusiasts container (`--connection_type=1
  --data_format=1`, share code, position; files in the runtime directory), rbfeeder with
  `--config $XDG_RUNTIME_DIR/zeroairfeeder/rbfeeder.ini` in network mode, its own MLAT and GNSS
  off (checked with pfclient 5.3.31 and rbfeeder 1.0.17 on arm64 trixie, as a normal user).
- **Position and altitude** come from the GPS of the **M5Stack Cap LoRa-1262** (ZeroRadio's
  reader: it powers the HAT 5 V rail and reads NMEA on `/dev/ttyS0`; a USB GPS works too). They
  go to readsb and to the FR24 signup. Without a fix you can set them by hand.

## The app

Three pages, key 4 switches (hold 4 for the previous one), H opens the help. Everything is
grouped by feeder.

| Page | What | Keys |
| --- | --- | --- |
| **FEED** | one row per feeder (Flightradar24, Plane Finder, AirNav) with its own state and numbers, coloured green/yellow/red/grey; then receiver and GPS | 5 start/stop, 6 log, 7 theme, 8 close |
| **KEYS** | per feeder its key or share code (and the FR24 e-mail); every key has the same menu: *I have one*, *Get a new one*, *Show it in full* | F/X move, Enter or Z/C open the menu, 1-3 choose |
| **SETUP** | per feeder on/off (and FR24's MLAT), receiver gain and PPM, antenna position and altitude, app (update programs, theme, language, log, about); group titles, scrolling, `SETUP 3/13` in the header | F/X move, Z/C change, Enter act, 8 apply now |

- Settings are saved as they change; while feeding they apply when you go back to FEED (or at
  once with 8). Feeders that are not ready yet (no key, no program, no position) are skipped
  and their row on FEED says what they miss.
- **Sharing key**: 16 letters or digits, from flightradar24.com > Account > Data sharing.
  If `/etc/fr24feed.ini` from an earlier fr24feed install has one, the app takes it.
- **Get a new one** for FR24 asks your e-mail and runs FR24's own signup wizard (`fr24feed --signup --adsb`) as your user and
  answers it (e-mail, GPS position and altitude, MLAT, Beast on 127.0.0.1:30005). The key
  appears on screen and FR24 e-mails it to you.
- **E-mail**: Tab types `@` (Shift+2 works too if the keyboard sends it).
- **MLAT** is off by default: it needs a fixed antenna and a precise position.
- **Plane Finder** needs a share code (planefinder.net > Sharing > Create share code) and the
  position. **AirNav** needs nothing: with no key, rbfeeder gets one from AirNav at its first
  connection, writes it to its ini and the app saves it in the settings. Turning a service on
  downloads its program right away.

## Install

On the CardputerZero (Debian trixie, arm64), from the store or by hand:

```bash
cp zeroairfeeder_1.1.0_arm64.deb /tmp/ && sudo apt install /tmp/zeroairfeeder_1.1.0_arm64.deb
```

At its first start the app downloads fr24feed by itself (it needs internet once) into
`~/.local/share/zeroairfeeder/fr24feed/`. SETUP > Update programs > Enter does it again, or updates it.
pfclient and rbfeeder are downloaded the same way, into `~/.local/share/zeroairfeeder/pfclient/`
and `.../rbfeeder/`, when you turn Plane Finder or AirNav on.

### What the package changes on the system

Only its own files: no maintainer scripts, no service, no sudo rule, nothing run as root.

| Path | What |
| --- | --- |
| `/usr/share/zeroairfeeder/bin/` | the app, `readsb`, `zeroairfeeder-ctl` (downloader of the feeder programs) |
| `/usr/share/zeroairfeeder/flightradar24.gpg` | Flightradar24's repository key |
| `/usr/share/zeroairfeeder/airnav.gpg` | AirNav's repository key |
| `/usr/share/APPLaunch/...` | launcher entry and icon |
| `~/.local/share/zeroairfeeder/fr24feed/` | fr24feed, its version and licences (downloaded by the app) |
| `~/.local/share/zeroairfeeder/pfclient/`, `.../rbfeeder/` | pfclient and rbfeeder, if you turned Plane Finder or AirNav on |
| `~/.config/zeroairfeeder/` | settings, theme, language |

`zeroairfeeder-ctl install-fr24feed` runs as the app's user and checks the download the way apt
does: `InRelease` signed with Flightradar24's key (fingerprint
`B35C 96E2 E7F2 C2C7 3274 120F C969 F078 40C4 30F5`), then the SHA256 of the package index and
of the `.deb`. It only extracts the `fr24feed` binary: FR24's package, with its service and
daily updater, is **not** installed, so nothing of FR24 runs in the background either.

`zeroairfeeder-ctl install-rbfeeder` does the same with AirNav's repository (`apt.rb24.com`,
dist `trixie`, key fingerprint `52FD 03F4 53DD 205B A982 44F4 03C6 85A6 082B CF18`, the one
AirNav's own installer pins) and extracts only `rbfeeder` (not its service, `dump1090-rb` or
the MLAT client). Plane Finder publishes pfclient as a plain, unsigned tarball, so
`zeroairfeeder-ctl install-pfclient` accepts exactly one version (5.3.31 arm64) with its SHA256
pinned in the script, and nothing else in the archive. The package depends on the libraries
rbfeeder links to (libcurl, GLib, Jansson, protobuf-c, libbladeRF; librtlsdr comes with readsb) and on netbase.

Uninstall: `sudo apt remove zeroairfeeder`. apt never touches home directories: to remove the
downloaded fr24feed and the settings too, `rm -r ~/.local/share/zeroairfeeder ~/.config/zeroairfeeder`.

## Notes

- **One program per dongle.** While ZeroAirFeeder is open and feeding, ZeroRadio's SDR/ADS-B
  apps cannot open the dongle; on the CardputerZero only one app is open at a time anyway.
- While feeding, fr24feed shows its own status page on port 8754 to private networks:
  `http://<cardputer-ip>:8754`; pfclient its own on port 30053 (`http://<cardputer-ip>:30053`).
- rbfeeder warns that it cannot remove `/var/run/rbfeeder/rbfeeder.pid`: it is harmless, the
  app does not run it as a service.
- FR24 allows 3 feeders per account; the radar ID (e.g. `T-LIML123`) appears once FR24 has
  accepted the feeder.

## Build

Same tooling as ZeroRadio.

```bash
# Desktop simulator (SDL window 320x170) with the mock helper and sample data
cmake --preset linux-x86-64 && cmake --build --preset linux-x86-64-dbg
./build/linux-x86-64/apps/feeder/Debug/zeroairfeeder_app      # ZEROAIRFEEDER_MOCK=0 for the real helper
ctest --test-dir build/linux-x86-64 -C Debug --output-on-failure

# Device build and .deb, in a Debian trixie container (needs Docker)
scripts/cp0-docker-build.sh --package                       # build/cp0-trixie/zeroairfeeder_<v>_arm64.deb
```

Maintainer: Wirpool <wirpool12@gmail.com>. Source: https://github.com/wirpool/zeroairfeeder

Tests: `feeder_core_test` (validation, ini files, settings, readsb and pfclient arguments,
rbfeeder ini, fr24feed monitor file, pfclient stats, rbfeeder log, aircraft.json), `signup_test` (the wizard driver on FR24's real prompt texts,
then on a pseudo-terminal against a mock wizard that reads `/dev/tty` like fr24feed),
`system_test` (feeding one or all three services with mock programs, the download queue,
AirNav's new key read back; nothing left running after stop, after the app object goes away,
or after the app is killed with SIGKILL), `ctl_helper_test` (the fr24feed and rbfeeder
downloads against locally signed fake repositories: wrong signature, altered index or altered
`.deb` are refused; pfclient with a wrong checksum or extra files is refused), plus ZeroRadio's location (with the GGA altitude) and i18n tests.

## Layout

```
apps/feeder/src/core/        pure logic: config + validation, fr24feed/pfclient/rbfeeder/readsb status, signup script
apps/feeder/src/sys/         child processes and pty, supervised readsb and feeders, signup runner, FeederSystem
apps/feeder/src/app/         GPS source (Cap LoRa-1262 through the toolkit's GnssReader, or a mock)
apps/feeder/src/viewmodel/   FeederViewModel (pages, actions, NavBar)
apps/feeder/src/view/        FeederScreen, text entry and panel dialogs
apps/feeder/assets/mock/     sample data, mock readsb / fr24feed / pfclient / rbfeeder / helper / signup wizard
system/                      zeroairfeeder-ctl, Flightradar24's and AirNav's keys, the launcher entry
toolkit/                     ZeroRadio's toolkit (MIT); text entry gained Shift/Caps (@, _, capitals),
                             the GPS reader gained the GGA altitude
```

## Italiano in breve

ZeroAirFeeder invia a Flightradar24 gli aerei ricevuti dalla chiavetta RTL-SDR del
CardputerZero. Al primo avvio l'app scarica da sola fr24feed (il programma ufficiale di FR24,
firma verificata) nella cartella dell'utente: niente root, niente sudo. Posizione e
altitudine arrivano dal GPS del Cap LoRa-1262. Nella pagina CHIAVI, per ogni feeder, inserisci la chiave che hai o ottienine una nuova (FR24 con la registrazione ufficiale, Plane Finder con un QR per il telefono, AirNav in automatico); la chiave di
condivisione (o registrati con "Ottieni una chiave"), poi premi 5 nella pagina FEED. Nella
pagina SETUP puoi attivare anche Plane Finder (lo share code va in CHIAVI) e AirNav RadarBox
(la chiave arriva da sola alla prima connessione): l'app ne scarica e verifica i programmi. La lingua (sistema, English, Italiano) si sceglie in SETUP > Lingua. L'invio
gira solo ad app aperta e si ferma quando la chiudi: niente in background, niente all'avvio.

## Licence

MIT (see LICENSE). readsb is GPL-3.0 and ships as a separate program. fr24feed,
pfclient and rbfeeder are the software of Flightradar24, Plane Finder (Pinkfroot) and AirNav
Systems under their own terms; none of them is part of this package. Credits in
CREDITS.md.
