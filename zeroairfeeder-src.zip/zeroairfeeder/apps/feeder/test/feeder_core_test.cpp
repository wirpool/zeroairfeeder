/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

// Pure logic: validation, ini files, settings round trip, the fr24feed monitor
// file and readsb's aircraft.json.

#include "feeder_config.h"
#include "fr24_status.h"
#include "test_util.h"

#include <cstdlib>
#include <filesystem>
#include <string>
#include <unistd.h>
#include <vector>

using namespace feeder;

static void test_validation() {
    CHECK(valid_sharing_key("0123456789abcdef"));
    CHECK(valid_sharing_key("0123456789ABCDEF"));
    CHECK(!valid_sharing_key("0123456789abcde"));    // 15
    CHECK(!valid_sharing_key("0123456789abcdef0"));  // 17
    CHECK(!valid_sharing_key("0123456789abcde!"));
    CHECK(!valid_sharing_key("0123456789abcd\"f"));
    CHECK(!valid_sharing_key(""));
    CHECK_EQ(normalize_key(" 0123-4567 89ab cdef\n"), std::string("0123456789abcdef"));

    CHECK(valid_email("matteo@example.it"));
    CHECK(valid_email("a.b+c@mail.example.co.uk"));
    CHECK(!valid_email("matteo"));
    CHECK(!valid_email("@example.it"));
    CHECK(!valid_email("matteo@example"));
    CHECK(!valid_email("matteo@@example.it"));
    CHECK(!valid_email("mat teo@example.it"));
    CHECK(!valid_email("matteo@example.it."));
    CHECK(!valid_email("matteo@example..it"));
    CHECK(!valid_email("ma\"tteo@example.it"));
    CHECK(!valid_email("matteo@.example.it"));

    CHECK(valid_lat(45.4642) && valid_lat(-90) && valid_lat(90) && !valid_lat(90.01));
    CHECK(valid_lon(9.19) && valid_lon(-180) && !valid_lon(180.5));
    CHECK(valid_altitude_ft(400) && !valid_altitude_ft(40000) && !valid_altitude_ft(-2000));
    CHECK(valid_ppm(0) && valid_ppm(-200) && !valid_ppm(201));
    CHECK(valid_gain("auto") && valid_gain("49.6") && valid_gain("58") && !valid_gain("50"));
    CHECK_EQ(gain_choices().front(), std::string("auto"));

    CHECK_EQ(metres_to_feet(100.0), 328);
    CHECK_EQ(metres_to_feet(0.0), 0);
    CHECK(feet_to_metres(328) > 99.9 && feet_to_metres(328) < 100.1);
    CHECK_EQ(format_coord(45.4642), std::string("45.464200"));
    CHECK_EQ(format_coord(-0.000001), std::string("-0.000001"));
}

static void test_ini() {
    const auto kv = parse_ini(
        "receiver=\"beast-tcp\"\n"
        "fr24key=\"0123456789abcdef\"\r\n"
        "  host = 127.0.0.1:30005  \n"
        "# comment\n"
        "; other comment\n"
        "\n"
        "noequals\n"
        "=novalue\n"
        "mlat=\"no\"\n");
    CHECK_EQ(kv.size(), static_cast<size_t>(4));
    CHECK_EQ(kv.at("receiver"), std::string("beast-tcp"));
    CHECK_EQ(kv.at("fr24key"), std::string("0123456789abcdef"));
    CHECK_EQ(kv.at("host"), std::string("127.0.0.1:30005"));
    CHECK_EQ(kv.at("mlat"), std::string("no"));

    FeederConfig cfg;
    cfg.sharing_key = "0123456789abcdef";
    cfg.mlat = true;
    const std::string ini = render_fr24feed_ini(cfg, "/run/user/1000/zeroairfeeder");
    CHECK_EQ(ini, std::string("receiver=\"beast-tcp\"\n"
                              "fr24key=\"0123456789abcdef\"\n"
                              "host=\"127.0.0.1:30005\"\n"
                              "bs=\"no\"\n"
                              "raw=\"no\"\n"
                              "logmode=\"0\"\n"
                              "logpath=\"/run/user/1000/zeroairfeeder\"\n"
                              "mlat=\"yes\"\n"
                              "mlat-without-gps=\"yes\"\n"
                              "monitor-file=\"/run/user/1000/zeroairfeeder/decoder.txt\"\n"
                              "write-pid=\"/run/user/1000/zeroairfeeder/fr24feed.pid\"\n"));
    const auto back = parse_ini(ini);
    CHECK_EQ(back.at("fr24key"), cfg.sharing_key);
    CHECK_EQ(back.at("mlat-without-gps"), std::string("yes"));
    CHECK_EQ(back.at("monitor-file"), std::string("/run/user/1000/zeroairfeeder/decoder.txt"));

    // readsb: device first, Beast on localhost only, position when known.
    FeederConfig r;
    auto args = readsb_args(r, "/rt/readsb");
    CHECK(args == std::vector<std::string>({"--device-type", "rtlsdr", "--gain", "auto", "--net",
                                            "--net-bind-address", "127.0.0.1", "--net-bo-port", "30005",
                                            "--write-json", "/rt/readsb", "--write-json-every", "1",
                                            "--quiet"}));
    r.gain = "42.1";
    r.ppm = -3;
    r.has_location = true;
    r.lat = 45.464211;
    r.lon = 9.191383;
    args = readsb_args(r, "/rt/readsb");
    CHECK(args == std::vector<std::string>({"--device-type", "rtlsdr", "--gain", "42.1", "--ppm", "-3",
                                            "--net", "--net-bind-address", "127.0.0.1", "--net-bo-port",
                                            "30005", "--write-json", "/rt/readsb", "--write-json-every",
                                            "1", "--quiet", "--lat", "45.464211", "--lon", "9.191383"}));
    r.gain = "51"; // not a readsb step: never passed on
    CHECK_EQ(readsb_args(r, "/x")[3], std::string("auto"));
}

static void test_settings_round_trip() {
    FeederConfig cfg;
    cfg.sharing_key = "abcdef0123456789";
    cfg.email = "matteo@example.it";
    cfg.has_location = true;
    cfg.lat = 45.464211;
    cfg.lon = 9.191383;
    cfg.location_label = "Milano, IT";
    cfg.has_altitude = true;
    cfg.altitude_ft = 400;
    cfg.mlat = true;
    cfg.gain = "42.1";
    cfg.ppm = -3;

    const FeederConfig back = parse_settings(serialize_settings(cfg));
    CHECK_EQ(back.sharing_key, cfg.sharing_key);
    CHECK_EQ(back.email, cfg.email);
    CHECK(back.has_location);
    CHECK(back.lat > 45.46421 && back.lat < 45.46422);
    CHECK(back.lon > 9.19138 && back.lon < 9.19139);
    CHECK_EQ(back.location_label, cfg.location_label);
    CHECK(back.has_altitude);
    CHECK_EQ(back.altitude_ft, 400);
    CHECK(back.mlat);
    CHECK_EQ(back.gain, std::string("42.1"));
    CHECK_EQ(back.ppm, -3);

    // Bad values fall back to "not set" instead of something wrong.
    const FeederConfig bad = parse_settings(
        "sharing_key=short\nemail=nope\nlat=95\nlon=9\naltitude_ft=abc\ngain=51\nppm=999\nmlat=maybe\n");
    CHECK(bad.sharing_key.empty());
    CHECK(bad.email.empty());
    CHECK(!bad.has_location);
    CHECK(!bad.has_altitude);
    CHECK_EQ(bad.gain, std::string("auto"));
    CHECK_EQ(bad.ppm, 0);
    CHECK(!bad.mlat);

    // On disk, atomically, into a fresh directory.
    char tmpl[] = "/tmp/zeroairfeeder-test-XXXXXX";
    const char* dir = ::mkdtemp(tmpl);
    CHECK(dir != nullptr);
    if (dir) {
        const std::filesystem::path path = std::filesystem::path(dir) / "sub" / "settings.ini";
        CHECK(!load_settings(path).has_value());
        CHECK(save_settings(path, cfg));
        const auto loaded = load_settings(path);
        CHECK(loaded.has_value());
        if (loaded) CHECK_EQ(loaded->sharing_key, cfg.sharing_key);
        CHECK(!std::filesystem::exists(path.string() + ".tmp"));
        FeederConfig nl = cfg;
        nl.email = "a@b.it\nsharing_key=evil";
        CHECK(!save_settings(path, nl)); // one value per line, always
        std::filesystem::remove_all(dir);
    }

    FeederConfig empty;
    CHECK(missing_for_feeding(empty) == Field::Key);
    CHECK(missing_for_signup(empty) == Field::Email);
    empty.sharing_key = cfg.sharing_key;
    CHECK(missing_for_feeding(empty) == Field::None); // the position is optional
    CHECK(missing_for_feeding(cfg) == Field::None);
    CHECK(missing_for_signup(cfg) == Field::None);
    empty.email = cfg.email;
    CHECK(missing_for_signup(empty) == Field::Location);
}

static void test_decoder_txt() {
    const std::string text =
        "time_update_utc=2026-11-26 18:10:07\n"
        "time_update_utc_s=1795716607\n"
        "feed_status=connected\n"
        "feed_status_message=\n"
        "feed_current_mode=UDP\n"
        "feed_alias=T-LIML123\n"
        "feed_num_ac_tracked=17\n"
        "rx_connected=1\n"
        "num_messages=48211\n"
        "num_resyncs=0\n"
        "mlat-ok=YES\n"
        "mlat-mode=UDP\n"
        "build_version=1.0.57-1\n";
    const Fr24Status st = parse_decoder_txt(text);
    CHECK(st.present);
    CHECK_EQ(st.updated_utc, static_cast<int64_t>(1795716607));
    CHECK(st.connected());
    CHECK_EQ(st.radar_id(), std::string("T-LIML123"));
    CHECK_EQ(st.tracked(), std::string("17"));
    CHECK(st.receiver_connected());
    CHECK_EQ(st.messages(), std::string("48211"));
    CHECK(st.mlat_ok());
    CHECK_EQ(st.version(), std::string("1.0.57-1"));
    CHECK_EQ(st.feed_message(), std::string(""));
    CHECK(is_fresh(st, 1795716607 + 20));
    CHECK(!is_fresh(st, 1795716607 + 200));
    CHECK(!is_fresh(Fr24Status{}, 1795716607));

    const Fr24Status down = parse_decoder_txt("feed_status=connecting\nrx_connected=0\n");
    CHECK(down.present && !down.connected() && !down.receiver_connected());
    CHECK(!is_fresh(down, 1795716607)); // no timestamp: never fresh
    CHECK(!parse_decoder_txt("").present);
}

static void test_aircraft_json() {
    const std::string json = R"({ "now" : 1795716607.1,
      "messages" : 123456,
      "aircraft" : [
        {"hex":"4ca7b5","flight":"RYR12AB ","alt_baro":34000,"lat":45.1,"lon":9.2,"seen":0.4},
        {"hex":"3c6586","alt_baro":12000,"seen":2.0},
        {"hex":"440123","lat":45.0,"lon":9.0,"seen":75.0},
        "garbage"
      ]})";
    const AircraftSummary s = parse_aircraft_json(json);
    CHECK(s.present);
    CHECK_EQ(s.aircraft, 2);
    CHECK_EQ(s.with_position, 1);
    CHECK(s.messages == 123456.0);
    CHECK(s.now > 1795716607.0);
    CHECK(!parse_aircraft_json("{not json").present);
    CHECK(!parse_aircraft_json("").present);
    const AircraftSummary none = parse_aircraft_json(R"({"now":1,"aircraft":[]})");
    CHECK(none.present && none.aircraft == 0);
}

static void test_other_services() {
    // Codes and keys: letters and digits only (nothing else reaches the files).
    CHECK(valid_pf_sharecode("zg84632abhf231"));
    CHECK(!valid_pf_sharecode("short"));
    CHECK(!valid_pf_sharecode("zg84632abhf231\n--x"));
    CHECK(!valid_pf_sharecode("zg84632 abhf231"));
    CHECK(valid_rb_key("g45643ab345af3c5d5g923a99ffc0de9"));
    CHECK(!valid_rb_key("g45643ab345af3c5d5g923a99ffc0de9\nkey=evil"));
    CHECK(!valid_rb_key("abc"));
    CHECK(!valid_rb_key(""));

    FeederConfig cfg;
    cfg.sharing_key = "0123456789abcdef";
    cfg.has_location = true;
    cfg.lat = 45.4642;
    cfg.lon = 9.19;
    cfg.has_altitude = true;
    cfg.altitude_ft = 400;
    cfg.rb_key = "g45643ab345af3c5d5g923a99ffc0de9";
    CHECK_EQ(render_rbfeeder_ini(cfg, "/run/user/1000/zeroairfeeder"),
             std::string("[client]\n"
                         "network_mode=true\n"
                         "log_file=/run/user/1000/zeroairfeeder/rbfeeder.log\n"
                         "key=g45643ab345af3c5d5g923a99ffc0de9\n"
                         "lat=45.464200\n"
                         "lon=9.190000\n"
                         "alt=122\n"
                         "use_gnss=false\n"
                         "\n[network]\n"
                         "mode=beast\n"
                         "external_host=127.0.0.1\n"
                         "external_port=30005\n"
                         "\n[mlat]\n"
                         "autostart_mlat=false\n"));
    FeederConfig bare;
    bare.rb_key = "bad key";
    const std::string ini = render_rbfeeder_ini(bare, "/rt");
    CHECK(ini.find("key=\n") != std::string::npos); // rbfeeder makes one
    CHECK(ini.find("\nlat=") == std::string::npos);

    cfg.pf_sharecode = "zg84632abhf231";
    CHECK(pfclient_args(cfg, "/rt") ==
          std::vector<std::string>({"--connection_type=1", "--address=127.0.0.1", "--port=30005",
                                    "--data_format=1", "--sharecode=zg84632abhf231", "--lat=45.464200",
                                    "--lon=9.190000", "--pid_file=/rt/pfclient.pid",
                                    "--config_path=/rt/pfclient-config.json", "--log_path=/rt/pfclient-log",
                                    "--web_port=30053"}));

    // Settings: the services round-trip; older files keep FR24 on.
    cfg.pf_enabled = true;
    cfg.rb_enabled = true;
    cfg.fr24_enabled = false;
    const FeederConfig back = parse_settings(serialize_settings(cfg));
    CHECK(!back.fr24_enabled && back.pf_enabled && back.rb_enabled);
    CHECK_EQ(back.pf_sharecode, cfg.pf_sharecode);
    CHECK_EQ(back.rb_key, cfg.rb_key);
    const FeederConfig old = parse_settings("version=1\nsharing_key=0123456789abcdef\n");
    CHECK(old.fr24_enabled && !old.pf_enabled && !old.rb_enabled);
    CHECK(parse_settings("pf_sharecode=a;b\nrb_key=x\n").pf_sharecode.empty());

    // What feeding needs, service by service.
    FeederConfig f;
    f.fr24_enabled = false;
    CHECK(missing_for_feeding(f) == Field::NoService);
    f.rb_enabled = true;
    CHECK(missing_for_feeding(f) == Field::None); // AirNav makes its own key
    f.pf_enabled = true;
    CHECK(missing_for_feeding(f) == Field::PfShareCode);
    f.pf_sharecode = "zg84632abhf231";
    CHECK(missing_for_feeding(f) == Field::Location);
    f.has_location = true;
    CHECK(missing_for_feeding(f) == Field::None);
    f.fr24_enabled = true;
    CHECK(missing_for_feeding(f) == Field::Key);
}

static void test_pf_stats() {
    const PfStats st = parse_pf_stats(
        R"({"executable_start_time":1795774681.28,"client_version":"5.3.31 arm64","total_modes_packets":812,)"
        R"("master_server_bytes_out":5120,"receiver_bytes_in":40960,"total_modes_types":{}})");
    CHECK(st.present);
    CHECK_EQ(st.version, std::string("5.3.31 arm64"));
    CHECK(st.modes_packets == 812 && st.server_bytes_out == 5120 && st.receiver_bytes_in == 40960);
    CHECK(!parse_pf_stats("").present);
    CHECK(!parse_pf_stats("<html>").present);
}

static void test_rbfeeder_log() {
    // rbfeeder 1.0.17's own lines.
    const std::string log =
        "[2026-11-27 10:22:21]  Starting RBFeeder Version 1.0.17 (build 20260808100000)\n"
        "[2026-11-27 10:22:21]  Using configuration file: /rt/rbfeeder.ini\n"
        "[2026-11-27 10:22:22]  Can't connect to AirNav Server. Retry in 60 seconds.\n";
    RbStatus st = parse_rbfeeder_log(log);
    CHECK(st.present && st.link == RbStatus::Link::Disconnected && !st.key_accepted);
    st = parse_rbfeeder_log(log +
        "[2026-11-27 10:23:22]  External host connected!\n"
        "[2026-11-27 10:23:23]  Your new key is 0f1e2d3c4b5a69788796a5b4c3d2e1f0. Please save this key for future use.\n"
        "[2026-11-27 10:23:23]  Connection with RadarBox24 server OK! Key accepted by server.\n"
        "[2026-11-27 10:23:23]  This is your station serial number: EXTRPI012345\n"
        "[2026-11-27 10:24:23]  Packets sent in the last 60 seconds: 812, Total packets sent since startup: 1907\n");
    CHECK(st.link == RbStatus::Link::Connected && st.key_accepted && st.receiver == 1);
    CHECK_EQ(st.new_key, std::string("0f1e2d3c4b5a69788796a5b4c3d2e1f0"));
    CHECK_EQ(st.station, std::string("EXTRPI012345"));
    CHECK_EQ(st.packets_total, 1907LL);
    CHECK(!parse_rbfeeder_log("").present);
    CHECK(parse_rbfeeder_log("Your new key is ab;cd. x\n").new_key.empty());
}

int main() {
    test_validation();
    test_ini();
    test_settings_round_trip();
    test_decoder_txt();
    test_aircraft_json();
    test_other_services();
    test_pf_stats();
    test_rbfeeder_log();
    return test_result("feeder_core_test");
}
