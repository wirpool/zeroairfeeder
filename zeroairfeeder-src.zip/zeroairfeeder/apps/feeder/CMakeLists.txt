#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#

# ====================================================
# feeder_core — pure logic (config, fr24feed monitor file, aircraft.json, the
# signup wizard driver) plus the processes (readsb and fr24feed as children of
# the app, the jobs), in a static lib so the tests link it without LVGL.
# ====================================================
add_library(feeder_core STATIC
    ${CMAKE_CURRENT_SOURCE_DIR}/src/core/feeder_config.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/core/fr24_status.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/core/signup_script.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/sys/child_process.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/sys/signup_runner.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/sys/feeder_system.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/src/sys/supervised_process.cpp
)
target_include_directories(feeder_core PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/src/core
    ${CMAKE_CURRENT_SOURCE_DIR}/src/sys
)
target_link_libraries(feeder_core PUBLIC nlohmann_json::nlohmann_json Threads::Threads)
# forkpty(): libutil on older glibc, libc itself since glibc 2.34.
find_library(ZF_UTIL_LIBRARY util)
if(ZF_UTIL_LIBRARY)
    target_link_libraries(feeder_core PUBLIC ${ZF_UTIL_LIBRARY})
endif()
target_compile_options(feeder_core PRIVATE -Wall -Wextra)

if(USE_DESKTOP)
    add_executable(feeder_core_test ${CMAKE_CURRENT_SOURCE_DIR}/test/feeder_core_test.cpp)
    target_include_directories(feeder_core_test PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/test)
    target_link_libraries(feeder_core_test PRIVATE feeder_core)
    add_test(NAME feeder_core_test COMMAND feeder_core_test)

    add_executable(signup_test ${CMAKE_CURRENT_SOURCE_DIR}/test/signup_test.cpp)
    target_include_directories(signup_test PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/test)
    target_link_libraries(signup_test PRIVATE feeder_core)
    target_compile_definitions(signup_test PRIVATE
        MOCK_WIZARD="${CMAKE_CURRENT_SOURCE_DIR}/assets/mock/mock-signup-wizard.sh")
    add_test(NAME signup_test COMMAND signup_test)

    add_executable(system_test ${CMAKE_CURRENT_SOURCE_DIR}/test/system_test.cpp)
    target_include_directories(system_test PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/test)
    target_link_libraries(system_test PRIVATE feeder_core)
    target_compile_definitions(system_test PRIVATE MOCK_DIR="${CMAKE_CURRENT_SOURCE_DIR}/assets/mock")
    add_test(NAME system_test COMMAND system_test)

    # The privileged helper against a fake, locally signed repository.
    add_test(NAME ctl_helper_test
        COMMAND /bin/bash ${CMAKE_CURRENT_SOURCE_DIR}/test/ctl_helper_test.sh
                ${CMAKE_SOURCE_DIR}/system/zeroairfeeder-ctl)
endif()

# ====================================================
# zeroairfeeder_app — the LVGL app
# ====================================================
file(GLOB_RECURSE FEEDER_APP_SOURCES CONFIGURE_DEPENDS
    "${CMAKE_CURRENT_SOURCE_DIR}/src/app/*.cpp"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/viewmodel/*.cpp"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/view/*.cpp"
)
add_executable(zeroairfeeder_app
    ${CMAKE_CURRENT_SOURCE_DIR}/src/main.cpp
    ${FEEDER_APP_SOURCES}
)
target_include_directories(zeroairfeeder_app PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/src
    ${CMAKE_CURRENT_SOURCE_DIR}/src/app
    ${CMAKE_CURRENT_SOURCE_DIR}/src/viewmodel
    ${CMAKE_CURRENT_SOURCE_DIR}/src/view
)
target_compile_definitions(zeroairfeeder_app PRIVATE
    ZF_MOCK_DIR="$<IF:$<BOOL:${CMAKE_CROSSCOMPILING}>,/usr/share/zeroairfeeder/mock,${CMAKE_CURRENT_SOURCE_DIR}/assets/mock>"
    ZF_INSTALL_DIR="/usr/share/zeroairfeeder"
    # The desktop simulator runs on the mock helper and sample data by default
    # (ZEROAIRFEEDER_MOCK=0 to use the real helper); the device on the real ones
    # (ZEROAIRFEEDER_MOCK=1 for a demo).
    ZF_DEFAULT_MOCK=$<IF:$<BOOL:${CMAKE_CROSSCOMPILING}>,0,1>
)
target_link_libraries(zeroairfeeder_app PRIVATE feeder_core radio_toolkit lvgl)
