#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# Stand-in for Plane Finder's pfclient (simulator and tests): takes pfclient's
# options, writes its pid file and serves /ajax/stats on --web_port like
# pfclient 5.3.31, with byte counters that grow once it "connected" (2 s).
set -u
port=30053; pidfile=""; code=""
for a in "$@"; do
    case "$a" in
        --web_port=*) port="${a#--web_port=}" ;;
        --pid_file=*) pidfile="${a#--pid_file=}" ;;
        --sharecode=*) code="${a#--sharecode=}" ;;
    esac
done
echo "pfclient (5.3.31 arm64) started with the following options:"
echo "	web_server_port = $port"
[ -n "$code" ] || { echo "No sharecode set"; exit 1; }
[ -n "$pidfile" ] && echo $$ > "$pidfile"
exec python3 -I -c '
import http.server, json, signal, sys, time
start = time.time()
signal.signal(signal.SIGTERM, lambda *a: sys.exit(0))
class H(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path != "/ajax/stats":
            self.send_error(404); return
        up = max(0.0, time.time() - start - 2)
        body = json.dumps({"client_version": "5.3.31 arm64",
            "total_modes_packets": int(up * 90), "receiver_bytes_in": int(up * 4000),
            "master_server_bytes_out": int(up * 700)}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body)
http.server.HTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
' "$port"
