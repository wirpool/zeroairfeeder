/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "lvgl.h"

#include <functional>
#include <string>

namespace app {
class AssetManager;
}

namespace feeder::view {

// Full-screen modal for one line of text (sharing key, e-mail, altitude), in
// the style of the toolkit's LocationDialog. Captures the keyboard in text mode
// while open. Enter validates and applies, Esc cancels, Backspace deletes.
//
// Callbacks run after the dialog closed itself; the owner must not destroy the
// object from inside a callback (FeederScreen parks closed dialogs and frees
// them on its next tick).
class TextEntryDialog {
public:
    struct Options {
        std::string title;
        std::string initial;
        std::string hint;                               // footer line
        size_t max_len = 64;
        std::function<bool(char)> accept;               // which characters to take
        std::function<std::string(const std::string&)> validate; // "" = fine, else the error
        bool tab_types_at = false;                      // TAB types '@' (e-mail)
    };
    using OnApply = std::function<void(const std::string&)>;

    TextEntryDialog(app::AssetManager& assets, bool dark_mode, Options options, OnApply on_apply);
    ~TextEntryDialog();
    TextEntryDialog(const TextEntryDialog&) = delete;
    TextEntryDialog& operator=(const TextEntryDialog&) = delete;

    bool is_open() const { return root_ != nullptr; }

private:
    static void key_cb(uint32_t key, void* ctx);
    void on_key(uint32_t key);
    void render();
    void close();

    Options options_;
    OnApply on_apply_;
    bool dark_;
    std::string text_;
    std::string error_;

    lv_obj_t* root_ = nullptr;
    lv_obj_t* input_ = nullptr;
    lv_obj_t* error_label_ = nullptr;
};

// Full-screen panel with a title, a body that can change (live progress) and a
// footer line. Captures the keyboard (not in text mode: F/X/Z/C are arrows)
// and hands every key to `on_key`; the owner decides when to close().
class PanelDialog {
public:
    using OnKey = std::function<void(uint32_t key)>;

    PanelDialog(app::AssetManager& assets, bool dark_mode, const std::string& title,
                const std::string& body, const std::string& footer, OnKey on_key);
    ~PanelDialog();
    PanelDialog(const PanelDialog&) = delete;
    PanelDialog& operator=(const PanelDialog&) = delete;

    void set_title(const std::string& text);
    void set_body(const std::string& text);
    void set_footer(const std::string& text);
    void set_accent(lv_color_t color); // title colour (ok / error)
    // A QR code of `data`, `size` px, on the right of the body (the body
    // narrows to make room).
    void add_qr(const std::string& data, int32_t size);
    void close();
    bool is_open() const { return root_ != nullptr; }

private:
    static void key_cb(uint32_t key, void* ctx);

    OnKey on_key_;
    std::string body_;
    lv_obj_t* root_ = nullptr;
    lv_obj_t* title_ = nullptr;
    lv_obj_t* body_label_ = nullptr;
    lv_obj_t* footer_ = nullptr;
};

} // namespace feeder::view
