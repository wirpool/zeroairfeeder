/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "child_process.h"

#include "signup_script.h" // strip_ansi

#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <poll.h>
#include <pty.h>
#include <sys/prctl.h>
#include <sys/wait.h>
#include <termios.h>
#include <thread>
#include <unistd.h>

namespace feeder {
namespace {

[[noreturn]] void exec_child(const std::vector<std::string>& argv, pid_t parent,
                             const ChildProcess::Env& env) {
    // The app's own death must not leave a helper running (same idea as the
    // toolkit's Subprocess). If the app died before prctl(), go now.
    ::prctl(PR_SET_PDEATHSIG, SIGTERM);
    if (::getppid() != parent) ::_exit(1);
    for (const auto& [k, v] : env) ::setenv(k.c_str(), v.c_str(), 1);
    ::setenv("LC_ALL", "C", 1);
    ::setenv("TERM", "dumb", 1);
    ::setenv("DEBIAN_FRONTEND", "noninteractive", 1);
    std::vector<char*> args;
    args.reserve(argv.size() + 1);
    for (const auto& a : argv) args.push_back(const_cast<char*>(a.c_str()));
    args.push_back(nullptr);
    ::execvp(args[0], args.data());
    const char msg[] = "exec failed\n";
    (void)!::write(STDERR_FILENO, msg, sizeof(msg) - 1);
    ::_exit(127);
}

} // namespace

ChildProcess::~ChildProcess() {
    if (pid_ > 0 && !reaped_) {
        terminate();
        wait();
    }
    if (fd_ >= 0) ::close(fd_);
}

bool ChildProcess::start(const std::vector<std::string>& argv, bool pty, std::string* error,
                         const Env& env) {
    const pid_t parent = ::getpid();
    if (argv.empty() || pid_ > 0) {
        if (error) *error = "bad command";
        return false;
    }
    if (pty) {
        int master = -1;
        const pid_t pid = ::forkpty(&master, nullptr, nullptr, nullptr);
        if (pid < 0) {
            if (error) *error = std::string("forkpty: ") + std::strerror(errno);
            return false;
        }
        if (pid == 0) {
            termios t{};
            if (::tcgetattr(STDIN_FILENO, &t) == 0) {
                t.c_lflag &= ~static_cast<tcflag_t>(ECHO | ECHONL);
                t.c_oflag &= ~static_cast<tcflag_t>(ONLCR);
                ::tcsetattr(STDIN_FILENO, TCSANOW, &t);
            }
            exec_child(argv, parent, env);
        }
        pid_ = pid;
        fd_ = master;
    } else {
        int fds[2];
        if (::pipe2(fds, O_CLOEXEC) != 0) {
            if (error) *error = std::string("pipe: ") + std::strerror(errno);
            return false;
        }
        const pid_t pid = ::fork();
        if (pid < 0) {
            ::close(fds[0]);
            ::close(fds[1]);
            if (error) *error = std::string("fork: ") + std::strerror(errno);
            return false;
        }
        if (pid == 0) {
            ::setpgid(0, 0); // own group, so terminate() reaches grandchildren too
            const int devnull = ::open("/dev/null", O_RDONLY);
            if (devnull >= 0) ::dup2(devnull, STDIN_FILENO);
            ::dup2(fds[1], STDOUT_FILENO);
            ::dup2(fds[1], STDERR_FILENO);
            exec_child(argv, parent, env);
        }
        ::close(fds[1]);
        pid_ = pid;
        fd_ = fds[0];
    }
    const int flags = ::fcntl(fd_, F_GETFL);
    ::fcntl(fd_, F_SETFL, flags | O_NONBLOCK);
    ::fcntl(fd_, F_SETFD, FD_CLOEXEC);
    return true;
}

int ChildProcess::read(std::string& out, int timeout_ms) {
    if (fd_ < 0) return -1;
    pollfd p{fd_, POLLIN, 0};
    const int r = ::poll(&p, 1, timeout_ms);
    if (r == 0) return 0;
    if (r < 0) return errno == EINTR ? 0 : -1;
    char buf[2048];
    const ssize_t n = ::read(fd_, buf, sizeof(buf));
    if (n > 0) {
        out.append(buf, static_cast<size_t>(n));
        return static_cast<int>(n);
    }
    if (n < 0 && (errno == EAGAIN || errno == EINTR)) return 0;
    return -1; // EOF, or EIO on a pty once the child closed it
}

bool ChildProcess::write_line(const std::string& line) {
    if (fd_ < 0) return false;
    const std::string data = line + "\n";
    size_t off = 0;
    for (int tries = 0; off < data.size() && tries < 50; ++tries) {
        const ssize_t n = ::write(fd_, data.data() + off, data.size() - off);
        if (n > 0) {
            off += static_cast<size_t>(n);
        } else if (n < 0 && (errno == EAGAIN || errno == EINTR)) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        } else {
            return false;
        }
    }
    return off == data.size();
}

void ChildProcess::terminate() {
    if (pid_ <= 0 || reaped_) return;
    // forkpty makes the child a session leader and setpgid() a group leader, so
    // its pid is also its group id.
    ::kill(-pid_, SIGTERM);
    ::kill(pid_, SIGTERM);
    for (int i = 0; i < 40; ++i) {
        int status = 0;
        const pid_t r = ::waitpid(pid_, &status, WNOHANG);
        if (r == pid_) {
            reaped_ = true;
            status_ = status;
            return;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    ::kill(-pid_, SIGKILL);
    ::kill(pid_, SIGKILL);
}

int ChildProcess::wait() {
    if (pid_ <= 0) return -1;
    if (!reaped_) {
        int status = 0;
        pid_t r;
        do {
            r = ::waitpid(pid_, &status, 0);
        } while (r < 0 && errno == EINTR);
        if (r != pid_) return -1;
        reaped_ = true;
        status_ = status;
    }
    if (WIFEXITED(status_)) return WEXITSTATUS(status_);
    if (WIFSIGNALED(status_)) return 128 + WTERMSIG(status_);
    return -1;
}

CommandResult run_command(const std::vector<std::string>& argv, int timeout_s,
                          const std::atomic<bool>* cancel,
                          const std::function<void(const std::string&)>& on_output,
                          const ChildProcess::Env& env) {
    CommandResult result;
    ChildProcess child;
    std::string error;
    if (!child.start(argv, /*pty=*/false, &error, env)) {
        result.output = error;
        return result;
    }
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(timeout_s);
    std::string raw;
    bool stopped = false;
    int stop_code = 0;
    for (;;) {
        std::string chunk;
        const int r = child.read(chunk, 200);
        if (r > 0) {
            const std::string clean = strip_ansi(chunk);
            raw += clean;
            if (raw.size() > 256 * 1024) raw.erase(0, raw.size() - 128 * 1024);
            if (on_output) on_output(clean);
        } else if (r < 0) {
            break;
        }
        if (cancel && cancel->load()) {
            stop_code = 130;
            stopped = true;
            break;
        }
        if (std::chrono::steady_clock::now() > deadline) {
            stop_code = 124;
            stopped = true;
            break;
        }
    }
    if (stopped) {
        child.terminate();
        child.wait();
        result.exit_code = stop_code;
    } else {
        result.exit_code = child.wait();
    }
    result.output = std::move(raw);
    return result;
}

} // namespace feeder
