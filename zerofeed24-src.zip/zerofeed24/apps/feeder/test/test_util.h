/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <cstdio>

// Tiny check harness: every failed CHECK prints its line, main() returns the count.
inline int g_failures = 0;

#define CHECK(cond)                                                              \
    do {                                                                         \
        if (!(cond)) {                                                           \
            ++g_failures;                                                        \
            std::fprintf(stderr, "%s:%d: CHECK failed: %s\n", __FILE__, __LINE__, \
                         #cond);                                                 \
        }                                                                        \
    } while (0)

#define CHECK_EQ(a, b)                                                                 \
    do {                                                                               \
        const auto& va_ = (a);                                                         \
        const auto& vb_ = (b);                                                         \
        if (!(va_ == vb_)) {                                                           \
            ++g_failures;                                                              \
            std::fprintf(stderr, "%s:%d: CHECK_EQ failed: %s == %s\n", __FILE__, __LINE__, \
                         #a, #b);                                                      \
        }                                                                              \
    } while (0)

inline int test_result(const char* name) {
    if (g_failures == 0) std::printf("%s: all checks passed\n", name);
    else std::printf("%s: %d check(s) FAILED\n", name, g_failures);
    return g_failures == 0 ? 0 : 1;
}
