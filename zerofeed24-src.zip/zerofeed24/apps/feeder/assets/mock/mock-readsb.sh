#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
#
# SPDX-License-Identifier: MIT
#
# Stand-in for readsb (simulator and tests): writes the sample aircraft.json
# into --write-json <dir> every second.
#   MOCK_NO_DONGLE=1   exit like readsb without an RTL-SDR dongle
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
dir=""
while [ $# -gt 0 ]; do
    case "$1" in --write-json) dir="$2"; shift ;; esac
    shift
done
if [ "${MOCK_NO_DONGLE:-0}" = 1 ]; then
    echo "rtlsdr: no supported devices found."
    exit 1
fi
[ -n "$dir" ] || { echo "no --write-json"; exit 2; }
trap 'exit 0' TERM INT
echo "readsb version: 3.16.16 (mock)"
while :; do
    sed "s/\"now\": [0-9.]*/\"now\": $(date +%s).0/" "$HERE/aircraft.json" > "$dir/aircraft.json.tmp" &&
        mv -f "$dir/aircraft.json.tmp" "$dir/aircraft.json"
    sleep 1 & wait $!
done
