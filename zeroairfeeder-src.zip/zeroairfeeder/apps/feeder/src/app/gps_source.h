/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "location.h"

#include <chrono>
#include <memory>
#include <optional>
#include <string>

namespace feeder {

// The antenna position and altitude, from the GPS of the M5Stack Cap
// LoRa-1262 (the toolkit's GnssReader: it powers the HAT 5 V rail, wakes the
// module and reads NMEA on /dev/ttyS0; a USB GPS works too). Runs while the app
// is open, stops (and restores the rail) with it.
class GpsSource {
public:
    struct Status {
        bool searching = true;          // still looking for the receiver
        bool receiver = false;          // a receiver is answering
        std::string source;             // "shield" (the Cap) or "USB"
        int satellites = 0;
        std::optional<toolkit::geo::LatLon> fix;
        std::optional<double> altitude_m; // above mean sea level
    };

    virtual ~GpsSource() = default;
    virtual Status status() const = 0;

    // The Cap's GPS, or in mock mode (simulator) a fake one from
    // ZEROAIRFEEDER_MOCK_GPS="lat,lon,alt_m" ("none": no receiver) that gets its
    // fix after 3 s.
    static std::unique_ptr<GpsSource> create(bool mock);
};

} // namespace feeder
