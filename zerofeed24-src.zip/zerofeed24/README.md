# ZeroFeed24

Feed ADS-B aircraft data from the **M5Stack CardputerZero** to **Flightradar24**.
Plug an RTL-SDR dongle with a 1090 MHz antenna into the USB-A port, fit the M5Stack Cap
LoRa-1262 (its GPS gives the antenna position), enter your FR24 sharing key (or get one from
the app) and start feeding. Feeding runs only while the app is open.

<p>
<img src="docs/media/feed.png" width="320" alt="FEED page">
<img src="docs/media/fr24.png" width="320" alt="FR24 page">
</p>

Built on the toolkit of [ZeroRadio](https://github.com/andreahaku/zeroradio) (same
look, same keys, same shared position) and on Flightradar24's own feeder.

## How it works

```
RTL-SDR ──► readsb ──Beast 127.0.0.1:30005──► fr24feed ──► Flightradar24
              │ aircraft.json                     │ decoder.txt (status)
              └─────────────► ZeroFeed24 app ◄────┘
                   (both are children of the app)      Cap LoRa-1262 GPS ──► position, altitude
```

- **Nothing runs in the background.** readsb and fr24feed are child processes of the app,
  started only when you press 5 on the FEED page. They stop when you press 5 again or close
  the app, and the kernel stops them if the app is killed (`PR_SET_PDEATHSIG`). No service,
  nothing at boot.
- **readsb** (bundled, GPL-3.0) decodes 1090 MHz from the dongle and serves Beast on
  127.0.0.1:30005 only.
- **fr24feed** is Flightradar24's official program, used unmodified, configured as
  `receiver="beast-tcp"`, `host="127.0.0.1:30005"` (FR24's own setup for an external decoder).
  It runs as your user, with its config, monitor file, pid and logs in
  `$XDG_RUNTIME_DIR/zerofeed24/` (checked with fr24feed 1.0.57 on arm64).
- **Position and altitude** come from the GPS of the **M5Stack Cap LoRa-1262** (ZeroRadio's
  reader: it powers the HAT 5 V rail and reads NMEA on `/dev/ttyS0`; a USB GPS works too). They
  go to readsb and to the FR24 signup. Without a fix you can set them by hand.

## The app

Three pages, key 4 switches (hold 4 for the previous one), H opens the help.

| Page | What | Keys |
| --- | --- | --- |
| **FEED** | link to FR24, radar ID, aircraft sent/heard, receiver, GPS, MLAT | 5 start/stop, 6 log, 7 theme, 8 close |
| **FR24** | sharing key, e-mail, GPS position and altitude, MLAT, *Get a new key*, *Save* | F/X move, Enter or 7 edit, 8 save |
| **SETUP** | fr24feed (install / update), receiver gain, PPM, theme, language, log, about | F/X move, Z/C change, 8 save |

- **Sharing key**: 16 letters or digits, from flightradar24.com > Account > Data sharing.
  If `/etc/fr24feed.ini` from an earlier fr24feed install has one, the app takes it.
- **Get a new key** runs FR24's own signup wizard (`fr24feed --signup --adsb`) as your user and
  answers it (e-mail, GPS position and altitude, MLAT, Beast on 127.0.0.1:30005). The key
  appears on screen and FR24 e-mails it to you.
- **E-mail**: Tab types `@` (Shift+2 works too if the keyboard sends it).
- **MLAT** is off by default: it needs a fixed antenna and a precise position.

## Install

On the CardputerZero (Debian trixie, arm64), from the store or by hand:

```bash
cp zerofeed24_1.0.0_arm64.deb /tmp/ && sudo apt install /tmp/zerofeed24_1.0.0_arm64.deb
```

At its first start the app downloads fr24feed by itself (it needs internet once) into
`~/.local/share/zerofeed24/fr24feed/`. SETUP > fr24feed > Enter does it again, or updates it.

### What the package changes on the system

Only its own files: no maintainer scripts, no service, no sudo rule, nothing run as root.

| Path | What |
| --- | --- |
| `/usr/share/zerofeed24/bin/` | the app, `readsb`, `zerofeed24-ctl` (fr24feed downloader) |
| `/usr/share/zerofeed24/flightradar24.gpg` | Flightradar24's repository key |
| `/usr/share/APPLaunch/...` | launcher entry and icon |
| `~/.local/share/zerofeed24/fr24feed/` | fr24feed, its version and licences (downloaded by the app) |
| `~/.config/zerofeed24/` | settings, theme, language |

`zerofeed24-ctl install-fr24feed` runs as the app's user and checks the download the way apt
does: `InRelease` signed with Flightradar24's key (fingerprint
`B35C 96E2 E7F2 C2C7 3274 120F C969 F078 40C4 30F5`), then the SHA256 of the package index and
of the `.deb`. It only extracts the `fr24feed` binary: FR24's package, with its service and
daily updater, is **not** installed, so nothing of FR24 runs in the background either.

Uninstall: `sudo apt remove zerofeed24`. apt never touches home directories: to remove the
downloaded fr24feed and the settings too, `rm -r ~/.local/share/zerofeed24 ~/.config/zerofeed24`.

## Notes

- **One program per dongle.** While ZeroFeed24 is open and feeding, ZeroRadio's SDR/ADS-B
  apps cannot open the dongle; on the CardputerZero only one app is open at a time anyway.
- While feeding, fr24feed shows its own status page on port 8754 to private networks:
  `http://<cardputer-ip>:8754`.
- FR24 allows 3 feeders per account; the radar ID (e.g. `T-LIML123`) appears once FR24 has
  accepted the feeder.

## Build

Same tooling as ZeroRadio.

```bash
# Desktop simulator (SDL window 320x170) with the mock helper and sample data
cmake --preset linux-x86-64 && cmake --build --preset linux-x86-64-dbg
./build/linux-x86-64/apps/feeder/Debug/zerofeed24_app      # ZEROFEED24_MOCK=0 for the real helper
ctest --test-dir build/linux-x86-64 -C Debug --output-on-failure

# Device build and .deb, in a Debian trixie container (needs Docker)
scripts/cp0-docker-build.sh --package                       # build/cp0-trixie/zerofeed24_<v>_arm64.deb
```

Maintainer: Wirpool <wirpool12@gmail.com>. Source: https://github.com/wirpool/zerofeed24

Tests: `feeder_core_test` (validation, ini files, settings, readsb arguments, fr24feed
monitor file, aircraft.json), `signup_test` (the wizard driver on FR24's real prompt texts,
then on a pseudo-terminal against a mock wizard that reads `/dev/tty` like fr24feed),
`system_test` (feeding with mock programs; nothing left running after stop, after the app
object goes away, or after the app is killed with SIGKILL), `ctl_helper_test` (the fr24feed
download against a locally signed fake repository: wrong signature, altered index or altered
`.deb` are refused), plus ZeroRadio's location (with the GGA altitude) and i18n tests.

## Layout

```
apps/feeder/src/core/        pure logic: config + validation, fr24feed/readsb status, signup script
apps/feeder/src/sys/         child processes and pty, supervised readsb/fr24feed, signup runner, FeederSystem
apps/feeder/src/app/         GPS source (Cap LoRa-1262 through the toolkit's GnssReader, or a mock)
apps/feeder/src/viewmodel/   FeederViewModel (pages, actions, NavBar)
apps/feeder/src/view/        FeederScreen, text entry and panel dialogs
apps/feeder/assets/mock/     sample data, mock readsb / fr24feed / helper / signup wizard
system/                      zerofeed24-ctl, Flightradar24's key, the launcher entry
toolkit/                     ZeroRadio's toolkit (MIT); text entry gained Shift/Caps (@, _, capitals),
                             the GPS reader gained the GGA altitude
```

## Italiano in breve

ZeroFeed24 invia a Flightradar24 gli aerei ricevuti dalla chiavetta RTL-SDR del
CardputerZero. Al primo avvio l'app scarica da sola fr24feed (il programma ufficiale di FR24,
firma verificata) nella cartella dell'utente: niente root, niente sudo. Posizione e
altitudine arrivano dal GPS del Cap LoRa-1262. Nella pagina FR24 inserisci la chiave di
condivisione (o registrati con "Ottieni una chiave"), poi premi 5 nella pagina FEED. La lingua (sistema, English, Italiano) si sceglie in SETUP > Lingua. L'invio
gira solo ad app aperta e si ferma quando la chiudi: niente in background, niente all'avvio.

## Licence

MIT (see LICENSE). readsb is GPL-3.0 and ships as a separate program. fr24feed is
Flightradar24's software under their licence and is not part of this package. Credits in
CREDITS.md.
