#!/bin/bash
#
# SPDX-FileCopyrightText: 2026 Wirpool
#
# SPDX-License-Identifier: MIT
#
# zeroairfeeder-ctl (run as a normal user) against fake, locally signed APT
# repositories and a local pfclient tarball (file:// URLs): it must install
# only what the signature or the pinned checksum covers.
#   ctl_helper_test.sh <zeroairfeeder-ctl>
# The checks are strings evaluated later (check), hence single quotes.
# shellcheck disable=SC2016,SC2034
set -u

CTL="$1"
fails=0
check() { if ! eval "$1"; then echo "FAIL: $1"; fails=$((fails + 1)); fi; }

for tool in gpg gpgv dpkg-deb curl sha256sum; do
    command -v "$tool" >/dev/null || { echo "SKIP: $tool missing"; exit 0; }
done

W="$(mktemp -d)"
trap 'rm -rf "$W"' EXIT
export GNUPGHOME="$W/gnupg"
mkdir -m 0700 "$GNUPGHOME"
gpg --batch --quiet --passphrase '' --quick-gen-key "Test Repo <repo@test>" rsa2048 sign never 2>/dev/null
gpg --batch --quiet --passphrase '' --quick-gen-key "Other <other@test>" rsa2048 sign never 2>/dev/null

gpg --batch --export "repo@test" > "$W/flightradar24.gpg"
export ZF_KEYRING="$W/flightradar24.gpg"
export ZF_ARCH=arm64
# As a normal user: the default destination is under the data directory.
export XDG_DATA_HOME="$W/data"
DEST="$XDG_DATA_HOME/zeroairfeeder/fr24feed"

REPO="$W/repo"
export ZF_REPO="file://$REPO"

make_deb() { # version -> pool path
    local v="$1" d="$W/pkg-$1"
    mkdir -p "$d/DEBIAN" "$d/usr/bin" "$d/usr/share/fr24/licences"
    printf 'Package: fr24feed\nVersion: %s\nArchitecture: arm64\nMaintainer: t <t@t>\nDescription: t\n' "$v" > "$d/DEBIAN/control"
    printf '#!/bin/sh\necho "fr24feed %s"\n' "$v" > "$d/usr/bin/fr24feed"
    chmod 0755 "$d/usr/bin/fr24feed"
    echo licence > "$d/usr/share/fr24/licences/LICENSE.fr24feed.txt"
    mkdir -p "$REPO/pool/raspberrypi-stable/f/fr24feed"
    dpkg-deb --build --root-owner-group "$d" "$REPO/pool/raspberrypi-stable/f/fr24feed/fr24feed_${v}_arm64.deb" >/dev/null
}

publish() { # signer -> Packages, Release, InRelease
    local signer="$1" idx="$REPO/dists/flightradar24/raspberrypi-stable/binary-arm64"
    mkdir -p "$idx"
    : > "$idx/Packages"
    for deb in "$REPO"/pool/raspberrypi-stable/f/fr24feed/*.deb; do
        local v rel
        v="$(dpkg-deb -f "$deb" Version)"
        rel="${deb#"$REPO"/}"
        printf 'Package: fr24feed\nVersion: %s\nArchitecture: arm64\nFilename: %s\nSize: %s\nSHA256: %s\n\n' \
            "$v" "$rel" "$(stat -c %s "$deb")" "$(sha256sum "$deb" | cut -d' ' -f1)" >> "$idx/Packages"
    done
    printf 'Package: dump978-fr24\nVersion: 9.9\nFilename: pool/x.deb\nSHA256: 00\n\n' >> "$idx/Packages"
    {
        printf 'Codename: flightradar24\nComponents: raspberrypi-stable\nMD5Sum:\n'
        printf ' %s %s raspberrypi-stable/binary-arm64/Packages\n' "$(md5sum "$idx/Packages" | cut -d' ' -f1)" "$(stat -c %s "$idx/Packages")"
        printf 'SHA256:\n'
        printf ' %s %s raspberrypi-stable/binary-arm64/Packages\n' "$(sha256sum "$idx/Packages" | cut -d' ' -f1)" "$(stat -c %s "$idx/Packages")"
    } > "$REPO/dists/flightradar24/Release"
    rm -f "$REPO/dists/flightradar24/InRelease"
    gpg --batch --quiet --yes --local-user "$signer" --clearsign \
        -o "$REPO/dists/flightradar24/InRelease" "$REPO/dists/flightradar24/Release"
}

make_deb 1.0.56-0
make_deb 1.0.57-1
publish repo@test

BIN="$DEST/fr24feed"

# --- the newest version, verified ---
out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 0 ]'
check '[[ "$out" == *"OK: fr24feed 1.0.57-1 installed"* ]]'
check '[ -x "$BIN" ]'
check '[ "$("$BIN")" = "fr24feed 1.0.57-1" ]'
check '[ "$(cat "$DEST/version")" = "1.0.57-1" ]'
check '[ -f "$DEST/licences/LICENSE.fr24feed.txt" ]'

out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [[ "$out" == *"already installed"* ]]'

# --- an update is picked up ---
make_deb 1.0.58-0
publish repo@test
out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [ "$("$BIN")" = "fr24feed 1.0.58-0" ]'

# --- index signed by another key: refused, nothing changes ---
rm -rf "$DEST"
publish other@test
out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"not signed by Flightradar24"* ]]'
check '[ ! -e "$BIN" ]'

# --- Packages changed after signing: refused ---
publish repo@test
echo "Package: evil" >> "$REPO/dists/flightradar24/raspberrypi-stable/binary-arm64/Packages"
out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"does not match its signature"* ]]'
check '[ ! -e "$BIN" ]'

# --- a .deb swapped after signing: refused ---
publish repo@test
cp "$REPO/pool/raspberrypi-stable/f/fr24feed/fr24feed_1.0.56-0_arm64.deb" \
   "$REPO/pool/raspberrypi-stable/f/fr24feed/fr24feed_1.0.58-0_arm64.deb"
out="$("$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"does not match the signed index"* ]]'
check '[ ! -e "$BIN" ]'

# --- no repository / no such architecture ---
out="$(ZF_REPO="file://$W/nothing" "$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -ne 0 ]'
out="$(ZF_ARCH=mips "$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"no fr24feed for mips"* ]]'

"$CTL" nonsense >/dev/null 2>&1; rc=$?
check '[ $rc -eq 64 ]'

# --- an explicit destination, and a missing keyring ---
publish repo@test
out="$("$CTL" install-fr24feed --dest "$W/other" 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [ -x "$W/other/fr24feed" ]'
out="$(ZF_KEYRING="$W/none.gpg" "$CTL" install-fr24feed 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"missing"* ]]'

# --- rbfeeder: AirNav's repository (dist trixie, component main) ---
gpg --batch --export "repo@test" > "$W/airnav.gpg"
export ZF_RB_KEYRING="$W/airnav.gpg"
RB="$W/rb"
export ZF_RB_REPO="file://$RB"
make_rb() { # version
    local v="$1" d="$W/rbpkg-$1"
    mkdir -p "$d/DEBIAN" "$d/usr/bin" "$d/usr/share/doc/rbfeeder"
    printf 'Package: rbfeeder\nVersion: %s\nArchitecture: arm64\nMaintainer: t <t@t>\nDescription: t\n' "$v" > "$d/DEBIAN/control"
    printf '#!/bin/sh\necho "rbfeeder %s"\n' "$v" > "$d/usr/bin/rbfeeder"
    printf '#!/bin/sh\necho dump\n' > "$d/usr/bin/dump1090-rb"
    chmod 0755 "$d/usr/bin/rbfeeder" "$d/usr/bin/dump1090-rb"
    echo copyright > "$d/usr/share/doc/rbfeeder/copyright"
    mkdir -p "$RB/pool/main/r/rbfeeder"
    dpkg-deb --build --root-owner-group "$d" "$RB/pool/main/r/rbfeeder/rbfeeder_${v#*:}_arm64.deb" >/dev/null
}
publish_rb() { # signer
    local idx="$RB/dists/trixie/main/binary-arm64"
    mkdir -p "$idx"
    printf 'Package: mlat-client\nVersion: 9\nFilename: pool/m.deb\nSHA256: 00\n\n' > "$idx/Packages"
    for deb in "$RB"/pool/main/r/rbfeeder/*.deb; do
        printf 'Package: rbfeeder\nVersion: %s\nFilename: %s\nSHA256: %s\n\n' \
            "$(dpkg-deb -f "$deb" Version)" "${deb#"$RB"/}" "$(sha256sum "$deb" | cut -d' ' -f1)" >> "$idx/Packages"
    done
    printf 'Codename: trixie\nSHA256:\n %s %s main/binary-arm64/Packages\n' \
        "$(sha256sum "$idx/Packages" | cut -d' ' -f1)" "$(stat -c %s "$idx/Packages")" > "$RB/dists/trixie/Release"
    rm -f "$RB/dists/trixie/InRelease"
    gpg --batch --quiet --yes --local-user "$1" --clearsign -o "$RB/dists/trixie/InRelease" "$RB/dists/trixie/Release"
}
make_rb 1:1.0.16+trixie
make_rb 1:1.0.17+trixie
publish_rb repo@test
RBD="$XDG_DATA_HOME/zeroairfeeder/rbfeeder"
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [[ "$out" == *"OK: rbfeeder 1:1.0.17+trixie installed"* ]]'
check '[ "$("$RBD/rbfeeder")" = "rbfeeder 1:1.0.17+trixie" ]'
check '[ -f "$RBD/copyright" ] && [ ! -e "$RBD/dump1090-rb" ]'
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [[ "$out" == *"already installed"* ]]'
rm -rf "$RBD"
publish_rb other@test
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"not signed by AirNav"* ]] && [ ! -e "$RBD/rbfeeder" ]'
# Signed by AirNav's key and by another one (AirNav signs with its old and new
# keys): accepted, like apt does.
gpg --batch --quiet --yes --local-user repo@test --local-user other@test --clearsign \
    -o "$RB/dists/trixie/InRelease" "$RB/dists/trixie/Release"
check '[ "$(grep -c "BEGIN PGP SIGNATURE" "$RB/dists/trixie/InRelease")" = 1 ]'
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [ -x "$RBD/rbfeeder" ]'
rm -rf "$RBD"
# A signature that does not match the content: refused even next to a good one.
sed -i 's/^Codename: trixie/Codename: trixie2/' "$RB/dists/trixie/InRelease"
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"not signed by AirNav"* ]] && [ ! -e "$RBD/rbfeeder" ]'
publish_rb repo@test
cp "$RB/pool/main/r/rbfeeder/rbfeeder_1.0.16+trixie_arm64.deb" "$RB/pool/main/r/rbfeeder/rbfeeder_1.0.17+trixie_arm64.deb"
out="$("$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"does not match the signed index"* ]] && [ ! -e "$RBD/rbfeeder" ]'
out="$(ZF_ARCH=amd64 "$CTL" install-rbfeeder 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"no rbfeeder for amd64"* ]]'

# --- pfclient: a pinned tarball ---
PFW="$W/pf"; mkdir -p "$PFW/src"
printf '#!/bin/sh\necho pfclient\n' > "$PFW/src/pfclient"; chmod 0755 "$PFW/src/pfclient"
tar -czf "$PFW/pfclient.tar.gz" -C "$PFW/src" pfclient
export ZF_PF_URL="file://$PFW/pfclient.tar.gz"
ZF_PF_SHA256="$(sha256sum "$PFW/pfclient.tar.gz" | cut -d' ' -f1)"
export ZF_PF_SHA256
PFD="$XDG_DATA_HOME/zeroairfeeder/pfclient"
out="$("$CTL" install-pfclient 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [ "$("$PFD/pfclient")" = "pfclient" ] && [ "$(cat "$PFD/version")" = "5.3.31" ]'
out="$("$CTL" install-pfclient 2>&1)"; rc=$?
check '[ $rc -eq 0 ] && [[ "$out" == *"already installed"* ]]'
rm -rf "$PFD"
out="$(ZF_PF_SHA256=0000 "$CTL" install-pfclient 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"does not match its checksum"* ]] && [ ! -e "$PFD/pfclient" ]'
printf 'x\n' > "$PFW/src/evil"
tar -czf "$PFW/bad.tar.gz" -C "$PFW/src" pfclient evil
out="$(ZF_PF_URL="file://$PFW/bad.tar.gz" ZF_PF_SHA256="$(sha256sum "$PFW/bad.tar.gz" | cut -d' ' -f1)" "$CTL" install-pfclient 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"unexpected content"* ]] && [ ! -e "$PFD/pfclient" ]'
out="$(ZF_ARCH=armhf "$CTL" install-pfclient 2>&1)"; rc=$?
check '[ $rc -eq 2 ] && [[ "$out" == *"no checked pfclient for armhf"* ]]'

if [ "$fails" -eq 0 ]; then echo "ctl_helper_test: all checks passed"; exit 0; fi
echo "ctl_helper_test: $fails check(s) FAILED"
exit 1
