/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_system.h"

#include "child_process.h"
#include "signup_runner.h"

#include <cerrno>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

namespace feeder {
namespace {

namespace fs = std::filesystem;
constexpr auto kPollPeriod = std::chrono::seconds(1);
constexpr size_t kLiveLimit = 6000;

bool executable(const std::string& path) { return !path.empty() && ::access(path.c_str(), X_OK) == 0; }

// Seconds since the file was last written, or -1 if missing.
long long age_s(const std::string& path) {
    struct stat st {};
    if (::stat(path.c_str(), &st) != 0) return -1;
    return static_cast<long long>(std::time(nullptr)) - static_cast<long long>(st.st_mtime);
}

std::string mock_state_dir() {
    if (const char* s = std::getenv("ZEROAIRFEEDER_MOCK_STATE"); s && s[0] != '\0') return s;
    return "/tmp/zeroairfeeder-mock-" + std::to_string(::getuid());
}

std::string trim(const std::string& s) {
    const auto a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return {};
    return s.substr(a, s.find_last_not_of(" \t\r\n") - a + 1);
}

} // namespace

const char* program_name(Program p) {
    switch (p) {
        case Program::Fr24feed: return "fr24feed";
        case Program::Pfclient: return "pfclient";
        case Program::Rbfeeder: return "rbfeeder";
    }
    return "";
}

const std::string& SystemPaths::dir(Program p) const {
    return p == Program::Pfclient ? pf_dir : p == Program::Rbfeeder ? rb_dir : fr24_dir;
}
const std::string& SystemPaths::binary(Program p) const {
    return p == Program::Pfclient ? pfclient : p == Program::Rbfeeder ? rbfeeder : fr24feed;
}
const std::string& SystemPaths::version_file(Program p) const {
    return p == Program::Pfclient ? pf_version : p == Program::Rbfeeder ? rb_version : fr24_version;
}

bool SystemState::installed(Program p) const {
    return p == Program::Pfclient ? pf_installed : p == Program::Rbfeeder ? rb_installed : fr24_installed;
}
bool SystemState::installing_program(Program p) const {
    return p == Program::Pfclient ? installing_pf : p == Program::Rbfeeder ? installing_rb : installing_fr24;
}

std::string http_get_local(int port, const std::string& path, int timeout_ms) {
    const int fd = ::socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (fd < 0) return {};
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);
    const auto wait = [&](short events) {
        const auto left = std::chrono::duration_cast<std::chrono::milliseconds>(
                              deadline - std::chrono::steady_clock::now()).count();
        if (left <= 0) return false;
        pollfd pfd{fd, events, 0};
        return ::poll(&pfd, 1, static_cast<int>(left)) == 1 && (pfd.revents & (events | POLLHUP));
    };
    std::string body;
    do {
        if (::connect(fd, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) != 0) {
            if (errno != EINPROGRESS || !wait(POLLOUT)) break;
            int err = 0;
            socklen_t len = sizeof(err);
            if (::getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len) != 0 || err != 0) break;
        }
        const std::string req = "GET " + path + " HTTP/1.0\r\nHost: 127.0.0.1\r\nConnection: close\r\n\r\n";
        if (::send(fd, req.data(), req.size(), MSG_NOSIGNAL) != static_cast<ssize_t>(req.size())) break;
        std::string resp;
        char buf[4096];
        while (resp.size() < 256 * 1024 && wait(POLLIN)) {
            const ssize_t n = ::recv(fd, buf, sizeof(buf), 0);
            if (n > 0) resp.append(buf, static_cast<size_t>(n));
            else if (n == 0) break;
            else if (errno != EAGAIN && errno != EINTR) break;
        }
        if (resp.rfind("HTTP/1.", 0) != 0 || resp.size() < 12 || resp.compare(9, 3, "200") != 0) break;
        const auto sep = resp.find("\r\n\r\n");
        if (sep != std::string::npos) body = resp.substr(sep + 4);
    } while (false);
    ::close(fd);
    return body;
}

std::string runtime_dir() {
    std::string dir;
    if (const char* rt = std::getenv("XDG_RUNTIME_DIR"); rt && rt[0] != '\0') {
        dir = std::string(rt) + "/zeroairfeeder";
    } else {
        dir = "/tmp/zeroairfeeder-" + std::to_string(::getuid());
    }
    ::mkdir(dir.c_str(), 0700);
    return dir;
}

std::string data_dir() {
    if (const char* d = std::getenv("XDG_DATA_HOME"); d && d[0] != '\0') return std::string(d) + "/zeroairfeeder";
    if (const char* h = std::getenv("HOME"); h && h[0] != '\0') return std::string(h) + "/.local/share/zeroairfeeder";
    return "/tmp/zeroairfeeder-data-" + std::to_string(::getuid());
}

void kill_stale(const std::string& pid_file, const std::string& exe) {
    std::ifstream in(pid_file);
    long pid = 0;
    if (!(in >> pid) || pid <= 1) return;
    std::error_code ec;
    const auto target = fs::read_symlink("/proc/" + std::to_string(pid) + "/exe", ec);
    if (ec) return;
    const auto want = fs::weakly_canonical(exe, ec);
    if (ec || target != want) return;
    ::kill(static_cast<pid_t>(pid), SIGTERM);
}

SystemPaths SystemPaths::from_env(const std::string& install_dir, const std::string& mock_dir,
                                  bool default_mock) {
    SystemPaths p;
    p.mock = default_mock;
    if (const char* m = std::getenv("ZEROAIRFEEDER_MOCK"); m && m[0] != '\0') p.mock = std::string(m) != "0";
    p.runtime_dir = feeder::runtime_dir();
    if (p.mock) {
        const std::string state = mock_state_dir();
        ::mkdir(state.c_str(), 0700);
        p.ctl = mock_dir + "/mock-ctl.sh";
        p.fr24_dir = state + "/fr24feed";
        p.pf_dir = state + "/pfclient";
        p.rb_dir = state + "/rbfeeder";
        p.readsb = mock_dir + "/mock-readsb.sh";
        p.legacy_ini = state + "/etc-fr24feed.ini";
    } else {
        p.ctl = install_dir + "/bin/zeroairfeeder-ctl";
        p.fr24_dir = data_dir() + "/fr24feed";
        p.pf_dir = data_dir() + "/pfclient";
        p.rb_dir = data_dir() + "/rbfeeder";
        p.readsb = install_dir + "/bin/readsb";
        p.legacy_ini = "/etc/fr24feed.ini";
    }
    if (const char* c = std::getenv("ZEROAIRFEEDER_CTL"); c && c[0] != '\0') p.ctl = c;
    p.fr24feed = p.fr24_dir + "/fr24feed";
    p.fr24_version = p.fr24_dir + "/version";
    p.pfclient = p.pf_dir + "/pfclient";
    p.pf_version = p.pf_dir + "/version";
    p.rbfeeder = p.rb_dir + "/rbfeeder";
    p.rb_version = p.rb_dir + "/version";
    if (const char* port = std::getenv("ZEROAIRFEEDER_PF_PORT"); port && port[0] != '\0') {
        const int v = std::atoi(port);
        if (v > 0 && v < 65536) p.pf_web_port = v;
    }
    return p;
}

std::string summarize_output(const std::string& output) {
    std::istringstream in(output);
    std::string line, last, flagged;
    while (std::getline(in, line)) {
        const auto first = line.find_first_not_of(" \t");
        if (first == std::string::npos) continue;
        line = line.substr(first);
        last = line;
        if (line.rfind("ERROR", 0) == 0 || line.rfind("sudo:", 0) == 0 || line.rfind("E: ", 0) == 0 ||
            line.rfind("curl:", 0) == 0 || line.rfind("gpgv:", 0) == 0 || line.rfind("Failed", 0) == 0)
            flagged = line;
    }
    return flagged.empty() ? last : flagged;
}

FeederSystem::FeederSystem(SystemPaths paths) : paths_(std::move(paths)) {
    // A fr24feed of ours left over by a crash (it would hold port 8754).
    kill_stale(paths_.runtime_dir + "/fr24feed.pid", paths_.fr24feed);
    kill_stale(paths_.runtime_dir + "/pfclient.pid", paths_.pfclient); // port 30053
    poll_once();
    poll_thread_ = std::thread([this] { poll_loop(); });
    job_thread_ = std::thread([this] { job_loop(); });
}

FeederSystem::~FeederSystem() {
    running_ = false;
    cancel_ = true;
    cv_.notify_all();
    if (poll_thread_.joinable()) poll_thread_.join();
    if (job_thread_.joinable()) job_thread_.join();
    stop_feeding(); // the feeder never outlives the app
}

SystemState FeederSystem::state() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return state_;
}

std::string FeederSystem::start_feeding(const FeederConfig& cfg) {
    switch (missing_for_feeding(cfg)) {
        case Field::NoService: return "no service is on";
        case Field::Key: return "no FR24 sharing key";
        case Field::PfShareCode: return "no Plane Finder share code";
        case Field::Location: return "Plane Finder needs the position";
        default: break;
    }
    if (cfg.fr24_enabled && !executable(paths_.fr24feed)) return "fr24feed is not installed";
    if (cfg.pf_enabled && !executable(paths_.pfclient)) return "pfclient is not installed";
    if (cfg.rb_enabled && !executable(paths_.rbfeeder)) return "rbfeeder is not installed";
    if (!executable(paths_.readsb)) return "readsb is missing: " + paths_.readsb;

    stop_feeding();
    const std::string& rt = paths_.runtime_dir;
    const std::string json_dir = rt + "/readsb";
    ::mkdir(json_dir.c_str(), 0700);
    // Never show a previous session's numbers.
    for (const char* f : {"/decoder.txt", "/readsb/aircraft.json", "/rbfeeder.log"})
        ::unlink((rt + f).c_str());

    // Files with a key in them: 0600 from the start.
    const auto write_private = [](const std::string& path, const std::string& text) {
        const int fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
        if (fd < 0) return false;
        ::fchmod(fd, 0600);
        size_t done = 0;
        while (done < text.size()) {
            const ssize_t n = ::write(fd, text.data() + done, text.size() - done);
            if (n <= 0) {
                ::close(fd);
                return false;
            }
            done += static_cast<size_t>(n);
        }
        return ::close(fd) == 0;
    };
    const std::string fr24_ini = rt + "/fr24feed.ini";
    if (cfg.fr24_enabled && !write_private(fr24_ini, render_fr24feed_ini(cfg, rt)))
        return "cannot write " + fr24_ini;
    const std::string rb_ini = rt + "/rbfeeder.ini";
    if (cfg.rb_enabled && !write_private(rb_ini, render_rbfeeder_ini(cfg, rt)))
        return "cannot write " + rb_ini;

    std::vector<std::string> readsb = {paths_.readsb};
    const auto args = readsb_args(cfg, json_dir);
    readsb.insert(readsb.end(), args.begin(), args.end());
    readsb_.start(readsb);
    if (cfg.fr24_enabled) {
        // fr24feed must be able to tell the time is UTC-correct: it complains
        // about a TZ other than GMT (see the sdr-enthusiasts container).
        fr24feed_.start({paths_.fr24feed, "--config-file=" + fr24_ini}, {{"TZ", "GMT"}});
    }
    if (cfg.pf_enabled) {
        std::vector<std::string> pf = {paths_.pfclient};
        auto pf_args = pfclient_args(cfg, rt);
        for (auto& a : pf_args)
            if (a.rfind("--web_port=", 0) == 0) a = "--web_port=" + std::to_string(paths_.pf_web_port);
        pf.insert(pf.end(), pf_args.begin(), pf_args.end());
        pfclient_.start(pf);
    }
    if (cfg.rb_enabled) rbfeeder_.start({paths_.rbfeeder, "--config", rb_ini});
    fr24_on_ = cfg.fr24_enabled;
    pf_on_ = cfg.pf_enabled;
    rb_on_ = cfg.rb_enabled;
    feeding_ = true;
    poll_once();
    return {};
}

void FeederSystem::stop_feeding() {
    feeding_ = false;
    fr24_on_ = pf_on_ = rb_on_ = false;
    fr24feed_.stop();
    pfclient_.stop();
    rbfeeder_.stop();
    readsb_.stop();
    if (running_) poll_once();
}

std::string FeederSystem::log_text() const {
    std::string out;
    for (const auto* p : {&readsb_, &fr24feed_, &pfclient_, &rbfeeder_}) {
        for (const auto& l : p->log_lines()) out += l + "\n";
    }
    return out;
}

std::string FeederSystem::read_version(Program p) const {
    std::ifstream in(paths_.version_file(p));
    std::string v;
    std::getline(in, v);
    return trim(v);
}

void FeederSystem::poll_once() {
    SystemState next;
    next.fr24_installed = executable(paths_.fr24feed);
    if (next.fr24_installed) next.fr24_version = read_version(Program::Fr24feed);
    next.pf_installed = executable(paths_.pfclient);
    if (next.pf_installed) next.pf_version = read_version(Program::Pfclient);
    next.rb_installed = executable(paths_.rbfeeder);
    if (next.rb_installed) next.rb_version = read_version(Program::Rbfeeder);

    next.feeding = feeding_;
    next.fr24_on = fr24_on_;
    next.pf_on = pf_on_;
    next.rb_on = rb_on_;
    next.readsb_running = readsb_.running();
    next.fr24_running = fr24feed_.running();
    next.pf_running = pfclient_.running();
    next.rb_running = rbfeeder_.running();
    next.readsb_restarts = readsb_.restarts();
    next.fr24_restarts = fr24feed_.restarts();
    next.pf_restarts = pfclient_.restarts();
    next.rb_restarts = rbfeeder_.restarts();
    next.readsb_error = readsb_.last_exit_line();
    next.fr24_error = fr24feed_.last_exit_line();
    next.pf_error = pfclient_.last_exit_line();
    next.rb_error = rbfeeder_.last_exit_line();

    if (next.feeding) {
        const std::string& rt = paths_.runtime_dir;
        if (next.fr24_on) {
            const std::string monitor = rt + "/decoder.txt";
            next.fr24 = parse_decoder_txt(read_text_file(monitor));
            const long long age = age_s(monitor);
            next.fr24_fresh = next.fr24_running && next.fr24.present && age >= 0 && age <= 30;
        }
        if (next.pf_on && next.pf_running)
            next.pf = parse_pf_stats(http_get_local(paths_.pf_web_port, "/ajax/stats", 400));
        if (next.rb_on) {
            if (next.rb_running) next.rb = parse_rbfeeder_log(read_text_file(rt + "/rbfeeder.log"));
            // rbfeeder writes the key it got from AirNav into its ini.
            const auto ini = parse_ini(read_text_file(rt + "/rbfeeder.ini"));
            if (const auto it = ini.find("key"); it != ini.end() && valid_rb_key(it->second))
                next.rb_ini_key = it->second;
        }
        const std::string json = paths_.runtime_dir + "/readsb/aircraft.json";
        if (next.readsb_running && age_s(json) >= 0 && age_s(json) <= 10)
            next.aircraft = parse_aircraft_json(read_text_file(json));
    }

    const auto legacy = parse_ini(read_text_file(paths_.legacy_ini));
    if (const auto it = legacy.find("fr24key"); it != legacy.end()) {
        const std::string key = normalize_key(it->second);
        if (valid_sharing_key(key)) next.legacy_key = key;
    }

    std::lock_guard<std::mutex> lock(mutex_);
    const auto mark = [&](Program p, bool& flag) {
        flag = busy_name_ == "install" && busy_program_ == p;
        for (const auto& j : pending_) flag = flag || (j.name == "install" && j.program == p);
        next.installing = next.installing || flag;
    };
    mark(Program::Fr24feed, next.installing_fr24);
    mark(Program::Pfclient, next.installing_pf);
    mark(Program::Rbfeeder, next.installing_rb);
    state_ = std::move(next);
}

void FeederSystem::poll_loop() {
    while (running_) {
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait_for(lock, kPollPeriod, [this] { return !running_.load(); });
        }
        if (!running_) break;
        poll_once();
    }
}

std::vector<std::string> FeederSystem::install_command(Program program) const {
    return {paths_.ctl, std::string("install-") + program_name(program), "--dest", paths_.dir(program)};
}

bool FeederSystem::submit(Job job) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (job.name == "signup") {
            if (!pending_.empty() || !busy_name_.empty()) return false;
        } else {
            if (busy_name_ == job.name && busy_program_ == job.program) return false;
            for (const auto& j : pending_)
                if (j.name == job.name && j.program == job.program) return false;
        }
        pending_.push_back(std::move(job));
        cv_.notify_all();
    }
    poll_once(); // "installing" right away
    return true;
}

bool FeederSystem::submit_install(Program program) { return submit({"install", program, std::nullopt}); }

bool FeederSystem::submit_signup(SignupAnswers answers) {
    return submit({"signup", Program::Fr24feed, std::move(answers)});
}

void FeederSystem::cancel_job() { cancel_ = true; }

bool FeederSystem::busy() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return !pending_.empty() || !busy_name_.empty();
}

std::string FeederSystem::busy_name() const {
    std::lock_guard<std::mutex> lock(mutex_);
    if (!busy_name_.empty()) return busy_name_;
    return pending_.empty() ? std::string{} : pending_.front().name;
}

std::string FeederSystem::live_output() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return live_;
}

std::optional<JobResult> FeederSystem::take_result() {
    std::lock_guard<std::mutex> lock(mutex_);
    if (results_.empty()) return std::nullopt;
    JobResult r = std::move(results_.front());
    results_.pop_front();
    return r;
}

void FeederSystem::job_loop() {
    while (running_) {
        Job job;
        {
            std::unique_lock<std::mutex> lock(mutex_);
            cv_.wait(lock, [this] { return !pending_.empty() || !running_.load(); });
            if (!running_) return;
            job = std::move(pending_.front());
            pending_.pop_front();
            busy_name_ = job.name;
            busy_program_ = job.name == "install" ? std::optional<Program>(job.program) : std::nullopt;
            live_.clear();
        }
        cancel_ = false;
        JobResult result = run_job(job);
        {
            std::lock_guard<std::mutex> lock(mutex_);
            busy_name_.clear();
            busy_program_.reset();
            results_.push_back(std::move(result));
        }
        poll_once();
    }
}

JobResult FeederSystem::run_job(const Job& job) {
    JobResult result;
    result.name = job.name;
    result.program = job.program;
    if (job.signup) {
        if (!executable(paths_.fr24feed)) {
            result.message = "fr24feed is not installed";
            return result;
        }
        // FR24's wizard, as the app's user, saving into a fresh file of ours.
        const std::string& rt = paths_.runtime_dir;
        const std::string key_file = rt + "/signup.ini";
        { std::ofstream(key_file, std::ios::trunc); }
        ::chmod(key_file.c_str(), 0600);
        // At its end the wizard tries `systemctl enable/restart fr24feed`; there
        // is no such service here, and a non-root systemctl could ask for a
        // password. A stand-in that does nothing comes first in PATH.
        const std::string nosys = rt + "/nosystemctl";
        ::mkdir(nosys.c_str(), 0700);
        {
            std::ofstream s(nosys + "/systemctl", std::ios::trunc);
            s << "#!/bin/sh\nexit 1\n";
        }
        ::chmod((nosys + "/systemctl").c_str(), 0700);
        const char* path = std::getenv("PATH");
        const std::string new_path = nosys + ":" + (path ? path : "/usr/bin:/bin");
        const SignupResult r = run_signup(
            {paths_.fr24feed, "--signup", "--adsb", "--config-file=" + key_file}, *job.signup, cancel_,
            [this](const std::string& tail) {
                std::lock_guard<std::mutex> lock(mutex_);
                live_ = tail;
            },
            key_file, {{"PATH", new_path}, {"TZ", "GMT"}});
        ::unlink(key_file.c_str());
        result.ok = r.ok;
        result.message = r.ok ? r.sharing_key : r.error;
        result.output = r.transcript;
        result.sharing_key = r.sharing_key;
        return result;
    }
    // install: the helper downloads the program from its maker into the
    // user's data directory and checks its signature (or pinned checksum).
    const CommandResult r = run_command(install_command(job.program), 900, &cancel_,
                                        [this](const std::string& s) {
                                            std::lock_guard<std::mutex> lock(mutex_);
                                            live_ += s;
                                            if (live_.size() > kLiveLimit)
                                                live_.erase(0, live_.size() - kLiveLimit);
                                        });
    result.ok = r.ok() && executable(paths_.binary(job.program));
    result.output = r.output;
    if (r.exit_code == 124) result.message = "timed out";
    else result.message = summarize_output(r.output);
    if (!r.ok() && result.message.empty()) result.message = "exit code " + std::to_string(r.exit_code);
    return result;
}

} // namespace feeder
