/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <filesystem>
#include <map>
#include <optional>
#include <string>
#include <vector>

namespace feeder {

// Everything the app needs to feed. Kept in ~/.config/zeroairfeeder/settings.ini;
// position and altitude come from the GPS of the M5Stack Cap LoRa-1262.
struct FeederConfig {
    std::string sharing_key;      // FR24 sharing key, 16 letters/digits ("" = not set)
    std::string email;            // FR24 account e-mail, only used to sign up
    bool has_location = false;    // antenna position set
    double lat = 0.0;             // degrees, WGS84
    double lon = 0.0;
    std::string location_label;   // what the Account row shows, e.g. "Milano, IT"
    bool has_altitude = false;
    int altitude_ft = 0;          // antenna height above sea level, in feet (FR24 asks feet)
    bool mlat = false;            // take part in FR24 MLAT (needs a fixed, precise position)
    std::string gain = "auto";    // readsb --gain: "auto" or one of gain_choices()
    int ppm = 0;                  // readsb --ppm: dongle frequency correction

    // The services to feed (FEEDS page): each one on or off, all from the same
    // readsb. FR24 is on unless turned off; the others are off until turned on.
    bool fr24_enabled = true;
    bool pf_enabled = false;      // Plane Finder (pfclient)
    std::string pf_sharecode;     // Plane Finder share code ("" = not set)
    bool rb_enabled = false;      // AirNav RadarBox (rbfeeder)
    std::string rb_key;           // AirNav sharing key; "" = rbfeeder makes one
};

// --- validation ---

// FR24 sharing keys are 16 characters, letters and digits (fr24feed rejects any
// other length or character).
bool valid_sharing_key(const std::string& key);
// A plain address check: one '@', a non-empty local part, a dotted domain, no
// spaces or control characters, at most 254 characters.
bool valid_email(const std::string& email);
bool valid_lat(double lat);
bool valid_lon(double lon);
// FR24's signup takes the altitude in feet; -1500..30000 covers every antenna.
bool valid_altitude_ft(int feet);
bool valid_ppm(int ppm);
bool valid_gain(const std::string& gain);
// Plane Finder share codes (planefinder.net > Sharing > Create share code) are
// letters and digits, 14 in the ones seen; 8..32 accepted.
bool valid_pf_sharecode(const std::string& code);
// AirNav sharing keys are letters and digits, 32 in the ones seen; 16..64
// accepted. Only letters and digits ever reach rbfeeder's ini.
bool valid_rb_key(const std::string& key);

// readsb gain steps for the R820T/R828D tuners (RTL-SDR Blog V3/V4), "auto" first.
const std::vector<std::string>& gain_choices();

// Removes spaces, tabs and dashes people paste around a key.
std::string normalize_key(const std::string& text);

// Metres <-> feet for the altitude row (FR24 wants feet, most people think metres).
int metres_to_feet(double metres);
double feet_to_metres(int feet);

// "%.6f" in the C locale, so a decimal comma never reaches the helper.
std::string format_coord(double value);

// --- ini files ---

// key=value lines (fr24feed.ini, /etc/default files, our settings): blank lines
// and lines starting with '#' or ';' are skipped, spaces around the key and the
// value are trimmed and one pair of surrounding double quotes is removed.
std::map<std::string, std::string> parse_ini(const std::string& text);

// The fr24feed.ini the app writes in its runtime directory before it starts
// fr24feed: receiver = our readsb's Beast output on 127.0.0.1:30005, and the
// monitor file, pid file and logs kept in `runtime_dir` (fr24feed runs as the
// app's user, not as a service). Kept here so the tests pin the exact content.
std::string render_fr24feed_ini(const FeederConfig& cfg, const std::string& runtime_dir);

// The rbfeeder.ini of AirNav's rbfeeder, written in the runtime directory:
// network mode on our readsb's Beast output, its log in `runtime_dir`, its own
// MLAT and GNSS off (the app has no mlat-client, and the GPS is the app's). An
// empty key lets rbfeeder make one at its first connection and write it back.
std::string render_rbfeeder_ini(const FeederConfig& cfg, const std::string& runtime_dir);

// pfclient's arguments (after the program): Beast from our readsb, the share
// code and position, its pid, config and log files in `runtime_dir`.
std::vector<std::string> pfclient_args(const FeederConfig& cfg, const std::string& runtime_dir);
constexpr int kPfWebPort = 30053; // pfclient's status page (/ajax/stats)

// readsb's arguments: the RTL-SDR dongle in, Beast out on 127.0.0.1:30005 only,
// aircraft.json every second in `json_dir`; gain, ppm and position from `cfg`.
std::vector<std::string> readsb_args(const FeederConfig& cfg, const std::string& json_dir);

// Our own settings file.
std::string serialize_settings(const FeederConfig& cfg);
FeederConfig parse_settings(const std::string& text);
std::filesystem::path settings_path(); // ~/.config/zeroairfeeder/settings.ini
std::optional<FeederConfig> load_settings(const std::filesystem::path& path);
bool save_settings(const std::filesystem::path& path, const FeederConfig& cfg); // atomic

// The first field still missing, or Field::None when everything is set.
enum class Field { None, NoService, Key, Email, Location, Altitude, PfShareCode };
// Feeding needs at least one service on, the FR24 sharing key if FR24 is on,
// the share code and the position if Plane Finder is on (AirNav makes its own
// key; the position helps readsb but is otherwise optional).
Field missing_for_feeding(const FeederConfig& cfg);
// A signup needs the e-mail, the position and the altitude.
Field missing_for_signup(const FeederConfig& cfg);

// Reads the whole file, "" when missing.
std::string read_text_file(const std::filesystem::path& path);

} // namespace feeder
