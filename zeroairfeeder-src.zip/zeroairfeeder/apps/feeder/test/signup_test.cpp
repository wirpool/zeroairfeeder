/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

// The signup wizard driver: SignupScript on fixed prompt texts, then the whole
// pseudo-terminal path (run_signup) against assets/mock/mock-signup-wizard.sh, which reads
// its answers from /dev/tty like fr24feed and checks each one.

#include "child_process.h"
#include "signup_runner.h"
#include "signup_script.h"
#include "test_util.h"

#include <atomic>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <string>
#include <unistd.h>

#ifndef MOCK_WIZARD
#error "MOCK_WIZARD must point to assets/mock/mock-signup-wizard.sh"
#endif

using namespace feeder;

namespace {

SignupAnswers answers() {
    SignupAnswers a;
    a.email = "matteo@example.it";
    a.lat = 45.46421;
    a.lon = 9.19138;
    a.altitude_ft = 400;
    a.mlat = false;
    return a;
}

void test_script_prompts() {
    SignupScript s(answers());
    // Banner only: nothing to answer yet.
    CHECK(!s.on_output("Welcome to the FR24 Decoder/Feeder sign up wizard!\n").has_value());
    // A prompt split across reads, answered once the "$:" marker arrives.
    CHECK(!s.on_output("Step 1.1 - Enter your email ").has_value());
    auto a = s.on_output("address (username@domain.tld)\n$:");
    CHECK(a && *a == "matteo@example.it");
    // Same prompt text again later would be a re-ask; first the next steps.
    a = s.on_output("Step 1.2 - If you used to feed FR24 with ADS-B data before, enter your sharing key.\n"
                    "Enter your sharing key or press ENTER/RETURN to continue.\n$:");
    CHECK(a && a->empty());
    a = s.on_output("Step 1.3 - Would you like to participate in MLAT calculations? (yes/no)$:");
    CHECK(a && *a == "no");
    // No marker: answered when the output goes quiet.
    CHECK(!s.on_output("Step 3.A - Enter antenna's latitude (DD.DDDD)\n").has_value());
    a = s.on_idle();
    CHECK(a && *a == "45.4642");
    a = s.on_output("Step 3.B - Enter antenna's longitude (DDD.DDDD)\n$:");
    CHECK(a && *a == "9.1914");
    a = s.on_output("Step 3.C - Enter antenna's altitude above the sea level (in feet)\n$:");
    CHECK(a && *a == "400");
    a = s.on_output("Would you like to continue using these settings?\nEnter your choice (yes/no)$:");
    CHECK(a && *a == "yes");
    a = s.on_output("Step 4.1 - Receiver selection:\n 4 - ModeS Beast (USB/Network)\nEnter your receiver type (1-6)$:");
    CHECK(a && *a == "4");
    a = s.on_output("Step 4.2 - Please select connection type:\nEnter your connection type (1-2)$:");
    CHECK(a && *a == "1");
    a = s.on_output("Step 4.3A - Please enter your receiver's IP address/hostname\n$:");
    CHECK(a && *a == "127.0.0.1");
    a = s.on_output("Step 4.3B - Please enter your receiver's data port number\n$:");
    CHECK(a && *a == "30005");
    a = s.on_output("Step 5.1 - Would you like to enable RAW data feed on port 30334 (yes/*no*)$:");
    CHECK(a && *a == "no");
    a = s.on_output("\x1b[1mStep 5.2\x1b[0m - Would you like to enable Basestation data feed on port 30003 (yes/no)$:");
    CHECK(a && *a == "no"); // ANSI codes are stripped before matching
    CHECK(!s.on_output("Saving settings to /etc/fr24feed.ini...OK\nZEROAIRFEEDER_KEY=0a1b2c3d4e5f6a7b\n").has_value());
    CHECK_EQ(s.sharing_key(), std::string("0a1b2c3d4e5f6a7b"));
    CHECK(!s.failed());
}

void test_script_failures() {
    {   // A value the wizard keeps refusing.
        SignupScript s(answers());
        for (int i = 0; i < 3; ++i) {
            auto a = s.on_output("Invalid email x provided, please try again\nStep 1.1 - Enter your email address\n$:");
            CHECK(a.has_value());
        }
        CHECK(!s.on_output("Step 1.1 - Enter your email address\n$:").has_value());
        CHECK(s.failed());
        CHECK(s.error().find("Step 1.1") != std::string::npos);
    }
    {   // The server says no: answer "no" and report it.
        SignupScript s(answers());
        auto a = s.on_output("ERROR\nYour location is not allowed.\nWould you like to try again? (yes/no)$:");
        CHECK(a && *a == "no");
        CHECK(s.failed());
        CHECK(s.error().find("not allowed") != std::string::npos);
    }
    {   // sudo wants a password: nobody is there to type it.
        SignupScript s(answers());
        CHECK(!s.on_output("[sudo] password for pi: ").has_value());
        CHECK(s.failed());
    }
    {   // A malformed key line is ignored.
        SignupScript s(answers());
        s.on_output("ZEROAIRFEEDER_KEY=tooshort\n");
        CHECK(s.sharing_key().empty());
    }
    {   // The wizard's own success line, when the helper's marker is missing.
        SignupScript s(answers());
        s.on_output("+ Your sharing key (abcdef0123456789) has been configured and emailed to you.\n");
        CHECK_EQ(s.sharing_key(), std::string("abcdef0123456789"));
        SignupScript t(answers());
        t.on_output("+ Your sharing key (abcdef01234567890) has been configured\n"); // 17 chars
        CHECK(t.sharing_key().empty());
    }
    CHECK_EQ(strip_ansi("\x1b[31mred\x1b[0m\r\n"), std::string("red\n"));
}

void test_pty_wizard() {
    ::setenv("MOCK_EXPECT_EMAIL", "matteo@example.it", 1);
    ::setenv("MOCK_EXPECT_LAT", "45.4642", 1);
    ::setenv("MOCK_EXPECT_LON", "9.1914", 1);
    ::setenv("MOCK_EXPECT_ALT", "400", 1);
    ::setenv("MOCK_EXPECT_MLAT", "no", 1);
    ::unsetenv("MOCK_DELAY");
    char tmpl[] = "/tmp/zeroairfeeder-signup-XXXXXX";
    const std::string dir = ::mkdtemp(tmpl);
    const std::string key_file = dir + "/signup.ini";
    const auto fresh = [&] { std::ofstream(key_file, std::ios::trunc); };
    const std::vector<std::string> wizard = {"/bin/bash", MOCK_WIZARD, "--config-file=" + key_file};
    std::atomic<bool> cancel{false};
    int progress_calls = 0;
    const auto progress = [&](const std::string&) { ++progress_calls; };

    // "password": the wizard saved the key, then asks for a password nobody
    // can type: still a success, the key is in the file.
    for (const char* mode : {"ok", "nomarker", "password"}) {
        ::setenv("MOCK_MODE", mode, 1);
        fresh();
        const SignupResult r = run_signup(wizard, answers(), cancel, progress, key_file, {}, 30, 300);
        if (!r.ok) std::fprintf(stderr, "mode %s: %s\n%s\n", mode, r.error.c_str(), r.transcript.c_str());
        CHECK(r.ok);
        CHECK_EQ(r.sharing_key, std::string("0a1b2c3d4e5f6a7b"));
    }
    CHECK(progress_calls > 5);

    ::setenv("MOCK_MODE", "reject", 1);
    fresh();
    SignupResult r = run_signup(wizard, answers(), cancel, progress, key_file, {}, 30, 300);
    CHECK(!r.ok);
    CHECK(r.error.find("not allowed") != std::string::npos);

    ::setenv("MOCK_MODE", "bademail", 1);
    fresh();
    r = run_signup(wizard, answers(), cancel, progress, key_file, {}, 30, 300);
    CHECK(!r.ok);
    CHECK(r.error.find("Step 1.1") != std::string::npos);

    // A wrong answer (the mock expects another latitude) ends with its code.
    ::setenv("MOCK_MODE", "ok", 1);
    ::setenv("MOCK_EXPECT_LAT", "1.0000", 1);
    fresh();
    r = run_signup(wizard, answers(), cancel, progress, key_file, {}, 30, 300);
    CHECK(!r.ok);
    CHECK(r.error.find("code 3") != std::string::npos);

    // The extra environment reaches the wizard.
    ::setenv("MOCK_EXPECT_LAT", "45.4642", 1);
    fresh();
    r = run_signup({"/bin/bash", "-c", "[ \"$ZF_PROBE\" = yes ] && echo 'fr24key=\"abcdefabcdefabcd\"' > \"$0\"",
                    key_file},
                   answers(), cancel, progress, key_file, {{"ZF_PROBE", "yes"}}, 10, 300);
    CHECK(r.ok && r.sharing_key == "abcdefabcdefabcd");

    // Cancel stops a wizard that waits forever.
    cancel = true;
    fresh();
    r = run_signup({"/bin/bash", "-c", "read -r x < /dev/tty; sleep 100"}, answers(), cancel, progress,
                   key_file, {}, 30, 300);
    CHECK(!r.ok && r.error == "cancelled");

    // A command that cannot run.
    cancel = false;
    r = run_signup({"/nonexistent/fr24feed", "--signup"}, answers(), cancel, progress, key_file, {}, 10, 300);
    CHECK(!r.ok);
    std::filesystem::remove_all(dir);
}

void test_run_command() {
    std::string live;
    const CommandResult r = run_command({"/bin/sh", "-c", "echo out; echo err >&2; exit 7"}, 10,
                                        nullptr, [&](const std::string& s) { live += s; });
    CHECK_EQ(r.exit_code, 7);
    CHECK(r.output.find("out") != std::string::npos && r.output.find("err") != std::string::npos);
    CHECK(live == r.output);
    const CommandResult t = run_command({"/bin/sh", "-c", "sleep 30"}, 1);
    CHECK_EQ(t.exit_code, 124);
    const CommandResult m = run_command({"/nonexistent/tool"}, 5);
    CHECK_EQ(m.exit_code, 127);
}

} // namespace

int main() {
    test_script_prompts();
    test_script_failures();
    test_pty_wizard();
    test_run_command();
    return test_result("signup_test");
}
