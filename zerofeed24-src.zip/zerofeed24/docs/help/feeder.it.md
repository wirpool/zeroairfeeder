# ZeroFeed24

Condivide con Flightradar24 gli aerei ricevuti dalla chiavetta RTL-SDR. Durante l'invio l'app fa girare due programmi: readsb decodifica l'ADS-B dalla chiavetta, fr24feed (il programma ufficiale di Flightradar24) invia i dati a FR24. Girano solo ad app aperta e dopo che hai avviato l'invio: chiudendo l'app si fermano, e niente parte da solo.

## La prima volta
- Collega la chiavetta RTL-SDR e un'antenna per 1090 MHz alla porta USB-A, monta il Cap LoRa-1262 (con GPS) e connettiti al Wi-Fi.
- Al primo avvio l'app scarica da sola fr24feed da Flightradar24 (serve internet una volta) e ne verifica la firma.
- Posizione e altitudine arrivano dal GPS del Cap: tieni il CardputerZero con il cielo in vista finché la riga GPS dice "fix".
- Invii già dati a FR24? Inserisci la tua chiave di condivisione nella pagina FR24 (flightradar24.com > Account > Data sharing).
- Non hai una chiave? Imposta l'e-mail, poi "Ottieni una chiave": parte la registrazione ufficiale di FR24, la chiave compare sullo schermo e FR24 te la invia per e-mail.
- Pagina FEED: il tasto 5 avvia l'invio, di nuovo 5 lo ferma.

## Pagine (tasto 4)
- FEED: stato dell'invio. Pallino verde: collegato a FR24. Tasto 5 avvia/ferma, 6 log, 7 tema, 8 chiudi.
- FR24: chiave, e-mail, posizione e altitudine GPS, MLAT, registrazione, salvataggio. Su/Giù (F/X) per muoversi, Invio (o 7) modifica, 8 salva.
- SETUP: fr24feed (Invio: installa, o cerca una versione più recente), guadagno e PPM del ricevitore (Sinistra/Destra, Z/C), tema, lingua (di sistema, English, Italiano), log, informazioni. 8 salva.

## Note
- Senza fix GPS puoi impostare a mano posizione e altitudine nella pagina FR24; il GPS le sostituisce appena ha il fix.
- Per scrivere un'e-mail: Tab scrive @. Funziona anche Shift + 2 se la tastiera lo invia.
- La MLAT richiede un'antenna fissa e una posizione precisa. Lasciala spenta in movimento.
- Guadagno, PPM e MLAT cambiati durante l'invio valgono dopo il salvataggio (tasto 8), che riavvia l'invio.
- La chiavetta la può usare un solo programma alla volta: chiudi ZeroFeed24 prima di usare SDR, ADS-B o le altre app di ZeroRadio.
- L'ID radar (es. T-LIML123) compare quando FR24 ha accettato il tuo feeder; le statistiche sono su flightradar24.com > Account > Data sharing.
