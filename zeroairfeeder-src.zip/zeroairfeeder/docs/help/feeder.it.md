# ZeroAirFeeder

Condivide con Flightradar24 gli aerei ricevuti dalla chiavetta RTL-SDR e, se vuoi, anche con Plane Finder e AirNav RadarBox. Durante l'invio readsb decodifica l'ADS-B dalla chiavetta e ogni feeder attivo lo riceve dal suo programma ufficiale: fr24feed (Flightradar24), pfclient (Plane Finder), rbfeeder (AirNav). Girano solo ad app aperta e dopo che hai avviato l'invio: chiudendo l'app si fermano tutti, e niente parte da solo.

## La prima volta
1. Collega la chiavetta RTL-SDR e un'antenna per 1090 MHz alla porta USB-A, monta il Cap LoRa-1262 (con GPS) e connettiti al Wi-Fi. Tieni il CardputerZero con il cielo in vista finché la riga GPS dice "fix".
2. SETUP: attiva i feeder che vuoi (Flightradar24 è già attivo). L'app ne scarica da sola i programmi.
3. CHIAVI: Invio sulla chiave di ogni feeder e scegli cosa ti serve (vedi sotto).
4. FEED: il tasto 5 avvia l'invio, di nuovo 5 lo ferma. La riga di ogni feeder dice cosa sta facendo o cosa gli manca.

## Chiavi (pagina CHIAVI)
Ogni feeder funziona allo stesso modo: Invio (o Sinistra/Destra) sulla sua chiave apre un menu, scegli con 1-3 o Su/Giù + Invio.
- 1 Ce l'ho: la inserisco. FR24: flightradar24.com > Account > Data sharing. Plane Finder: planefinder.net > Your Receivers. AirNav: la tua chiave di airnavradar.com.
- 2 Ottienine una nuova. FR24: l'app chiede l'e-mail e avvia la registrazione ufficiale di FR24; la chiave compare sullo schermo e FR24 te la invia per e-mail. Plane Finder: un QR apre sul telefono la pagina dello share code, con la posizione da inserire; poi scrivi qui il codice. AirNav: automatica, AirNav assegna una chiave alla prima connessione e l'app la salva.
- 3 Mostrala per intero: per collegare il feeder al tuo account sul sito del servizio.
I titoli dei feeder dicono "pronto" quando non manca niente.

## Pagine (tasto 4)
- FEED: una riga per feeder (verde: invia, giallo: in avvio o manca qualcosa, rosso: un problema, grigio: spento), poi ricevitore e GPS. Tasto 5 avvia/ferma, 6 log, 7 tema, 8 chiudi. I feeder non pronti vengono saltati e partono appena sono pronti.
- CHIAVI: per ogni feeder la sua chiave o share code (e l'e-mail di FR24).
- SETUP, a gruppi: ogni feeder attivo o spento (e la MLAT di FR24), guadagno e PPM del ricevitore, posizione e altitudine dell'antenna, app (aggiorna programmi, tema, lingua, log, informazioni). Su/Giù (F/X) per muoversi, Sinistra/Destra (Z/C) cambia, Invio esegue. L'intestazione mostra dove sei (es. SETUP 3/13).

## Note
- Le impostazioni si salvano subito. Durante l'invio le modifiche valgono quando torni a FEED (o subito con il tasto 8).
- Senza fix GPS puoi impostare a mano posizione e altitudine in SETUP; il GPS le sostituisce appena ha il fix.
- Per scrivere un'e-mail: Tab scrive @. Funziona anche Shift + 2 se la tastiera lo invia.
- La MLAT (solo FR24) richiede un'antenna fissa e una posizione precisa. Lasciala spenta in movimento.
- SETUP > Aggiorna programmi: installa quelli mancanti e cerca versioni più recenti di fr24feed e rbfeeder.
- La chiavetta la può usare un solo programma alla volta: chiudi ZeroAirFeeder prima di usare SDR, ADS-B o le altre app di ZeroRadio.
