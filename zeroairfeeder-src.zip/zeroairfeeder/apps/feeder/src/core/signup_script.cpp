/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "signup_script.h"

#include "feeder_config.h"

#include <cstdio>

namespace feeder {
namespace {

constexpr size_t kMaxLines = 200;
constexpr int kMaxAsks = 3; // the same question three times: our value is refused
constexpr const char* kKeyMarker = "ZEROAIRFEEDER_KEY=";

std::string fixed4(double v) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.4f", v);
    for (char* p = buf; *p; ++p)
        if (*p == ',') *p = '.';
    return buf;
}

} // namespace

std::string strip_ansi(std::string_view text) {
    std::string out;
    out.reserve(text.size());
    int state = 0; // 0 text, 1 after ESC, 2 inside CSI
    for (const char c : text) {
        const auto u = static_cast<unsigned char>(c);
        if (state == 0) {
            if (u == 0x1b) state = 1;
            else if (c != '\r') out.push_back(c);
        } else if (state == 1) {
            state = (c == '[') ? 2 : 0;
        } else if (u >= 0x40 && u <= 0x7e) {
            state = 0;
        }
    }
    return out;
}

SignupScript::SignupScript(SignupAnswers answers) : answers_(std::move(answers)) {
    // The prompts of fr24feed 1.0.x (signup.cpp). Each answer is what a person
    // feeding from an existing Beast decoder on this computer would type.
    rules_ = {
        {"Step 1.1", answers_.email},
        {"Step 1.2", ""}, // no previous key: register a new feeder
        {"Step 1.3", answers_.mlat ? "yes" : "no"},
        {"Would you like to use autoconfig", "no"},
        {"Step 3.A", fixed4(answers_.lat)},
        {"Step 3.B", fixed4(answers_.lon)},
        {"Step 3.C", std::to_string(answers_.altitude_ft)},
        {"Enter your choice (yes/no)", "yes"}, // continue with these settings
        {"Step 4.1", "4"},                     // ModeS Beast (USB/Network)
        {"Step 4.2", "1"},                     // Network connection
        {"Step 4.3A", answers_.beast_host},
        {"Step 4.3B", std::to_string(answers_.beast_port)},
        {"Step 4.3 -", ""},                    // extra dump1090 arguments (DVB-T only)
        {"Step 5.1", "no"},                    // RAW output
        {"Step 5.2", "no"},                    // BaseStation output
        {"Step 5.3", "no"},                    // SBS RAW output
        {"Would you like to try again", "no", /*fails=*/true},
    };
}

void SignupScript::append_clean(std::string_view chunk) {
    // ANSI state must survive chunk boundaries, so strip here byte by byte.
    std::string clean;
    clean.reserve(chunk.size());
    for (const char c : chunk) {
        const auto u = static_cast<unsigned char>(c);
        if (!in_escape_) {
            if (u == 0x1b) {
                in_escape_ = true;
                escape_csi_ = false;
            } else if (c != '\r') {
                clean.push_back(c);
            }
        } else if (!escape_csi_) {
            if (c == '[') escape_csi_ = true;
            else in_escape_ = false;
        } else if (u >= 0x40 && u <= 0x7e) {
            in_escape_ = false;
        }
    }
    pending_ += clean;
    // Bound the pending text: a prompt is never this long.
    if (pending_.size() > 16384) pending_.erase(0, pending_.size() - 8192);

    for (const char c : clean) {
        // A prompt ends with the "$:" input marker and no newline: end the
        // line there, so the transcript shows one question per line.
        const bool marker = c == ':' && !partial_line_.empty() && partial_line_.back() == '$';
        if (c != '\n' && !marker) {
            partial_line_.push_back(c);
            continue;
        }
        if (marker) partial_line_.pop_back();
        if (const auto pos = partial_line_.find(kKeyMarker); pos != std::string::npos) {
            const std::string key =
                normalize_key(partial_line_.substr(pos + std::char_traits<char>::length(kKeyMarker)));
            if (valid_sharing_key(key)) key_ = key;
        } else if (const auto p = partial_line_.find("sharing key ("); p != std::string::npos &&
                   key_.empty()) {
            // The wizard's own success line: "Your sharing key (xxxx) has been
            // configured and emailed to you". A fallback: the helper's marker wins.
            const std::string key = partial_line_.substr(p + 13, 16);
            if (valid_sharing_key(key) && partial_line_.size() > p + 29 &&
                partial_line_[p + 29] == ')')
                key_ = key;
        }
        lines_.push_back(partial_line_);
        if (lines_.size() > kMaxLines) lines_.pop_front();
        partial_line_.clear();
    }
}

std::optional<std::string> SignupScript::on_output(std::string_view chunk) {
    append_clean(chunk);
    if (failed_) return std::nullopt;
    return try_answer(/*idle=*/false);
}

std::optional<std::string> SignupScript::on_idle() {
    if (failed_) return std::nullopt;
    return try_answer(/*idle=*/true);
}

std::optional<std::string> SignupScript::try_answer(bool idle) {
    const Rule* best = nullptr;
    size_t best_pos = 0;
    for (const auto& rule : rules_) {
        const size_t pos = pending_.rfind(rule.token);
        if (pos == std::string::npos) continue;
        if (!best || pos > best_pos) {
            best = &rule;
            best_pos = pos;
        }
    }
    if (!best) {
        // sudo or polkit asking for a password: nobody can answer it here.
        if (pending_.find("assword") != std::string::npos) {
            fail("a password was requested (sudo is not set up for zeroairfeeder-ctl)");
        }
        return std::nullopt;
    }
    const bool ready = pending_.find("$:", best_pos) != std::string::npos || idle;
    if (!ready) return std::nullopt;

    const int count = ++asked_[best->token];
    if (count > kMaxAsks) {
        fail(std::string("the wizard did not accept the answer to \"") + best->token + "\"");
        return std::nullopt;
    }
    if (best->fails) fail("FR24 refused the signup");
    pending_.clear();
    return best->answer;
}

void SignupScript::fail(std::string message) {
    if (failed_) return;
    failed_ = true;
    const std::string detail = tail(3);
    error_ = detail.empty() ? std::move(message) : message + ": " + detail;
}

std::string SignupScript::tail(size_t n, const char* separator) const {
    std::string out;
    size_t taken = 0;
    std::deque<std::string> picked;
    for (auto it = lines_.rbegin(); it != lines_.rend() && taken < n; ++it) {
        if (it->find_first_not_of(" \t") == std::string::npos) continue;
        picked.push_front(*it);
        ++taken;
    }
    if (taken < n && partial_line_.find_first_not_of(" \t$:") != std::string::npos)
        picked.push_back(partial_line_);
    for (const auto& l : picked) {
        if (!out.empty()) out += separator;
        out += l;
    }
    return out;
}

} // namespace feeder
