/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "fr24_status.h"

#include "feeder_config.h"

#include <nlohmann/json.hpp>

#include <cstdlib>
#include <sstream>

namespace feeder {

std::string Fr24Status::get(const std::string& key) const {
    const auto it = values.find(key);
    return it == values.end() ? std::string{} : it->second;
}

Fr24Status parse_decoder_txt(const std::string& text) {
    Fr24Status st;
    if (text.empty()) return st;
    st.values = parse_ini(text);
    st.present = !st.values.empty();
    const std::string t = st.get("time_update_utc_s");
    if (!t.empty()) {
        char* end = nullptr;
        const long long v = std::strtoll(t.c_str(), &end, 10);
        if (end != t.c_str() && *end == '\0' && v > 0) st.updated_utc = v;
    }
    return st;
}

bool is_fresh(const Fr24Status& status, int64_t now_utc, int max_age_s) {
    if (!status.present || status.updated_utc <= 0) return false;
    const int64_t age = now_utc - status.updated_utc;
    return age >= -max_age_s && age <= max_age_s; // tolerate a small clock skew
}

AircraftSummary parse_aircraft_json(const std::string& text) {
    AircraftSummary out;
    if (text.empty()) return out;
    const auto doc = nlohmann::json::parse(text, nullptr, /*allow_exceptions=*/false);
    if (doc.is_discarded() || !doc.is_object()) return out;
    out.present = true;
    if (const auto it = doc.find("now"); it != doc.end() && it->is_number()) out.now = it->get<double>();
    if (const auto it = doc.find("messages"); it != doc.end() && it->is_number())
        out.messages = it->get<double>();
    const auto list = doc.find("aircraft");
    if (list == doc.end() || !list->is_array()) return out;
    for (const auto& ac : *list) {
        if (!ac.is_object()) continue;
        double seen = 0.0;
        if (const auto s = ac.find("seen"); s != ac.end() && s->is_number()) seen = s->get<double>();
        if (seen > 60.0) continue;
        ++out.aircraft;
        const auto lat = ac.find("lat");
        const auto lon = ac.find("lon");
        if (lat != ac.end() && lon != ac.end() && lat->is_number() && lon->is_number())
            ++out.with_position;
    }
    return out;
}

PfStats parse_pf_stats(const std::string& text) {
    PfStats out;
    if (text.empty()) return out;
    const auto doc = nlohmann::json::parse(text, nullptr, /*allow_exceptions=*/false);
    if (doc.is_discarded() || !doc.is_object()) return out;
    out.present = true;
    const auto num = [&](const char* key) {
        const auto it = doc.find(key);
        return it != doc.end() && it->is_number() ? it->get<double>() : 0.0;
    };
    if (const auto it = doc.find("client_version"); it != doc.end() && it->is_string())
        out.version = it->get<std::string>();
    out.receiver_bytes_in = num("receiver_bytes_in");
    out.server_bytes_out = num("master_server_bytes_out");
    out.modes_packets = num("total_modes_packets");
    return out;
}

namespace {

// The text after `marker` up to the first of `stop` (or the end), trimmed.
std::string after(const std::string& line, const std::string& marker, const char* stop) {
    const auto at = line.find(marker);
    if (at == std::string::npos) return {};
    std::string v = line.substr(at + marker.size());
    const auto a = v.find_first_not_of(' ');
    if (a == std::string::npos) return {};
    v = v.substr(a);
    const auto end = v.find_first_of(stop);
    return end == std::string::npos ? v : v.substr(0, end);
}

} // namespace

RbStatus parse_rbfeeder_log(const std::string& text) {
    // The messages of rbfeeder 1.0.17 (its binary's strings).
    RbStatus st;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        if (line.find("Key accepted by server") != std::string::npos) {
            st.link = RbStatus::Link::Connected;
            st.key_accepted = true;
        } else if (line.find("Connection established.") != std::string::npos) {
            st.link = RbStatus::Link::Connected;
        } else if (line.find("Can't connect to AirNav Server") != std::string::npos ||
                   line.find("Not connected to AirNAv Server") != std::string::npos ||
                   line.find("Could not start connection") != std::string::npos) {
            st.link = RbStatus::Link::Disconnected;
            st.key_accepted = false;
        } else if (line.find("Your new key is ") != std::string::npos) {
            std::string k = after(line, "Your new key is ", ". ");
            bool ok = !k.empty();
            for (const char c : k)
                ok = ok && ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
            if (ok) st.new_key = k;
        } else if (line.find("station serial number:") != std::string::npos) {
            st.station = after(line, "station serial number:", " \r");
        } else if (line.find("Total packets sent since startup:") != std::string::npos) {
            const std::string n = after(line, "Total packets sent since startup:", " ,\r");
            char* end = nullptr;
            const long long v = std::strtoll(n.c_str(), &end, 10);
            if (!n.empty() && end && *end == '\0' && v >= 0) st.packets_total = v;
        } else if (line.find("External host connected!") != std::string::npos ||
                   line.find("Local dump connected!") != std::string::npos) {
            st.receiver = 1;
        } else if (line.find("Can't connect to external host") != std::string::npos ||
                   line.find("doesn't seem to be running") != std::string::npos) {
            st.receiver = 0;
        } else {
            continue;
        }
        st.present = true;
    }
    return st;
}

} // namespace feeder
