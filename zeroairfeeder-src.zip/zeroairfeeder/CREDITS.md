# Credits

ZeroAirFeeder is MIT-licensed. The full third-party licence texts are in /usr/share/zeroairfeeder/licenses.

## ZeroRadio toolkit (MIT)
The app shell, widgets, keyboard handling, GPS reader (Cap LoRa-1262), location dialog and city list come from ZeroRadio by Andrea Salvatore (IU4APC), One Small Step Apps Ltd: github.com/andreahaku/zeroradio

## CardputerZero Template (MIT)
M5Stack's application template: parts of the toolkit and the cross-build toolchain. github.com/CardputerZero/Template

## readsb (GPL-3.0)
ADS-B decoder by wiedehopf and contributors, bundled unmodified as a separate program. Source code: github.com/wiedehopf/readsb, tag v3.16.16.

## fr24feed
Flightradar24's own feeder, downloaded by the app from their repository (repo-feed.flightradar24.com) at its first start and used unmodified under their licence. Not part of this package.

## pfclient
Plane Finder's feeder (Pinkfroot Ltd), downloaded by the app from client.planefinder.net when Plane Finder is turned on, and used unmodified under Plane Finder's terms. Not part of this package.

## rbfeeder
AirNav Systems' RadarBox feeder, downloaded by the app from their repository (apt.rb24.com) when AirNav is turned on, and used unmodified under AirNav's terms. Not part of this package.

## sdr-enthusiasts containers
How pfclient and rbfeeder are configured follows the docker-planefinder and docker-radarbox projects (github.com/sdr-enthusiasts); no code is taken from them.

## LVGL (MIT)
Graphics library: lvgl.io (with Project Nayuki's QR-Code generator, MIT, and ChaN's TJpgDec).

## nlohmann/json (MIT)
JSON for Modern C++ by Niels Lohmann.

## Fonts
Inter (SIL OFL 1.1) and Phosphor icons (MIT).

## City list
Contains data from GeoNames (geonames.org), cities15000, CC BY 4.0, from ZeroRadio.
