/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "feeder_config.h"
#include "feeder_system.h"
#include "gps_source.h"
#include "location.h"
#include "nav_provider.h"
#include "shell_viewmodel.h"

#include <memory>
#include <optional>
#include <string>
#include <vector>

namespace feeder {

// App state and actions. Three NavBar pages (key 4), each grouped by feeder:
// FEED (start/stop; one row per feeder with its own state and numbers, then
// the receiver and the GPS), KEYS (per feeder its key or share code, all
// asked the same way: enter the one you have, get a new one, show it) and
// SETUP (per feeder on/off and its options, then receiver, position, app).
// Lists have header rows (one per feeder or group) that the cursor skips.
// Settings are saved as they change; while feeding they apply when you go
// back to FEED (or at once with Save, key 8).
//
// Feeding only ever runs while the app is open and only when the user starts
// it (key 5): FeederSystem stops it with the app.
//
// The screen asks for dialogs through take_request() and reports back with the
// setters; the install and signup jobs come back through tick().
class FeederViewModel : public toolkit::ShellViewModel, public toolkit::NavProvider {
public:
    enum class Page : int { Status = 0, Account = 1, Setup = 2 };
    enum class AccountRow : int { HFr24, Fr24Key, Fr24Email, HPf, PfCode, HRb, RbKey, Count };
    enum class SetupRow : int {
        HFr24, Fr24, Mlat,
        HPf, Pf,
        HRb, Rb,
        HRx, Gain, Ppm,
        HPos, Location, Altitude,
        HApp, Programs, Theme, Language, Log, About,
        Count
    };
    // What the key menu (Enter on a key row) offers, the same for every feeder.
    enum class KeyAction { Enter, Obtain, Show };

    enum class Request {
        None,
        KeyMenu,       // key_menu_*(): enter / get / show a feeder's key
        EditKey,
        EditEmail,
        EditSignupEmail, // the e-mail, then the FR24 signup
        EditPfCode,
        EditRbKey,
        PfHowTo,       // how to get a share code, with a QR code to the page
        ShowKey,       // the whole key (to link the station to an account)
        EditLocation,  // by hand, only while the GPS has no fix
        EditAltitude,  // idem
        ConfirmSignup,
        JobPanel,      // install or signup running: show its live output
        ShowLog,
        ShowAbout,
        ShowError,     // error_title() / error_text()
    };

    enum class Tone { Neutral, Good, Warn, Bad, Off };

    FeederViewModel(FeederSystem& system, std::unique_ptr<GpsSource> gps);

    // Called by the screen every tick: system state, GPS, finished jobs.
    void tick();

    // The keyboard search at start-up: written to <runtime dir>/input.txt and
    // stderr; with no keyboard the FEED page says so (nothing else can).
    void report_input(bool searched, size_t keypads, const std::string& report);

    Page page() const;
    const SystemState& sys() const { return sys_; }
    const GpsSource::Status& gps() const { return gps_status_; }
    const FeederConfig& config() const { return cfg_; }
    int account_cursor() const { return account_cursor_; }
    int setup_cursor() const { return setup_cursor_; }

    Request take_request();

    // --- dialog results ---
    void set_key(const std::string& key);
    void set_email(const std::string& email);
    void set_signup_email(const std::string& email); // then on to the signup
    void set_pf_sharecode(const std::string& code);
    void set_rb_key(const std::string& key); // "" = let rbfeeder make one
    void set_location(const toolkit::location::Place& place);
    void set_altitude_m(int metres);
    void confirm_signup();

    // --- actions ---
    void toggle_feeding();
    void save();             // restart feeding with the new settings, if it runs
    void activate();         // Enter / ✓ on the selected row
    void install_fr24feed() { install_program(Program::Fr24feed, true); }
    void install_program(Program program, bool show_panel);
    void cancel_job() { system_.cancel_job(); }

    // --- text for the screen ---
    std::string headline(Tone& tone) const;
    static constexpr int kStatusRows = 5; // FR24, Plane Finder, AirNav, receiver, GPS
    std::string status_name(int row) const;
    std::string status_value(int row) const;
    Tone status_tone(int row) const;
    std::string account_name(int row) const;
    std::string account_value(int row) const;
    Tone account_tone(int row) const;    // header rows: is that feeder's key set
    std::string setup_name(int row) const;
    std::string setup_value(int row) const;
    static bool account_is_header(int row);
    static bool setup_is_header(int row);
    int setup_item_number() const;       // 1-based among the selectable rows
    static int setup_item_count();

    // The key menu of the feeder picked on KEYS.
    Program key_menu_feeder() const { return key_menu_feeder_; }
    std::string key_menu_title() const;
    std::string key_menu_intro() const;
    std::vector<KeyAction> key_actions() const;
    std::string key_action_text(KeyAction a) const;
    void choose_key_action(KeyAction a);
    // PfHowTo / ShowKey panels.
    static const char* pf_sharecode_url() { return "https://planefinder.net/sharing/create-sharecode"; }
    std::string pf_howto_text() const;
    std::string show_key_title() const;
    std::string show_key_text() const;
    std::string masked_key() const;
    std::string gps_text() const;

    bool job_running() const { return system_.busy(); }
    std::string system_busy_name() const { return system_.busy_name(); }
    std::string job_title() const { return panel_title_; }
    std::string job_body() const;
    std::optional<bool> job_outcome() const { return panel_outcome_; }

    std::string log_text() const;
    const std::string& error_title() const { return error_title_; }
    const std::string& error_text() const { return error_text_; }

    // --- NavProvider ---
    int nav_page_count() const override { return 3; }
    void nav_fill(int page, NavProvider::NavSlot out[5]) const override;
    void nav_activate(int page, int slot) override;
    const char* nav_page_name(int page) const override;
    toolkit::i18n::Text nav_hint(int page, int slot) const override;

    // --- keys ---
    void on_up() override { move_cursor(-1); }
    void on_down() override { move_cursor(1); }
    void on_left() override { change_value(-1); }
    void on_right() override { change_value(1); }
    void on_enter() override { activate(); }

private:
    void move_cursor(int dir);
    void change_value(int dir);
    void changed();                 // a setting changed: save it, mark it pending
    bool persist();
    void load_ui_prefs();
    void save_ui_prefs() const;
    void apply_language();          // help page for the language in use
    void apply_gps();
    void handle_result(const JobResult& r);
    void show_error(std::string title, std::string text);
    std::string field_missing_text(Field f) const;
    bool start_feeding();
    void toggle_service(SetupRow row);
    void start_signup();            // checks what the signup needs, then asks to confirm
    bool feeder_enabled(Program p) const;
    FeederConfig feeding_config() const;  // cfg_ with the feeders that are not ready off
    std::string not_ready_text() const;
    std::string feeder_problem(Program p) const; // what keeps it from feeding, "" if ready
    static Program row_program(SetupRow row);
    // A service's program as a short text: "pfclient 5.3.31", "downloading...".
    std::string program_text(Program p) const;
    std::string service_status(Program p) const; // FEED page rows

    FeederSystem& system_;
    std::unique_ptr<GpsSource> gps_;
    GpsSource::Status gps_status_;
    SystemState sys_;
    FeederConfig cfg_;
    bool pending_restart_ = false;  // settings changed while feeding
    bool first_tick_ = true;
    bool no_keyboard_ = false;
    std::string language_ = "auto"; // auto (system), en, it
    std::string input_file_;
    bool shared_location_saved_ = false;
    int account_cursor_ = static_cast<int>(AccountRow::Fr24Key);
    int setup_cursor_ = static_cast<int>(SetupRow::Fr24);
    Program key_menu_feeder_ = Program::Fr24feed;
    Program show_key_feeder_ = Program::Fr24feed;
    Page last_page_ = Page::Status;
    bool installs_ok_ = true;       // the downloads shown in the job panel
    Request request_ = Request::None;

    std::string panel_title_;
    std::string panel_result_;
    std::optional<bool> panel_outcome_;
    std::string error_title_;
    std::string error_text_;
};

} // namespace feeder
