/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "feeder_config.h"
#include "fr24_status.h"
#include "signup_script.h"
#include "supervised_process.h"

#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <optional>
#include <string>
#include <thread>
#include <vector>

namespace feeder {

// Where FeederSystem finds its programs. The device defaults are the
// installed paths; mock mode (desktop simulator, or ZEROAIRFEEDER_MOCK=1) uses
// stand-ins from the mock directory and a scratch state directory.
// The programs the helper downloads, one per service.
enum class Program { Fr24feed, Pfclient, Rbfeeder };
const char* program_name(Program p); // "fr24feed", "pfclient", "rbfeeder"

struct SystemPaths {
    bool mock = false;
    std::string ctl;          // zeroairfeeder-ctl (downloads the programs, as the user)
    std::string fr24_dir;     // where it puts fr24feed: ~/.local/share/zeroairfeeder/fr24feed
    std::string fr24feed;     // FR24's fr24feed binary, in fr24_dir
    std::string fr24_version; // file with its version, written by the helper
    std::string pf_dir;       // ~/.local/share/zeroairfeeder/pfclient, likewise
    std::string pfclient;
    std::string pf_version;
    std::string rb_dir;       // ~/.local/share/zeroairfeeder/rbfeeder, likewise
    std::string rbfeeder;
    std::string rb_version;
    std::string readsb;       // the bundled readsb
    std::string runtime_dir;  // per-user, private: ini, monitor file, aircraft.json
    std::string legacy_ini;   // /etc/fr24feed.ini of an earlier fr24feed install (key import)
    int pf_web_port = kPfWebPort; // pfclient's status page

    // The directory, binary and version file of a program.
    const std::string& dir(Program p) const;
    const std::string& binary(Program p) const;
    const std::string& version_file(Program p) const;

    static SystemPaths from_env(const std::string& install_dir, const std::string& mock_dir,
                                bool default_mock);
};

// What the feeder looks like right now (polled every second).
struct SystemState {
    bool fr24_installed = false;
    std::string fr24_version;
    bool pf_installed = false;
    std::string pf_version;
    bool rb_installed = false;
    std::string rb_version;
    bool installing = false;       // an install job is queued or running
    bool installing_fr24 = false;  // ... for this program
    bool installing_pf = false;
    bool installing_rb = false;

    bool feeding = false;          // started by the user, until stopped or the app closes
    bool fr24_on = false;          // the services this session feeds
    bool pf_on = false;
    bool rb_on = false;
    bool readsb_running = false;
    bool fr24_running = false;
    bool pf_running = false;
    bool rb_running = false;
    int readsb_restarts = 0;
    int fr24_restarts = 0;
    int pf_restarts = 0;
    int rb_restarts = 0;
    std::string readsb_error;      // its last line before it last exited
    std::string fr24_error;
    std::string pf_error;
    std::string rb_error;

    Fr24Status fr24;               // fr24feed's monitor file
    bool fr24_fresh = false;       // ... rewritten in the last 30 s by a running fr24feed
    PfStats pf;                    // pfclient's status page, while it runs
    RbStatus rb;                   // rbfeeder's log, while it runs
    std::string rb_ini_key;        // the key in our rbfeeder.ini (rbfeeder writes a new one there)
    AircraftSummary aircraft;      // readsb's aircraft.json
    std::string legacy_key;        // a key found in /etc/fr24feed.ini, "" if none

    bool installed(Program p) const;
    bool installing_program(Program p) const;
};

// A finished job (install, signup), for the UI.
struct JobResult {
    std::string name;         // "install" or "signup"
    Program program = Program::Fr24feed; // install: which one
    bool ok = false;
    std::string message;      // the last meaningful line, or the error
    std::string output;       // everything it printed
    std::string sharing_key;  // signup: the new key
};

// Runs the feeder for the app: readsb and the programs of the services that
// are on (fr24feed, pfclient, rbfeeder) as child processes while
// feeding is on, never longer than the app itself (they stop with stop_feeding(),
// with the destructor, and through PR_SET_PDEATHSIG if the app dies). Also polls
// their status and runs the jobs, one at a time in order: the program
// downloads (zeroairfeeder-ctl, as the user, into the user's data directory) and
// the FR24 signup wizard. All methods are thread-safe; none blocks for long.
class FeederSystem {
public:
    explicit FeederSystem(SystemPaths paths);
    ~FeederSystem();
    FeederSystem(const FeederSystem&) = delete;
    FeederSystem& operator=(const FeederSystem&) = delete;

    SystemState state() const;

    // Writes the services' files in the runtime directory and starts readsb
    // and the program of each service that is on. "" on success, else why not
    // (the UI shows it).
    std::string start_feeding(const FeederConfig& cfg);
    void stop_feeding();

    // The programs' last output lines, oldest first.
    std::string log_text() const;

    // Queues a download; false if that one is already queued or running.
    bool submit_install(Program program);
    bool submit_signup(SignupAnswers answers); // false while any job is queued or running
    void cancel_job();
    bool busy() const;
    std::string busy_name() const;
    std::string live_output() const;
    std::optional<JobResult> take_result();

    // The helper's command line for a download.
    std::vector<std::string> install_command(Program program) const;

    const SystemPaths& paths() const { return paths_; }

private:
    struct Job {
        std::string name;
        Program program = Program::Fr24feed;
        std::optional<SignupAnswers> signup;
    };

    void poll_loop();
    void poll_once();
    void job_loop();
    JobResult run_job(const Job& job);
    bool submit(Job job);
    std::string read_version(Program p) const;

    SystemPaths paths_;
    SupervisedProcess readsb_{"readsb"};
    SupervisedProcess fr24feed_{"fr24feed"};
    SupervisedProcess pfclient_{"pfclient"};
    SupervisedProcess rbfeeder_{"rbfeeder"};
    std::atomic<bool> feeding_{false};
    std::atomic<bool> fr24_on_{false};
    std::atomic<bool> pf_on_{false};
    std::atomic<bool> rb_on_{false};

    mutable std::mutex mutex_;
    std::condition_variable cv_;
    SystemState state_;
    std::deque<Job> pending_;
    std::string busy_name_;
    std::optional<Program> busy_program_; // the install running now
    std::string live_;
    std::deque<JobResult> results_;
    std::atomic<bool> cancel_{false};
    std::atomic<bool> running_{true};
    std::thread poll_thread_;
    std::thread job_thread_;
};

// The last line worth showing from a helper's output: an "ERROR: ..." line,
// sudo's own complaint, else the last non-empty line.
std::string summarize_output(const std::string& output);

// The per-user runtime directory: $XDG_RUNTIME_DIR/zeroairfeeder, else
// /tmp/zeroairfeeder-<uid>; created 0700.
std::string runtime_dir();

// The per-user data directory: $XDG_DATA_HOME/zeroairfeeder, else
// ~/.local/share/zeroairfeeder (/tmp/zeroairfeeder-data-<uid> without HOME).
std::string data_dir();

// GET http://127.0.0.1:<port><path>: the body, "" on any error or after
// `timeout_ms`. For pfclient's status page.
std::string http_get_local(int port, const std::string& path, int timeout_ms);

// Kills a leftover of ours: the process in `pid_file`, only if it still runs
// `exe` (checked through /proc/<pid>/exe). For a crash that skipped cleanup.
void kill_stale(const std::string& pid_file, const std::string& exe);

} // namespace feeder
