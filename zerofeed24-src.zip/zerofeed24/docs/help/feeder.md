# ZeroFeed24

Shares the aircraft your RTL-SDR dongle hears with Flightradar24. While feeding, the app runs two programs: readsb decodes ADS-B from the dongle, fr24feed (Flightradar24's own program) sends it to FR24. They run only while the app is open and you started feeding: closing the app stops them, and nothing starts by itself.

## First time
- Plug the RTL-SDR dongle and a 1090 MHz antenna into the USB-A port, fit the Cap LoRa-1262 (with GPS) and connect to Wi-Fi.
- At its first start the app downloads fr24feed from Flightradar24 by itself (it needs internet once) and checks Flightradar24's signature.
- Position and altitude come from the Cap's GPS: put the CardputerZero where the sky is visible until the GPS row says "fix".
- Already feeding FR24? Enter your sharing key on the FR24 page (flightradar24.com > Account > Data sharing).
- No key yet? Set your e-mail, then "Get a new key": FR24's own signup runs, the key appears on screen and FR24 e-mails it to you.
- FEED page: key 5 starts feeding, again to stop.

## Pages (key 4)
- FEED: is the feed working. Green dot: connected to FR24. Key 5 start/stop, 6 log, 7 theme, 8 close.
- FR24: sharing key, e-mail, GPS position and altitude, MLAT, signup, save. Up/Down (F/X) move, Enter (or 7) edits, 8 saves.
- SETUP: fr24feed (Enter: install, or look for a newer version), receiver gain and PPM (Left/Right, Z/C), theme, language (system, English, Italiano), log, about. 8 saves.

## Notes
- Without a GPS fix you can set position and altitude by hand on the FR24 page; the GPS replaces them as soon as it has a fix.
- Typing an e-mail: Tab types @. Shift + 2 also works if your keyboard sends it.
- MLAT needs a fixed antenna and a precise position. Leave it off on the move.
- Gain, PPM and MLAT changes made while feeding apply after Save (key 8), which restarts feeding.
- Only one program can use the dongle: close ZeroFeed24 before using ZeroRadio's SDR, ADS-B or other apps.
- The radar ID (e.g. T-LIML123) shows once FR24 has accepted your feeder; your statistics are at flightradar24.com > Account > Data sharing.
