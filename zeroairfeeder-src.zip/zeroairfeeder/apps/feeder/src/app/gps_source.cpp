/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "gps_source.h"

#include <cstdio>
#include <cstdlib>

namespace feeder {
namespace {

// The Cap LoRa-1262's GNSS module sits on the HAT UART (see ZeroRadio's
// docs/cap-lora-1262.md and the toolkit's LocationDialog).
constexpr const char* kCapGnssDevice = "/dev/ttyS0";

class RealGps : public GpsSource {
public:
    RealGps() : reader_(kCapGnssDevice) {}
    Status status() const override {
        const auto s = reader_.status();
        Status out;
        out.searching = s.searching;
        out.receiver = s.port_ok && s.data;
        out.source = s.source;
        out.satellites = s.satellites;
        out.fix = s.fix;
        out.altitude_m = s.altitude_m;
        return out;
    }

private:
    toolkit::location::GnssReader reader_;
};

class MockGps : public GpsSource {
public:
    MockGps() {
        const char* env = std::getenv("ZEROAIRFEEDER_MOCK_GPS");
        const std::string spec = env && env[0] != '\0' ? env : "45.4642,9.1900,122";
        none_ = spec == "none";
        std::sscanf(spec.c_str(), "%lf,%lf,%lf", &lat_, &lon_, &alt_);
    }
    Status status() const override {
        Status s;
        const double t = std::chrono::duration<double>(std::chrono::steady_clock::now() - start_).count();
        s.searching = t < 1.0;
        if (none_ || s.searching) return s;
        s.receiver = true;
        s.source = "shield";
        s.satellites = t < 3.0 ? 3 : 9;
        if (t >= 3.0) {
            s.fix = toolkit::geo::LatLon{lat_, lon_};
            s.altitude_m = alt_;
        }
        return s;
    }

private:
    std::chrono::steady_clock::time_point start_ = std::chrono::steady_clock::now();
    bool none_ = false;
    double lat_ = 45.4642, lon_ = 9.19, alt_ = 122.0;
};

} // namespace

std::unique_ptr<GpsSource> GpsSource::create(bool mock) {
    if (mock) return std::make_unique<MockGps>();
    return std::make_unique<RealGps>();
}

} // namespace feeder
