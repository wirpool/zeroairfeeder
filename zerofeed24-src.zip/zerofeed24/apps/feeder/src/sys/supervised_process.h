/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include "child_process.h"

#include <atomic>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace feeder {

// A program the app runs while feeding (readsb, fr24feed): started by start(),
// restarted after `respawn_ms` if it exits, stopped by stop() or the
// destructor. Its output is kept (last lines) for the log page. It is a child
// of the app with PR_SET_PDEATHSIG, so it can never outlive the app.
class SupervisedProcess {
public:
    SupervisedProcess(std::string name, int respawn_ms = 5000);
    ~SupervisedProcess();
    SupervisedProcess(const SupervisedProcess&) = delete;
    SupervisedProcess& operator=(const SupervisedProcess&) = delete;

    void start(std::vector<std::string> argv, ChildProcess::Env env = {});
    void stop();

    bool wanted() const { return wanted_.load(); }  // between start() and stop()
    bool running() const { return running_.load(); } // a process is alive now
    int restarts() const { return restarts_.load(); }
    // The last line it printed before it last exited ("" if it never did).
    std::string last_exit_line() const;
    // Its last output lines, prefixed with the name.
    std::vector<std::string> log_lines() const;

private:
    void loop(std::vector<std::string> argv, ChildProcess::Env env);
    void add_output(const std::string& chunk);

    std::string name_;
    int respawn_ms_;
    std::atomic<bool> wanted_{false};
    std::atomic<bool> running_{false};
    std::atomic<int> restarts_{0};
    std::thread thread_;
    mutable std::mutex mutex_;
    std::deque<std::string> lines_;
    std::string partial_;
    std::string last_exit_line_;
};

} // namespace feeder
