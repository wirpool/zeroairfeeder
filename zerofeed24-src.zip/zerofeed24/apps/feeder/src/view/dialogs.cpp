/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include "dialogs.h"

#include "asset_manager.h"
#include "linux_input.h"
#include "theme.h"

namespace feeder::view {
namespace {

lv_obj_t* make_root(bool dark) {
    const auto pal = ::view::palette(dark);
    auto* root = lv_obj_create(lv_layer_top());
    lv_obj_remove_style_all(root);
    lv_obj_set_size(root, ::view::kScreenWidth, ::view::kScreenHeight);
    lv_obj_set_style_bg_color(root, pal.background, 0);
    lv_obj_set_style_bg_opa(root, LV_OPA_COVER, 0);
    lv_obj_set_style_pad_all(root, 6, 0);
    lv_obj_set_style_pad_row(root, 3, 0);
    lv_obj_clear_flag(root, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_set_flex_flow(root, LV_FLEX_FLOW_COLUMN);
    return root;
}

lv_obj_t* make_label(lv_obj_t* parent, const lv_font_t* font, lv_color_t color,
                     lv_label_long_mode_t mode = LV_LABEL_LONG_WRAP) {
    auto* label = lv_label_create(parent);
    lv_obj_set_width(label, LV_PCT(100));
    lv_label_set_long_mode(label, mode);
    lv_obj_set_style_text_font(label, font ? font : &lv_font_montserrat_12, 0);
    lv_obj_set_style_text_color(label, color, 0);
    lv_label_set_text(label, "");
    return label;
}

} // namespace

// ---------------------------------------------------------------------------
// TextEntryDialog

TextEntryDialog::TextEntryDialog(app::AssetManager& assets, bool dark_mode, Options options,
                                 OnApply on_apply)
    : options_(std::move(options)), on_apply_(std::move(on_apply)), dark_(dark_mode) {
    text_ = options_.initial.substr(0, options_.max_len);
    const auto pal = ::view::palette(dark_);
    auto* title_font = assets.load_font("inter-semibold.ttf", 14);
    auto* text_font = assets.load_font("inter-regular.ttf", 12);

    root_ = make_root(dark_);
    auto* title = make_label(root_, title_font, pal.primary);
    lv_label_set_text(title, options_.title.c_str());

    input_ = make_label(root_, title_font, pal.text, LV_LABEL_LONG_WRAP);
    lv_obj_set_style_border_side(input_, LV_BORDER_SIDE_BOTTOM, 0);
    lv_obj_set_style_border_width(input_, 1, 0);
    lv_obj_set_style_border_color(input_, pal.border, 0);
    lv_obj_set_style_pad_ver(input_, 4, 0);

    error_label_ = make_label(root_, text_font, lv_color_hex(0xff6b6b));

    auto* spacer = lv_obj_create(root_);
    lv_obj_remove_style_all(spacer);
    lv_obj_set_width(spacer, LV_PCT(100));
    lv_obj_set_flex_grow(spacer, 1);

    auto* hint = make_label(root_, text_font, pal.text_disabled);
    lv_label_set_text(hint, options_.hint.c_str());

    render();
    platform::set_key_capture(key_cb, this, /*text=*/true);
}

TextEntryDialog::~TextEntryDialog() { close(); }

void TextEntryDialog::key_cb(uint32_t key, void* ctx) {
    if (auto* self = static_cast<TextEntryDialog*>(ctx)) self->on_key(key);
}

void TextEntryDialog::on_key(uint32_t key) {
    if (!root_) return;
    if (key == LV_KEY_ESC) {
        close();
        return;
    }
    if (key == LV_KEY_ENTER) {
        if (options_.validate) {
            error_ = options_.validate(text_);
            if (!error_.empty()) {
                render();
                return;
            }
        }
        // Close first, then call a copy: the callback may open the next dialog.
        const auto apply = on_apply_;
        const std::string value = text_;
        close();
        if (apply) apply(value);
        return;
    }
    if (key == LV_KEY_BACKSPACE || key == LV_KEY_DEL) {
        if (!text_.empty()) text_.pop_back();
    } else if (key == LV_KEY_NEXT && options_.tab_types_at) {
        if (text_.size() < options_.max_len) text_.push_back('@');
    } else if (key >= 0x20 && key < 0x7f) {
        const char c = static_cast<char>(key);
        if (text_.size() >= options_.max_len) return;
        if (options_.accept && !options_.accept(c)) return;
        text_.push_back(c);
    } else {
        return;
    }
    error_.clear();
    render();
}

void TextEntryDialog::render() {
    if (!root_) return;
    const std::string shown = "> " + text_ + "_";
    lv_label_set_text(input_, shown.c_str());
    lv_label_set_text(error_label_, error_.c_str());
}

void TextEntryDialog::close() {
    if (!root_) return;
    platform::set_key_capture(nullptr, nullptr);
    lv_obj_delete(root_);
    root_ = nullptr;
    input_ = nullptr;
    error_label_ = nullptr;
}

// ---------------------------------------------------------------------------
// PanelDialog

PanelDialog::PanelDialog(app::AssetManager& assets, bool dark_mode, const std::string& title,
                         const std::string& body, const std::string& footer, OnKey on_key)
    : on_key_(std::move(on_key)) {
    const auto pal = ::view::palette(dark_mode);
    auto* title_font = assets.load_font("inter-semibold.ttf", 14);
    auto* text_font = assets.load_font("inter-regular.ttf", 12);

    root_ = make_root(dark_mode);
    title_ = make_label(root_, title_font, pal.primary, LV_LABEL_LONG_DOT);
    lv_label_set_text(title_, title.c_str());

    body_label_ = make_label(root_, text_font, pal.text);
    lv_obj_set_flex_grow(body_label_, 1);
    set_body(body);

    footer_ = make_label(root_, text_font, pal.text_disabled, LV_LABEL_LONG_DOT);
    lv_label_set_text(footer_, footer.c_str());

    platform::set_key_capture(key_cb, this, /*text=*/false);
}

PanelDialog::~PanelDialog() { close(); }

void PanelDialog::key_cb(uint32_t key, void* ctx) {
    auto* self = static_cast<PanelDialog*>(ctx);
    if (!self || !self->root_) return;
    const auto handler = self->on_key_; // the handler may close or replace us
    if (handler) handler(key);
}

void PanelDialog::set_title(const std::string& text) {
    if (title_) lv_label_set_text(title_, text.c_str());
}

void PanelDialog::set_body(const std::string& text) {
    if (!body_label_ || text == body_) return;
    body_ = text;
    lv_label_set_text(body_label_, body_.c_str());
}

void PanelDialog::set_footer(const std::string& text) {
    if (footer_) lv_label_set_text(footer_, text.c_str());
}

void PanelDialog::set_accent(lv_color_t color) {
    if (title_) lv_obj_set_style_text_color(title_, color, 0);
}

void PanelDialog::close() {
    if (!root_) return;
    platform::set_key_capture(nullptr, nullptr);
    lv_obj_delete(root_);
    root_ = nullptr;
    title_ = nullptr;
    body_label_ = nullptr;
    footer_ = nullptr;
}

} // namespace feeder::view
