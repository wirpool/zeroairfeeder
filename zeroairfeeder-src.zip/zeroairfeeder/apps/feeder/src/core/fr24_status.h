/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <cstdint>
#include <map>
#include <string>

namespace feeder {

// fr24feed's monitor file, /dev/shm/decoder.txt: one key=value per line,
// rewritten every few seconds (the same file /usr/bin/fr24feed-status reads).
struct Fr24Status {
    bool present = false;            // file found and parsed
    std::map<std::string, std::string> values;
    int64_t updated_utc = 0;         // time_update_utc_s, 0 if missing

    std::string get(const std::string& key) const;

    std::string feed_status() const { return get("feed_status"); }          // "connected", ...
    std::string feed_message() const { return get("feed_status_message"); }
    std::string feed_mode() const { return get("feed_current_mode"); }      // e.g. "UDP"
    std::string radar_id() const { return get("feed_alias"); }              // e.g. "T-LIML123"
    std::string tracked() const { return get("feed_num_ac_tracked"); }
    bool receiver_connected() const { return get("rx_connected") == "1"; }
    std::string messages() const { return get("num_messages"); }
    bool mlat_ok() const { return get("mlat-ok") == "YES"; }
    std::string mlat_mode() const { return get("mlat-mode"); }
    std::string version() const { return get("build_version"); }
    bool connected() const { return feed_status() == "connected"; }
};

Fr24Status parse_decoder_txt(const std::string& text);

// True when fr24feed rewrote the file in the last `max_age_s` seconds. A stale
// file stays in /dev/shm after the service stops.
bool is_fresh(const Fr24Status& status, int64_t now_utc, int max_age_s = 60);

// What readsb's aircraft.json says about the receiver right now.
struct AircraftSummary {
    bool present = false;
    int aircraft = 0;       // heard in the last 60 s
    int with_position = 0;  // ... and with a position
    double messages = 0.0;  // total messages since readsb started
    double now = 0.0;       // readsb's own clock (unix seconds)
};

AircraftSummary parse_aircraft_json(const std::string& text);

// Plane Finder's pfclient: its status page http://127.0.0.1:30053/ajax/stats.
struct PfStats {
    bool present = false;
    std::string version;            // client_version, e.g. "5.3.31 arm64"
    double receiver_bytes_in = 0;   // from our readsb
    double server_bytes_out = 0;    // master_server_bytes_out: sent to Plane Finder
    double modes_packets = 0;       // total_modes_packets
};

PfStats parse_pf_stats(const std::string& text);

// AirNav's rbfeeder: what its log file says, the latest of each.
struct RbStatus {
    bool present = false;            // some line understood
    enum class Link { Unknown, Connected, Disconnected } link = Link::Unknown;
    bool key_accepted = false;       // "Key accepted by server"
    std::string new_key;             // "Your new key is ..." (made at the first connection)
    std::string station;             // "This is your station serial number: ..."
    long long packets_total = -1;    // "Total packets sent since startup: N"
    int receiver = -1;               // 1 connected to readsb, 0 not, -1 unknown
};

RbStatus parse_rbfeeder_log(const std::string& text);

} // namespace feeder
