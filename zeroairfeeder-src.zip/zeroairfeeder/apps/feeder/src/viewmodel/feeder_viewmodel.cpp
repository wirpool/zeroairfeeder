/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_viewmodel.h"

#include "geo.h"
#include "i18n.h"
#include "nav_hints.h"
#include "ui_const.h"

#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace feeder {
namespace {

using T = toolkit::i18n::Text;
const char* tr(const T& t) { return toolkit::i18n::pick(t); }

std::string format_text(const char* format, ...) __attribute__((format(printf, 1, 2)));
std::string format_text(const char* format, ...) {
    char buf[320];
    va_list ap;
    va_start(ap, format);
    std::vsnprintf(buf, sizeof(buf), format, ap);
    va_end(ap);
    return buf;
}

std::string ui_prefs_path() {
    const auto p = settings_path();
    return p.empty() ? std::string{} : (p.parent_path() / "ui").string();
}

// The last `n` non-empty lines of `text`.
std::string last_lines(const std::string& text, size_t n) {
    std::vector<std::string> lines;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        if (line.find_first_not_of(" \t") != std::string::npos) lines.push_back(line);
    }
    std::string out;
    const size_t from = lines.size() > n ? lines.size() - n : 0;
    for (size_t i = from; i < lines.size(); ++i) {
        if (!out.empty()) out += "\n";
        out += lines[i];
    }
    return out;
}

const T kNotSet{"not set", "non impostato"};
const T kOff{"off", "spento"};
const T kOn{"on", "acceso"};

// "abcd••••ef": enough to recognise a code without showing it.
std::string mask(const std::string& code, size_t head, size_t tail) {
    if (code.size() <= head + tail) return code;
    return code.substr(0, head) + "\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2" +
           code.substr(code.size() - tail);
}

// "1:1.0.17+trixie" -> "1.0.17": the version as the maker announces it.
std::string short_version(std::string v) {
    if (const auto colon = v.find(':'); colon != std::string::npos) v = v.substr(colon + 1);
    if (const auto plus = v.find('+'); plus != std::string::npos) v = v.substr(0, plus);
    return v;
}

const char* service_label(Program p) {
    switch (p) {
        case Program::Fr24feed: return "FR24";
        case Program::Pfclient: return "Plane Finder";
        case Program::Rbfeeder: return "AirNav";
    }
    return "";
}

// A GPS position counts as new when it moved this far (metres) or the altitude
// changed this much: small wander is not worth a write.
constexpr double kMoveM = 30.0;
constexpr double kAltStepM = 5.0;

// Phosphor-Fill glyphs not in the toolkit's ui_const.h.
constexpr const char* kIconPlay = "";
constexpr const char* kIconStop = "";
constexpr const char* kIconLog = "";  // article
constexpr const char* kIconSave = ""; // floppy disk

} // namespace

FeederViewModel::FeederViewModel(FeederSystem& system, std::unique_ptr<GpsSource> gps)
    : system_(system), gps_(std::move(gps)) {
    set_nav_provider(this);
    set_title("ZeroAirFeeder");
    load_ui_prefs();
    apply_language();
    if (auto loaded = load_settings(settings_path())) cfg_ = *loaded;
}

FeederViewModel::Page FeederViewModel::page() const {
    return static_cast<Page>(
        lv_subject_get_int(const_cast<FeederViewModel*>(this)->toolbar_page_subject()));
}

FeederViewModel::Request FeederViewModel::take_request() {
    const Request r = request_;
    request_ = Request::None;
    return r;
}

void FeederViewModel::tick() {
    sys_ = system_.state();
    if (gps_) gps_status_ = gps_->status();
    apply_gps();

    if (first_tick_) {
        first_tick_ = false;
        // A key from an earlier fr24feed setup on this device.
        if (cfg_.sharing_key.empty() && !sys_.legacy_key.empty()) {
            cfg_.sharing_key = sys_.legacy_key;
            persist();
            show_status(tr({"Sharing key read from /etc/fr24feed.ini", "Chiave letta da /etc/fr24feed.ini"}));
        }
        // The feeder programs are not in the package (they are the services'
        // own): the app downloads the ones it needs by itself, into the
        // user's data directory, and checks them (signature or checksum).
        bool panel = true;
        for (const Program p : {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder}) {
            const bool wanted = p == Program::Fr24feed ? cfg_.fr24_enabled
                                : p == Program::Pfclient ? cfg_.pf_enabled
                                                         : cfg_.rb_enabled;
            if (wanted && !sys_.installed(p) && !sys_.installing_program(p)) {
                install_program(p, panel);
                panel = false; // one panel shows them all
            }
        }
    }

    while (auto r = system_.take_result()) handle_result(*r);

    // AirNav sent rbfeeder a new key: keep it, so the station stays the same.
    if (sys_.rb_on && cfg_.rb_key.empty() && valid_rb_key(sys_.rb_ini_key)) {
        cfg_.rb_key = sys_.rb_ini_key;
        persist();
        show_status(tr({"New AirNav key received and saved (KEYS)",
                        "Nuova chiave AirNav ricevuta e salvata (CHIAVI)"}));
    }

    // Settings changed while feeding: they apply when the user is back on
    // FEED (no restart at every step of the gain, no Save to remember).
    const Page now = page();
    if (now == Page::Status && sys_.feeding && pending_restart_ && request_ == Request::None &&
        !(sys_.installing && system_.busy_name() == "install" && !panel_outcome_)) {
        if (start_feeding()) {
            sys_ = system_.state();
            show_status(tr({"Feeding restarted with the new settings", "Invio riavviato con le nuove impostazioni"}));
        }
    }
    last_page_ = now;
}

void FeederViewModel::report_input(bool searched, size_t keypads, const std::string& report) {
    if (!searched) return; // SDL simulator or remote-fb: their own keyboard
    no_keyboard_ = keypads == 0;
    input_file_ = system_.paths().runtime_dir + "/input.txt";
    std::ofstream out(input_file_, std::ios::trunc);
    out << "keypads: " << keypads << "\n" << report;
    std::fprintf(stderr, "zeroairfeeder: %zu keyboard(s)\n%s", keypads, report.c_str());
}

// The GPS fix becomes the antenna position (and its altitude, in feet for FR24).
void FeederViewModel::apply_gps() {
    if (!gps_status_.fix) return;
    const auto fix = *gps_status_.fix;
    bool changed_pos = !cfg_.has_location || cfg_.location_label != "GPS";
    if (!changed_pos) {
        changed_pos = toolkit::geo::range_nm({cfg_.lat, cfg_.lon}, fix) * 1852.0 > kMoveM;
    }
    bool changed_alt = false;
    if (gps_status_.altitude_m) {
        const double now_m = *gps_status_.altitude_m;
        changed_alt = !cfg_.has_altitude ||
                      std::fabs(feet_to_metres(cfg_.altitude_ft) - now_m) > kAltStepM;
    }
    if (!changed_pos && !changed_alt) return;
    if (changed_pos && valid_lat(fix.lat) && valid_lon(fix.lon)) {
        cfg_.has_location = true;
        cfg_.lat = fix.lat;
        cfg_.lon = fix.lon;
        cfg_.location_label = "GPS";
    }
    if (changed_alt) {
        const int feet = metres_to_feet(*gps_status_.altitude_m);
        if (valid_altitude_ft(feet)) {
            cfg_.has_altitude = true;
            cfg_.altitude_ft = feet;
        }
    }
    persist();
    if (!shared_location_saved_) {
        // Also the position ZeroRadio's ADS-B and AIS apps centre on.
        shared_location_saved_ = true;
        char label[48];
        std::snprintf(label, sizeof(label), "GPS %.3f, %.3f", fix.lat, fix.lon);
        toolkit::location::save({fix, label});
    }
}

// --- jobs and feeding ---------------------------------------------------------

void FeederViewModel::show_error(std::string title, std::string text) {
    error_title_ = std::move(title);
    error_text_ = std::move(text);
    request_ = Request::ShowError;
}

void FeederViewModel::handle_result(const JobResult& r) {
    if (r.name == "install") {
        const char* prog = program_name(r.program);
        const SystemState now = system_.state();
        const std::string version = r.program == Program::Pfclient   ? now.pf_version
                                    : r.program == Program::Rbfeeder ? now.rb_version
                                                                     : now.fr24_version;
        std::string line;
        if (r.ok) {
            line = format_text(tr({"%s %s is installed.", "%s %s è installato."}), prog,
                               short_version(version).c_str());
        } else {
            installs_ok_ = false;
            line = format_text(tr({"%s could not be installed: ", "Impossibile installare %s: "}), prog) + r.message;
        }
        if (!panel_result_.empty()) panel_result_ += "\n";
        panel_result_ += line;
        // The panel shows the outcome once the last queued download is done.
        if (!system_.busy() || system_.busy_name() != "install") {
            if (!installs_ok_) {
                panel_result_ += "\n";
                panel_result_ += tr({"Check the internet connection, then SETUP > Update programs > Enter.",
                                     "Controlla la connessione a internet, poi SETUP > Aggiorna programmi > Invio."});
            }
            panel_outcome_ = installs_ok_;
        }
        sys_ = system_.state();
        std::string toast = format_text(r.ok ? tr({"%s installed", "%s installato"})
                                             : tr({"%s not installed", "%s non installato"}),
                                        prog);
        // Still something to do for that feeder: say what, in the same line.
        if (r.ok && feeder_enabled(r.program)) {
            const std::string next = feeder_problem(r.program);
            if (!next.empty()) toast += ". " + std::string(tr({"Now: ", "Ora: "})) + next;
        }
        show_status(toast);
        // Feeding already: the feeder that was waiting for it joins (FEED).
        if (r.ok && sys_.feeding && feeder_enabled(r.program)) pending_restart_ = true;
    } else if (r.name == "signup") {
        panel_outcome_ = r.ok;
        if (r.ok) {
            cfg_.sharing_key = r.sharing_key;
            persist();
            panel_result_ = format_text(tr({"Your sharing key: %s\nFR24 also e-mailed it to %s.\n"
                                            "It is saved. Press 5 on the FEED page to start feeding.",
                                            "La tua chiave di condivisione: %s\nFR24 l'ha inviata anche a "
                                            "%s.\nÈ salvata. Premi 5 nella pagina FEED per avviare l'invio."}),
                                        r.sharing_key.c_str(), cfg_.email.c_str());
            if (sys_.feeding) start_feeding(); // pick up the new key
        } else {
            panel_result_ = std::string(tr({"Signup failed: ", "Registrazione non riuscita: "})) + r.message;
        }
    }
}

std::string FeederViewModel::job_body() const {
    if (panel_outcome_) return panel_result_;
    const std::string live = last_lines(system_.live_output(), 7);
    return live.empty() ? tr({"Working...", "In corso..."}) : live;
}

std::string FeederViewModel::log_text() const {
    const std::string text = system_.log_text();
    if (!text.empty()) return text;
    return tr({"Nothing yet: readsb and the services' programs write here while feeding.",
               "Ancora niente: readsb e i programmi dei servizi scrivono qui durante l'invio."});
}

void FeederViewModel::install_program(Program program, bool show_panel) {
    // Another download already in the panel: this one joins it.
    const bool joining = !panel_outcome_ && system_.busy() && system_.busy_name() == "install";
    if (!system_.submit_install(program)) {
        show_status(system_.busy_name() == "signup"
                        ? tr({"Busy, try again in a moment", "Occupato, riprova tra poco"})
                        : tr({"Already downloading it", "Download già in corso"}));
        return;
    }
    sys_ = system_.state();
    if (joining) {
        panel_title_ = tr({"Installing the programs", "Installazione dei programmi"});
        return;
    }
    panel_title_ = format_text(tr({"Installing %s", "Installazione di %s"}), program_name(program));
    panel_outcome_.reset();
    panel_result_.clear();
    installs_ok_ = true;
    if (show_panel) request_ = Request::JobPanel;
}

std::string FeederViewModel::program_text(Program p) const {
    if (sys_.installing_program(p)) return tr({"downloading...", "download..."});
    if (!sys_.installed(p)) return tr({"missing, Enter", "manca, Invio"});
    const std::string& v = p == Program::Pfclient   ? sys_.pf_version
                           : p == Program::Rbfeeder ? sys_.rb_version
                                                    : sys_.fr24_version;
    const std::string shown = short_version(v);
    return shown.empty() ? std::string(tr({"installed", "installato"})) : shown;
}

std::string FeederViewModel::field_missing_text(Field f) const {
    switch (f) {
        case Field::Key:
            return tr({"FR24 needs its sharing key: KEYS > Flightradar24",
                       "Per FR24 serve la chiave: CHIAVI > Flightradar24"});
        case Field::Email:
            return tr({"FR24 needs your e-mail to sign up", "Per registrarti a FR24 serve l'e-mail"});
        case Field::Location:
            return tr({"Waiting for the GPS position (or set it by hand: SETUP > Position)",
                       "In attesa della posizione GPS (o impostala a mano: SETUP > Posizione)"});
        case Field::Altitude:
            return tr({"Waiting for the GPS altitude (or set it by hand: SETUP > Altitude)",
                       "In attesa dell'altitudine GPS (o impostala a mano: SETUP > Altitudine)"});
        case Field::NoService:
            return tr({"No feeder is on: SETUP > Flightradar24, Plane Finder or AirNav",
                       "Nessun feeder attivo: SETUP > Flightradar24, Plane Finder o AirNav"});
        case Field::PfShareCode:
            return tr({"Plane Finder needs its share code: KEYS > Plane Finder",
                       "Per Plane Finder serve lo share code: CHIAVI > Plane Finder"});
        case Field::None: break;
    }
    return {};
}

bool FeederViewModel::feeder_enabled(Program p) const {
    return p == Program::Fr24feed ? cfg_.fr24_enabled : p == Program::Pfclient ? cfg_.pf_enabled : cfg_.rb_enabled;
}

std::string FeederViewModel::feeder_problem(Program p) const {
    if (!sys_.installed(p)) {
        if (sys_.installing_program(p)) return tr({"downloading its program...", "download del programma..."});
        return tr({"program missing: SETUP > Update programs", "manca il programma: SETUP > Aggiorna programmi"});
    }
    switch (p) {
        case Program::Fr24feed:
            if (!valid_sharing_key(cfg_.sharing_key)) return tr({"no sharing key: KEYS", "manca la chiave: CHIAVI"});
            break;
        case Program::Pfclient:
            if (!valid_pf_sharecode(cfg_.pf_sharecode)) return tr({"no share code: KEYS", "manca lo share code: CHIAVI"});
            if (!cfg_.has_location) return tr({"waiting for the position (GPS)", "attesa della posizione (GPS)"});
            break;
        case Program::Rbfeeder: break; // AirNav gives a key at the first connection
    }
    return {};
}

FeederConfig FeederViewModel::feeding_config() const {
    // Feed the feeders that are ready; the others say on FEED what they miss.
    FeederConfig c = cfg_;
    c.fr24_enabled = c.fr24_enabled && feeder_problem(Program::Fr24feed).empty();
    c.pf_enabled = c.pf_enabled && feeder_problem(Program::Pfclient).empty();
    c.rb_enabled = c.rb_enabled && feeder_problem(Program::Rbfeeder).empty();
    return c;
}

bool FeederViewModel::start_feeding() {
    const FeederConfig c = feeding_config();
    if (!c.fr24_enabled && !c.pf_enabled && !c.rb_enabled) {
        system_.stop_feeding();
        pending_restart_ = false;
        show_error(tr({"Nothing to feed", "Niente da inviare"}), not_ready_text());
        return false;
    }
    const std::string error = system_.start_feeding(c);
    if (!error.empty()) {
        show_error(tr({"Could not start feeding", "Impossibile avviare l'invio"}), error);
        return false;
    }
    pending_restart_ = false;
    return true;
}

// Why no feeder can start, one line per feeder that is on.
std::string FeederViewModel::not_ready_text() const {
    std::string out;
    for (const Program p : {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder}) {
        if (!feeder_enabled(p)) continue;
        if (!out.empty()) out += "\n";
        out += std::string(service_label(p)) + ": " + feeder_problem(p);
    }
    if (out.empty()) out = field_missing_text(Field::NoService);
    return out;
}

void FeederViewModel::toggle_feeding() {
    if (sys_.feeding) {
        system_.stop_feeding();
        sys_ = system_.state();
        pending_restart_ = false;
        show_status(tr({"Feeding stopped", "Invio dati fermato"}));
        bump_nav_refresh();
        return;
    }
    if (!cfg_.fr24_enabled && !cfg_.pf_enabled && !cfg_.rb_enabled) {
        show_status(field_missing_text(Field::NoService));
        return;
    }
    // A feeder that is on but has no program yet: get it now (and start the
    // others meanwhile; it joins when it is there).
    for (const Program p : {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder})
        if (feeder_enabled(p) && !sys_.installed(p) && !sys_.installing_program(p)) install_program(p, false);
    sys_ = system_.state();
    if (start_feeding()) {
        sys_ = system_.state();
        std::string skipped;
        for (const Program p : {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder}) {
            if (!feeder_enabled(p) || feeder_problem(p).empty()) continue;
            if (!skipped.empty()) skipped += ", ";
            skipped += service_label(p);
        }
        if (skipped.empty()) show_status(tr({"Feeding started", "Invio dati avviato"}));
        else show_status(format_text(tr({"Feeding started; not ready: %s (see FEED)",
                                         "Invio avviato; non pronti: %s (vedi FEED)"}), skipped.c_str()));
        bump_nav_refresh();
    }
}

void FeederViewModel::save() {
    if (!persist()) {
        show_status(tr({"Could not write the settings file", "Impossibile scrivere il file delle impostazioni"}));
        return;
    }
    if (sys_.feeding && pending_restart_) {
        if (start_feeding()) show_status(tr({"Saved, feeding restarted", "Salvato, invio riavviato"}));
        return;
    }
    show_status(tr({"Saved", "Salvato"}));
}

void FeederViewModel::confirm_signup() {
    SignupAnswers a;
    a.email = cfg_.email;
    a.lat = cfg_.lat;
    a.lon = cfg_.lon;
    a.altitude_ft = cfg_.altitude_ft;
    a.mlat = cfg_.mlat;
    persist();
    if (!system_.submit_signup(a)) {
        show_status(tr({"Busy, try again in a moment", "Occupato, riprova tra poco"}));
        return;
    }
    panel_title_ = tr({"Signing up with Flightradar24", "Registrazione su Flightradar24"});
    panel_outcome_.reset();
    panel_result_.clear();
    request_ = Request::JobPanel;
}

void FeederViewModel::start_signup() {
    if (!sys_.fr24_installed) {
        if (!sys_.installing_fr24) install_program(Program::Fr24feed, false);
        show_error(tr({"Get a new FR24 key", "Nuova chiave FR24"}),
                   tr({"The signup is done by fr24feed, which is still downloading. Try again in a moment "
                       "(it needs internet).",
                       "La registrazione la fa fr24feed, che si sta ancora scaricando. Riprova tra poco "
                       "(serve internet)."}));
        return;
    }
    const Field f = missing_for_signup(cfg_);
    if (f == Field::Email) {
        request_ = Request::EditSignupEmail;
        return;
    }
    if (f != Field::None) {
        show_error(tr({"Get a new FR24 key", "Nuova chiave FR24"}),
                   field_missing_text(f) + "\n\n" +
                       tr({"FR24 registers the feeder at the antenna position, so the signup needs it.",
                           "FR24 registra il feeder alla posizione dell'antenna, per questo la registrazione "
                           "ne ha bisogno."}));
        return;
    }
    request_ = Request::ConfirmSignup;
}

void FeederViewModel::set_signup_email(const std::string& email) {
    if (!valid_email(email)) return;
    cfg_.email = email;
    persist();
    start_signup();
}

Program FeederViewModel::row_program(SetupRow row) {
    return row == SetupRow::Pf ? Program::Pfclient : row == SetupRow::Rb ? Program::Rbfeeder : Program::Fr24feed;
}

bool FeederViewModel::account_is_header(int row) {
    const auto r = static_cast<AccountRow>(row);
    return r == AccountRow::HFr24 || r == AccountRow::HPf || r == AccountRow::HRb;
}

bool FeederViewModel::setup_is_header(int row) {
    switch (static_cast<SetupRow>(row)) {
        case SetupRow::HFr24:
        case SetupRow::HPf:
        case SetupRow::HRb:
        case SetupRow::HRx:
        case SetupRow::HPos:
        case SetupRow::HApp: return true;
        default: return false;
    }
}

int FeederViewModel::setup_item_number() const {
    int n = 0;
    for (int r = 0; r <= setup_cursor_; ++r)
        if (!setup_is_header(r)) ++n;
    return n;
}

int FeederViewModel::setup_item_count() {
    int n = 0;
    for (int r = 0; r < static_cast<int>(SetupRow::Count); ++r)
        if (!setup_is_header(r)) ++n;
    return n;
}

void FeederViewModel::activate() {
    if (page() == Page::Account) {
        switch (static_cast<AccountRow>(account_cursor_)) {
            case AccountRow::Fr24Key: key_menu_feeder_ = Program::Fr24feed; request_ = Request::KeyMenu; break;
            case AccountRow::PfCode: key_menu_feeder_ = Program::Pfclient; request_ = Request::KeyMenu; break;
            case AccountRow::RbKey: key_menu_feeder_ = Program::Rbfeeder; request_ = Request::KeyMenu; break;
            case AccountRow::Fr24Email: request_ = Request::EditEmail; break;
            default: break;
        }
    } else if (page() == Page::Setup) {
        const auto row = static_cast<SetupRow>(setup_cursor_);
        switch (row) {
            case SetupRow::Fr24:
            case SetupRow::Pf:
            case SetupRow::Rb: {
                const Program p = row_program(row);
                // On but its program is missing (a failed download): Enter retries.
                if (feeder_enabled(p) && !sys_.installed(p)) {
                    if (sys_.installing_program(p)) request_ = Request::JobPanel;
                    else install_program(p, true);
                } else {
                    toggle_service(row);
                }
                break;
            }
            case SetupRow::Location:
            case SetupRow::Altitude:
                if (gps_status_.fix) {
                    show_status(tr({"Position and altitude come from the GPS",
                                    "Posizione e altitudine arrivano dal GPS"}));
                } else {
                    request_ = row == SetupRow::Location ? Request::EditLocation : Request::EditAltitude;
                }
                break;
            case SetupRow::Programs: {
                // Installs what is missing, or looks for newer fr24feed and
                // rbfeeder (the helper keeps the current one when there is none).
                if (sys_.installing) {
                    request_ = Request::JobPanel;
                    break;
                }
                bool first = true;
                for (const Program p : {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder}) {
                    if (!feeder_enabled(p)) continue;
                    install_program(p, first);
                    first = false;
                }
                if (first) show_status(tr({"No feeder is on", "Nessun feeder attivo"}));
                break;
            }
            case SetupRow::Mlat:
            case SetupRow::Gain:
            case SetupRow::Ppm:
            case SetupRow::Theme:
            case SetupRow::Language: change_value(1); break;
            case SetupRow::Log: request_ = Request::ShowLog; break;
            case SetupRow::About: request_ = Request::ShowAbout; break;
            default: break;
        }
    }
}

void FeederViewModel::move_cursor(int dir) {
    // Header rows are titles: the cursor jumps over them.
    if (page() == Page::Account) {
        const int n = static_cast<int>(AccountRow::Count);
        do account_cursor_ = (account_cursor_ + dir + n) % n;
        while (account_is_header(account_cursor_));
    } else if (page() == Page::Setup) {
        const int n = static_cast<int>(SetupRow::Count);
        do setup_cursor_ = (setup_cursor_ + dir + n) % n;
        while (setup_is_header(setup_cursor_));
    }
}

void FeederViewModel::change_value(int dir) {
    if (page() == Page::Account) {
        // Left/Right on a key row opens its menu too: one gesture less to learn.
        const auto row = static_cast<AccountRow>(account_cursor_);
        if (row == AccountRow::Fr24Key || row == AccountRow::PfCode || row == AccountRow::RbKey) activate();
        return;
    }
    if (page() != Page::Setup) return;
    const auto row = static_cast<SetupRow>(setup_cursor_);
    switch (row) {
        case SetupRow::Fr24:
        case SetupRow::Pf:
        case SetupRow::Rb: toggle_service(row); break;
        case SetupRow::Mlat:
            cfg_.mlat = !cfg_.mlat;
            changed();
            if (cfg_.mlat)
                show_status(tr({"MLAT needs a fixed antenna and a precise position",
                                "La MLAT richiede un'antenna fissa e una posizione precisa"}));
            break;
        case SetupRow::Gain: {
            const auto& g = gain_choices();
            int i = 0;
            for (int k = 0; k < static_cast<int>(g.size()); ++k)
                if (g[static_cast<size_t>(k)] == cfg_.gain) i = k;
            const int n = static_cast<int>(g.size());
            cfg_.gain = g[static_cast<size_t>((i + dir + n) % n)];
            changed();
            break;
        }
        case SetupRow::Ppm:
            if (valid_ppm(cfg_.ppm + dir)) {
                cfg_.ppm += dir;
                changed();
            }
            break;
        case SetupRow::Theme:
            toggle_dark_mode();
            save_ui_prefs();
            bump_nav_refresh();
            break;
        case SetupRow::Language: {
            static const char* kOrder[] = {"auto", "en", "it"};
            int i = 0;
            for (int k = 0; k < 3; ++k)
                if (language_ == kOrder[k]) i = k;
            language_ = kOrder[(i + (dir < 0 ? 2 : 1)) % 3];
            apply_language();
            save_ui_prefs();
            bump_nav_refresh();
            break;
        }
        default: break;
    }
}

void FeederViewModel::toggle_service(SetupRow row) {
    bool* flag = row == SetupRow::Fr24 ? &cfg_.fr24_enabled
                 : row == SetupRow::Pf ? &cfg_.pf_enabled
                                       : &cfg_.rb_enabled;
    const Program p = row_program(row);
    *flag = !*flag;
    changed();
    if (!*flag) return;
    // Turned on: get its program now, if it is not there yet, and say what
    // else it needs.
    if (!sys_.installed(p) && !sys_.installing_program(p)) install_program(p, false);
    sys_ = system_.state();
    if (p == Program::Fr24feed && !valid_sharing_key(cfg_.sharing_key)) {
        show_status(tr({"Now its key: KEYS > Flightradar24", "Ora la chiave: CHIAVI > Flightradar24"}));
    } else if (p == Program::Pfclient && !valid_pf_sharecode(cfg_.pf_sharecode)) {
        show_status(tr({"Now its share code: KEYS > Plane Finder", "Ora lo share code: CHIAVI > Plane Finder"}));
    } else if (sys_.installing_program(p)) {
        show_status(format_text(tr({"Downloading %s for %s...", "Scarico %s per %s..."}), program_name(p),
                                service_label(p)));
    }
}

// --- key menu (KEYS page) ---------------------------------------------------

std::string FeederViewModel::key_menu_title() const {
    switch (key_menu_feeder_) {
        case Program::Fr24feed: return tr({"Flightradar24 sharing key", "Chiave di Flightradar24"});
        case Program::Pfclient: return tr({"Plane Finder share code", "Share code di Plane Finder"});
        case Program::Rbfeeder: return tr({"AirNav RadarBox sharing key", "Chiave di AirNav RadarBox"});
    }
    return {};
}

std::string FeederViewModel::key_menu_intro() const {
    switch (key_menu_feeder_) {
        case Program::Fr24feed:
            return valid_sharing_key(cfg_.sharing_key)
                       ? tr({"Key set: ", "Chiave impostata: "}) + masked_key()
                       : tr({"No key yet.", "Nessuna chiave."});
        case Program::Pfclient:
            return valid_pf_sharecode(cfg_.pf_sharecode)
                       ? tr({"Share code set: ", "Share code impostato: "}) + mask(cfg_.pf_sharecode, 4, 2)
                       : tr({"No share code yet.", "Nessuno share code."});
        case Program::Rbfeeder:
            return valid_rb_key(cfg_.rb_key)
                       ? tr({"Key set: ", "Chiave impostata: "}) + mask(cfg_.rb_key, 4, 2)
                       : tr({"Automatic: AirNav gives a key at the first connection.",
                             "Automatica: AirNav assegna una chiave alla prima connessione."});
    }
    return {};
}

std::vector<FeederViewModel::KeyAction> FeederViewModel::key_actions() const {
    std::vector<KeyAction> out = {KeyAction::Enter, KeyAction::Obtain};
    const bool set = key_menu_feeder_ == Program::Fr24feed   ? valid_sharing_key(cfg_.sharing_key)
                     : key_menu_feeder_ == Program::Pfclient ? valid_pf_sharecode(cfg_.pf_sharecode)
                                                             : valid_rb_key(cfg_.rb_key);
    if (set) out.push_back(KeyAction::Show);
    return out;
}

std::string FeederViewModel::key_action_text(KeyAction a) const {
    const bool pf = key_menu_feeder_ == Program::Pfclient;
    switch (a) {
        case KeyAction::Enter:
            return pf ? tr({"I have one: type it", "Ce l'ho: lo inserisco"})
                      : tr({"I have one: type it", "Ce l'ho: la inserisco"});
        case KeyAction::Obtain:
            switch (key_menu_feeder_) {
                case Program::Fr24feed: return tr({"Get a new one (FR24 signup)", "Ottienine una nuova (registrazione FR24)"});
                case Program::Pfclient:
                    return tr({"Get a new one (QR code for the phone)", "Ottienine uno nuovo (QR per il telefono)"});
                case Program::Rbfeeder:
                    return valid_rb_key(cfg_.rb_key)
                               ? tr({"Get a new one (a new station)", "Ottienine una nuova (nuova stazione)"})
                               : tr({"Get a new one (automatic)", "Ottienine una nuova (automatica)"});
            }
            break;
        case KeyAction::Show: return tr({"Show it in full", "Mostrala per intero"});
    }
    return {};
}

void FeederViewModel::choose_key_action(KeyAction a) {
    const Program p = key_menu_feeder_;
    switch (a) {
        case KeyAction::Enter:
            request_ = p == Program::Fr24feed   ? Request::EditKey
                       : p == Program::Pfclient ? Request::EditPfCode
                                                : Request::EditRbKey;
            break;
        case KeyAction::Obtain:
            if (p == Program::Fr24feed) {
                // The e-mail first (prefilled), then what the signup needs.
                request_ = Request::EditSignupEmail;
            } else if (p == Program::Pfclient) {
                request_ = Request::PfHowTo;
            } else {
                cfg_.rb_key.clear();
                changed();
                show_status(sys_.feeding
                                ? tr({"AirNav key: automatic, a new one comes when you go back to FEED",
                                      "Chiave AirNav automatica: arriva quando torni a FEED"})
                                : tr({"AirNav key: automatic, it comes when you start feeding (FEED, 5)",
                                      "Chiave AirNav automatica: arriva quando avvii l'invio (FEED, 5)"}));
            }
            break;
        case KeyAction::Show:
            show_key_feeder_ = p;
            request_ = Request::ShowKey;
            break;
    }
}

std::string FeederViewModel::pf_howto_text() const {
    std::string pos = cfg_.has_location ? format_text("%.5f %.5f", cfg_.lat, cfg_.lon)
                                        : std::string(tr({"(no position yet)", "(posizione non ancora nota)"}));
    return format_text(tr({"1. Scan the QR code with\nthe phone.\n2. Give your e-mail and\nthe antenna position:\n%s\n3. Type the code here.",
                           "1. Inquadra il QR col\ntelefono.\n2. Inserisci e-mail e\nposizione dell'antenna:\n%s\n3. Scrivi qui il codice."}),
                       pos.c_str());
}

std::string FeederViewModel::show_key_title() const {
    switch (show_key_feeder_) {
        case Program::Fr24feed: return tr({"Flightradar24 sharing key", "Chiave di Flightradar24"});
        case Program::Pfclient: return tr({"Plane Finder share code", "Share code di Plane Finder"});
        case Program::Rbfeeder: return tr({"AirNav RadarBox sharing key", "Chiave di AirNav RadarBox"});
    }
    return {};
}

std::string FeederViewModel::show_key_text() const {
    switch (show_key_feeder_) {
        case Program::Fr24feed:
            return cfg_.sharing_key + "\n\n" +
                   tr({"Keep it: it is your feeder at flightradar24.com > Account > Data sharing.",
                       "Conservala: è il tuo feeder su flightradar24.com > Account > Data sharing."});
        case Program::Pfclient:
            return cfg_.pf_sharecode + "\n\n" +
                   tr({"Your receiver at planefinder.net > Your Receivers.",
                       "Il tuo ricevitore su planefinder.net > Your Receivers."});
        case Program::Rbfeeder:
            return cfg_.rb_key + "\n\n" +
                   tr({"Link the station to your account at airnavradar.com with this key.",
                       "Collega la stazione al tuo account su airnavradar.com con questa chiave."});
    }
    return {};
}

void FeederViewModel::changed() {
    persist();
    if (sys_.feeding) pending_restart_ = true;
}

bool FeederViewModel::persist() { return save_settings(settings_path(), cfg_); }

// --- dialog results ---------------------------------------------------------

void FeederViewModel::set_key(const std::string& key) {
    const std::string k = normalize_key(key);
    if (!valid_sharing_key(k)) return;
    cfg_.sharing_key = k;
    changed();
}

void FeederViewModel::set_email(const std::string& email) {
    if (!valid_email(email)) return;
    cfg_.email = email;
    persist(); // only used to sign up
}

void FeederViewModel::set_pf_sharecode(const std::string& code) {
    const std::string c = normalize_key(code);
    if (!valid_pf_sharecode(c)) return;
    cfg_.pf_sharecode = c;
    changed();
}

void FeederViewModel::set_rb_key(const std::string& key) {
    const std::string k = normalize_key(key);
    if (!k.empty() && !valid_rb_key(k)) return;
    cfg_.rb_key = k;
    changed();
}

void FeederViewModel::set_location(const toolkit::location::Place& place) {
    if (gps_status_.fix) return; // the GPS wins
    if (!valid_lat(place.pos.lat) || !valid_lon(place.pos.lon)) return;
    cfg_.has_location = true;
    cfg_.lat = place.pos.lat;
    cfg_.lon = place.pos.lon;
    cfg_.location_label = place.label;
    changed();
}

void FeederViewModel::set_altitude_m(int metres) {
    if (gps_status_.altitude_m) return; // the GPS wins
    const int feet = metres_to_feet(metres);
    if (!valid_altitude_ft(feet)) return;
    cfg_.has_altitude = true;
    cfg_.altitude_ft = feet;
    persist(); // only used to sign up
}

// --- texts ------------------------------------------------------------------

std::string FeederViewModel::masked_key() const {
    if (!valid_sharing_key(cfg_.sharing_key)) return tr(kNotSet);
    return cfg_.sharing_key.substr(0, 4) + "\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2\xE2\x80\xA2" +
           cfg_.sharing_key.substr(12);
}

std::string FeederViewModel::gps_text() const {
    const auto& g = gps_status_;
    if (g.fix) return format_text(tr({"fix, %d satellites", "fix, %d satelliti"}), g.satellites);
    if (g.receiver) return format_text(tr({"searching, %d satellites", "in ricerca, %d satelliti"}), g.satellites);
    if (g.searching) return tr({"starting the Cap LoRa GPS...", "avvio del GPS del Cap LoRa..."});
    return tr({"no GPS found (Cap LoRa-1262)", "nessun GPS (Cap LoRa-1262)"});
}

std::string FeederViewModel::headline(Tone& tone) const {
    tone = Tone::Warn;
    if (no_keyboard_) {
        tone = Tone::Bad;
        return tr({"Keyboard not found: see ", "Tastiera non trovata: vedi "}) + input_file_;
    }
    const Program all[] = {Program::Fr24feed, Program::Pfclient, Program::Rbfeeder};
    if (!sys_.feeding) {
        int on = 0, ready = 0;
        for (const Program p : all) {
            if (!feeder_enabled(p)) continue;
            ++on;
            if (feeder_problem(p).empty()) ++ready;
        }
        if (on == 0) return tr({"No feeder is on: see SETUP", "Nessun feeder attivo: vedi SETUP"});
        if (ready == 0) return tr({"Not ready yet: see below", "Non ancora pronto: vedi sotto"});
        tone = Tone::Neutral;
        return tr({"Ready: press 5 to start feeding", "Pronto: premi 5 per avviare l'invio"});
    }
    if (!sys_.readsb_running && sys_.readsb_restarts > 0) {
        tone = Tone::Bad;
        return tr({"No receiver: is the dongle in?", "Nessun ricevitore: la chiavetta è inserita?"});
    }
    int on = 0, good = 0, bad = 0;
    for (int row = 0; row < 3; ++row) {
        const Program p = all[row];
        if (!feeder_enabled(p)) continue;
        ++on;
        const Tone t = status_tone(row);
        if (t == Tone::Good) ++good;
        if (t == Tone::Bad) ++bad;
    }
    if (bad > 0) {
        tone = Tone::Bad;
        return tr({"A feeder has a problem: see below", "Un feeder ha un problema: vedi sotto"});
    }
    if (on > 0 && good == on) {
        tone = Tone::Good;
        return good == 1 ? tr({"Feeding: all good", "Invio in corso: tutto ok"})
                         : format_text(tr({"Feeding %d services: all good", "Invio a %d servizi: tutto ok"}), good);
    }
    if (good == 0) return tr({"Starting...", "Avvio in corso..."});
    return format_text(tr({"Feeding %d of %d: see below", "Invio a %d su %d: vedi sotto"}), good, on);
}

std::string FeederViewModel::status_name(int row) const {
    static const T kNames[kStatusRows] = {
        {"Flightradar24", "Flightradar24"}, {"Plane Finder", "Plane Finder"}, {"AirNav", "AirNav"},
        {"Receiver", "Ricevitore"}, {"GPS", "GPS"},
    };
    return (row >= 0 && row < kStatusRows) ? tr(kNames[row]) : "";
}

std::string FeederViewModel::service_status(Program p) const {
    // Each feeder's row says everything about that feeder: its state, and
    // once it feeds its own numbers.
    if (!feeder_enabled(p)) return tr({"off (SETUP to turn on)", "spento (attivalo in SETUP)"});
    const bool on = p == Program::Fr24feed ? sys_.fr24_on : p == Program::Pfclient ? sys_.pf_on : sys_.rb_on;
    if (!sys_.feeding || !on) {
        const std::string problem = feeder_problem(p);
        if (!problem.empty()) return problem;
        if (sys_.feeding) return tr({"joins when you are on FEED", "parte appena sei su FEED"});
        return tr({"ready", "pronto"});
    }
    const bool running = p == Program::Fr24feed ? sys_.fr24_running
                         : p == Program::Pfclient ? sys_.pf_running
                                                  : sys_.rb_running;
    const int restarts = p == Program::Fr24feed ? sys_.fr24_restarts
                         : p == Program::Pfclient ? sys_.pf_restarts
                                                  : sys_.rb_restarts;
    if (!running && restarts > 0) return tr({"stopped: see the log (6)", "fermo: vedi il log (6)"});
    switch (p) {
        case Program::Fr24feed: {
            if (!sys_.fr24_fresh) return tr({"starting...", "avvio..."});
            const auto& f = sys_.fr24;
            if (!f.connected()) {
                std::string s = f.feed_status().empty() ? std::string(tr({"connecting...", "connessione..."}))
                                                        : f.feed_status();
                if (!f.feed_message().empty()) s += " " + f.feed_message();
                return s;
            }
            std::string s = f.radar_id().empty() ? std::string(tr({"connected", "connesso"})) : f.radar_id();
            if (!f.tracked().empty()) s += format_text(tr({", %s aircraft sent", ", %s aerei inviati"}), f.tracked().c_str());
            if (cfg_.mlat) s += f.mlat_ok() ? ", MLAT ok" : ", MLAT...";
            return s;
        }
        case Program::Pfclient: {
            if (!sys_.pf.present) return tr({"starting...", "avvio..."});
            if (sys_.pf.receiver_bytes_in <= 0) return tr({"waiting for data from readsb", "attesa dati da readsb"});
            if (sys_.pf.server_bytes_out <= 0) return tr({"connecting...", "connessione..."});
            return format_text(tr({"sending, %.0f kB sent", "invio, %.0f kB inviati"}), sys_.pf.server_bytes_out / 1024.0);
        }
        case Program::Rbfeeder: {
            const auto& rb = sys_.rb;
            if (rb.link == RbStatus::Link::Disconnected)
                return tr({"cannot reach AirNav, retrying", "AirNav non raggiungibile, riprovo"});
            if (rb.link != RbStatus::Link::Connected) return tr({"starting...", "avvio..."});
            std::string s = rb.station.empty() ? std::string(tr({"connected", "connesso"})) : rb.station;
            if (rb.packets_total >= 0) s += format_text(tr({", %lld packets sent", ", %lld pacchetti inviati"}), rb.packets_total);
            return s;
        }
    }
    return {};
}

std::string FeederViewModel::status_value(int row) const {
    switch (row) {
        case 0: return service_status(Program::Fr24feed);
        case 1: return service_status(Program::Pfclient);
        case 2: return service_status(Program::Rbfeeder);
        case 3: {
            if (!sys_.feeding) return tr({"off: starts with feeding", "spento: parte con l'invio"});
            if (!sys_.readsb_running) {
                if (sys_.readsb_restarts == 0) return tr({"starting...", "avvio..."});
                // readsb's own words, e.g. "sdrOpen() failed, exiting!" or
                // "no supported devices found": the dongle is missing or busy.
                return tr({"no RTL-SDR dongle (or in use)", "nessuna chiavetta RTL-SDR (o occupata)"});
            }
            if (!sys_.aircraft.present) return tr({"starting...", "avvio..."});
            return format_text(tr({"%d aircraft (%d with position)", "%d aerei (%d con posizione)"}),
                               sys_.aircraft.aircraft, sys_.aircraft.with_position);
        }
        case 4: return gps_text();
        default: return {};
    }
}

FeederViewModel::Tone FeederViewModel::status_tone(int row) const {
    if (row >= 0 && row < 3) {
        const Program p = row == 0 ? Program::Fr24feed : row == 1 ? Program::Pfclient : Program::Rbfeeder;
        if (!feeder_enabled(p)) return Tone::Off;
        const bool on = p == Program::Fr24feed ? sys_.fr24_on : p == Program::Pfclient ? sys_.pf_on : sys_.rb_on;
        if (!sys_.feeding || !on) return feeder_problem(p).empty() ? Tone::Neutral : Tone::Warn;
        const bool running = p == Program::Fr24feed ? sys_.fr24_running
                             : p == Program::Pfclient ? sys_.pf_running
                                                      : sys_.rb_running;
        const int restarts = p == Program::Fr24feed ? sys_.fr24_restarts
                             : p == Program::Pfclient ? sys_.pf_restarts
                                                      : sys_.rb_restarts;
        if (!running && restarts > 0) return Tone::Bad;
        switch (p) {
            case Program::Fr24feed: return sys_.fr24_fresh && sys_.fr24.connected() ? Tone::Good : Tone::Warn;
            case Program::Pfclient: return sys_.pf.present && sys_.pf.server_bytes_out > 0 ? Tone::Good : Tone::Warn;
            case Program::Rbfeeder:
                return sys_.rb.link == RbStatus::Link::Connected ? Tone::Good : Tone::Warn;
        }
    }
    if (row == 3) {
        if (!sys_.feeding) return Tone::Off;
        if (!sys_.readsb_running) return sys_.readsb_restarts > 0 ? Tone::Bad : Tone::Warn;
        return sys_.aircraft.present ? Tone::Good : Tone::Warn;
    }
    if (row == 4) {
        if (gps_status_.fix) return Tone::Good;
        return gps_status_.receiver || gps_status_.searching ? Tone::Warn : Tone::Off;
    }
    return Tone::Neutral;
}

std::string FeederViewModel::account_name(int row) const {
    switch (static_cast<AccountRow>(row)) {
        case AccountRow::HFr24: return "Flightradar24";
        case AccountRow::Fr24Key: return tr({"  Sharing key", "  Chiave"});
        case AccountRow::Fr24Email: return tr({"  E-mail", "  E-mail"});
        case AccountRow::HPf: return "Plane Finder";
        case AccountRow::PfCode: return tr({"  Share code", "  Share code"});
        case AccountRow::HRb: return "AirNav RadarBox";
        case AccountRow::RbKey: return tr({"  Sharing key", "  Chiave"});
        case AccountRow::Count: break;
    }
    return {};
}

std::string FeederViewModel::account_value(int row) const {
    // Header rows: is that feeder set, at a glance.
    const auto header = [&](Program p, bool set, const T& missing) -> std::string {
        if (!feeder_enabled(p)) return tr({"off", "spento"});
        return set ? tr({"ready", "pronto"}) : tr(missing);
    };
    switch (static_cast<AccountRow>(row)) {
        case AccountRow::HFr24:
            return header(Program::Fr24feed, valid_sharing_key(cfg_.sharing_key), {"key missing", "manca la chiave"});
        case AccountRow::Fr24Key:
            return valid_sharing_key(cfg_.sharing_key) ? masked_key() : tr({"set it (Enter)", "impostala (Invio)"});
        case AccountRow::Fr24Email:
            return cfg_.email.empty() ? tr({"for the signup only", "serve solo per registrarsi"}) : cfg_.email;
        case AccountRow::HPf:
            return header(Program::Pfclient, valid_pf_sharecode(cfg_.pf_sharecode),
                          {"share code missing", "manca lo share code"});
        case AccountRow::PfCode:
            return valid_pf_sharecode(cfg_.pf_sharecode) ? mask(cfg_.pf_sharecode, 4, 2)
                                                         : tr({"set it (Enter)", "impostalo (Invio)"});
        case AccountRow::HRb: return header(Program::Rbfeeder, true, {"", ""});
        case AccountRow::RbKey:
            if (valid_rb_key(cfg_.rb_key)) return mask(cfg_.rb_key, 4, 2);
            return tr({"automatic (Enter)", "automatica (Invio)"});
        case AccountRow::Count: break;
    }
    return {};
}

FeederViewModel::Tone FeederViewModel::account_tone(int row) const {
    switch (static_cast<AccountRow>(row)) {
        case AccountRow::HFr24:
            if (!cfg_.fr24_enabled) return Tone::Off;
            return valid_sharing_key(cfg_.sharing_key) ? Tone::Good : Tone::Warn;
        case AccountRow::HPf:
            if (!cfg_.pf_enabled) return Tone::Off;
            return valid_pf_sharecode(cfg_.pf_sharecode) ? Tone::Good : Tone::Warn;
        case AccountRow::HRb: return cfg_.rb_enabled ? Tone::Good : Tone::Off;
        default: return Tone::Neutral;
    }
}

std::string FeederViewModel::setup_name(int row) const {
    switch (static_cast<SetupRow>(row)) {
        case SetupRow::HFr24: return "Flightradar24";
        case SetupRow::Fr24:
        case SetupRow::Pf:
        case SetupRow::Rb: return tr({"  Feed", "  Invio dati"});
        case SetupRow::Mlat: return "  MLAT";
        case SetupRow::HPf: return "Plane Finder";
        case SetupRow::HRb: return "AirNav RadarBox";
        case SetupRow::HRx: return tr({"Receiver", "Ricevitore"});
        case SetupRow::Gain: return tr({"  Gain", "  Guadagno"});
        case SetupRow::Ppm: return tr({"  PPM correction", "  Correzione PPM"});
        case SetupRow::HPos: return tr({"Antenna", "Antenna"});
        case SetupRow::Location: return tr({"  Position", "  Posizione"});
        case SetupRow::Altitude: return tr({"  Altitude", "  Altitudine"});
        case SetupRow::HApp: return "App";
        case SetupRow::Programs: return tr({"  Update programs", "  Aggiorna programmi"});
        case SetupRow::Theme: return tr({"  Theme", "  Tema"});
        case SetupRow::Language: return tr({"  Language", "  Lingua"});
        case SetupRow::Log: return "  Log";
        case SetupRow::About: return tr({"  About", "  Informazioni"});
        case SetupRow::Count: break;
    }
    return {};
}

std::string FeederViewModel::setup_value(int row) const {
    const auto toggle = [&](bool on, Program p) {
        if (!on) return std::string(tr(kOff)) + "  < >";
        return std::string(tr(kOn)) + " (" + program_text(p) + ")";
    };
    switch (static_cast<SetupRow>(row)) {
        case SetupRow::Fr24: return toggle(cfg_.fr24_enabled, Program::Fr24feed);
        case SetupRow::Pf: return toggle(cfg_.pf_enabled, Program::Pfclient);
        case SetupRow::Rb: return toggle(cfg_.rb_enabled, Program::Rbfeeder);
        case SetupRow::Mlat: return (cfg_.mlat ? std::string(tr(kOn)) : std::string(tr(kOff))) + "  < >";
        case SetupRow::Gain:
            return (cfg_.gain == "auto" ? std::string("auto") : cfg_.gain + " dB") + "  < >";
        case SetupRow::Ppm: return std::to_string(cfg_.ppm) + "  < >";
        case SetupRow::Location: {
            if (!cfg_.has_location) return gps_status_.receiver ? tr({"waiting for GPS", "attesa GPS"}) : tr(kNotSet);
            const std::string coords = format_text("%.4f, %.4f", cfg_.lat, cfg_.lon);
            if (cfg_.location_label == "GPS") return "GPS " + coords;
            return coords;
        }
        case SetupRow::Altitude: {
            if (!cfg_.has_altitude)
                return gps_status_.receiver ? tr({"waiting for GPS", "attesa GPS"}) : tr(kNotSet);
            std::string s = format_text("%.0f m (%d ft)", std::round(feet_to_metres(cfg_.altitude_ft)),
                                        cfg_.altitude_ft);
            if (cfg_.location_label == "GPS" && gps_status_.altitude_m) s += " GPS";
            return s;
        }
        case SetupRow::Programs:
            if (sys_.installing) return tr({"downloading...", "download..."});
            return tr({"Enter", "Invio"});
        case SetupRow::Theme: return (is_dark_mode() ? std::string(tr({"dark", "scuro"})) : std::string(tr({"light", "chiaro"}))) + "  < >";
        case SetupRow::Language:
            if (language_ == "en") return "English  < >";
            if (language_ == "it") return "Italiano  < >";
            return std::string(tr({"system", "di sistema"})) + "  < >";
        case SetupRow::Log:
        case SetupRow::About: return tr({"Enter", "Invio"});
        default: break; // header rows
    }
    return {};
}

// --- theme --------------------------------------------------------------------

void FeederViewModel::load_ui_prefs() {
    const std::string path = ui_prefs_path();
    if (path.empty()) return;
    const auto kv = parse_ini(read_text_file(path));
    if (const auto it = kv.find("dark"); it != kv.end()) set_dark_mode(it->second != "no");
    if (const auto it = kv.find("lang"); it != kv.end() &&
        (it->second == "en" || it->second == "it" || it->second == "auto"))
        language_ = it->second;
}

void FeederViewModel::save_ui_prefs() const {
    const std::string path = ui_prefs_path();
    if (path.empty()) return;
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(path).parent_path(), ec);
    std::ofstream out(path, std::ios::trunc);
    out << "dark=" << (is_dark_mode() ? "yes" : "no") << "\n";
    out << "lang=" << language_ << "\n";
}

// The language picked in SETUP (or the system's) for every text, from now on.
void FeederViewModel::apply_language() {
    using toolkit::i18n::Lang;
    if (language_ == "en") toolkit::i18n::set_override(Lang::En);
    else if (language_ == "it") toolkit::i18n::set_override(Lang::It);
    else toolkit::i18n::set_override(std::nullopt);
    set_help_doc(toolkit::i18n::current() == Lang::It ? "docs/help/feeder.it.md" : "docs/help/feeder.md");
}

// --- NavBar -----------------------------------------------------------------

void FeederViewModel::nav_fill(int page, NavProvider::NavSlot out[5]) const {
    out[0] = {"#", true, true};
    switch (static_cast<Page>(page)) {
        case Page::Status:
            out[1] = {sys_.feeding ? kIconStop : kIconPlay, false, true};
            out[2] = {kIconLog, false, true};
            out[3] = {is_dark_mode() ? ::view::ICON_SUN : ::view::ICON_MOON, false, true};
            out[4] = {::view::ICON_SIGN_OUT, false, true};
            break;
        case Page::Account:
        case Page::Setup:
            out[1] = {::view::ICON_CARET_UP, false, true};
            out[2] = {::view::ICON_CARET_DOWN, false, true};
            out[3] = {::view::ICON_CHECK, false, true};
            out[4] = {kIconSave, false, true};
            break;
    }
}

void FeederViewModel::nav_activate(int page, int slot) {
    switch (static_cast<Page>(page)) {
        case Page::Status:
            if (slot == 1) toggle_feeding();
            else if (slot == 2) request_ = Request::ShowLog;
            else if (slot == 3) {
                toggle_dark_mode();
                save_ui_prefs();
                bump_nav_refresh();
            } else if (slot == 4) request_quit();
            break;
        case Page::Account:
        case Page::Setup:
            if (slot == 1) move_cursor(-1);
            else if (slot == 2) move_cursor(1);
            else if (slot == 3) activate();
            else if (slot == 4) save();
            break;
    }
}

const char* FeederViewModel::nav_page_name(int page) const {
    switch (static_cast<Page>(page)) {
        case Page::Status: return "FEED";
        case Page::Account: return tr({"KEYS", "CHIAVI"});
        case Page::Setup: return "SETUP";
    }
    return nullptr;
}

toolkit::i18n::Text FeederViewModel::nav_hint(int page, int slot) const {
    namespace h = toolkit::hints;
    const T kQuit{"Close ZeroAirFeeder: feeding stops with it", "Chiudi ZeroAirFeeder: l'invio si ferma con l'app",
                  "Ferme ZeroAirFeeder : l’envoi s’arrête avec l’app",
                  "Schließt ZeroAirFeeder: das Senden endet mit der App",
                  "Cierra ZeroAirFeeder: el envío se detiene con la app"};
    const T kSave{"Apply the changes to feeding now (they also apply when you go back to FEED)",
                  "Applica subito le modifiche all'invio (si applicano anche tornando a FEED)",
                  "Applique tout de suite les changements (aussi en revenant à FEED)",
                  "Übernimmt die Änderungen sofort (sonst beim Zurück zu FEED)",
                  "Aplica ya los cambios al envío (también al volver a FEED)"};
    switch (static_cast<Page>(page)) {
        case Page::Status:
            switch (slot) {
                case 1: return {"Start or stop feeding the services that are on (only while the app is open)",
                                "Avvia o ferma l'invio ai servizi attivi (solo ad app aperta)",
                                "Démarre ou arrête l’envoi aux services actifs (app ouverte seulement)",
                                "Startet oder stoppt das Senden an die aktiven Dienste (nur bei offener App)",
                                "Inicia o detiene el envío a los servicios activos (solo con la app abierta)"};
                case 2: return {"Show the last lines of readsb and the services' programs",
                                "Mostra le ultime righe di readsb e dei programmi dei servizi",
                                "Affiche les dernières lignes de readsb et des programmes des services",
                                "Zeigt die letzten Zeilen von readsb und den Programmen der Dienste",
                                "Muestra las últimas líneas de readsb y de los programas de los servicios"};
                case 3: return h::kTheme;
                case 4: return kQuit;
            }
            break;
        case Page::Account:
            switch (slot) {
                case 1: return h::kListUp;
                case 2: return h::kListDown;
                case 3: return {"Edit the selected field, or run the selected action",
                                "Modifica il campo selezionato, o esegui l'azione selezionata",
                                "Modifie le champ choisi, ou lance l’action choisie",
                                "Bearbeitet das gewählte Feld oder führt die Aktion aus",
                                "Edita el campo elegido, o ejecuta la acción elegida"};
                case 4: return kSave;
            }
            break;
        case Page::Setup:
            switch (slot) {
                case 1: return h::kSettingPrev;
                case 2: return h::kSettingNext;
                case 3: return h::kSettingChange;
                case 4: return kSave;
            }
            break;
    }
    return {};
}

} // namespace feeder
