/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <atomic>
#include <functional>
#include <string>
#include <sys/types.h>
#include <utility>
#include <vector>

namespace feeder {

// A child process whose stdout and stderr arrive merged on one descriptor.
// With `pty` the child gets a pseudo-terminal as its controlling terminal (so a
// program that reads /dev/tty, like fr24feed's signup wizard, can be answered)
// with local echo off; without it, a pipe and /dev/null as stdin.
class ChildProcess {
public:
    ChildProcess() = default;
    ~ChildProcess();
    ChildProcess(const ChildProcess&) = delete;
    ChildProcess& operator=(const ChildProcess&) = delete;

    using Env = std::vector<std::pair<std::string, std::string>>;

    // `env` is added to (or overrides) the app's environment for the child.
    // The child gets SIGTERM if the app dies, so nothing outlives it.
    bool start(const std::vector<std::string>& argv, bool pty, std::string* error = nullptr,
               const Env& env = {});

    pid_t pid() const { return pid_; }

    // Waits up to `timeout_ms` for output and appends it to `out`.
    // Returns >0 when bytes arrived, 0 on timeout, -1 once the output is closed.
    int read(std::string& out, int timeout_ms);

    // Types `line` and a newline (pty mode only).
    bool write_line(const std::string& line);

    // SIGTERM to the child's process group, SIGKILL after 2 s if needed.
    void terminate();

    // Reaps the child: its exit code, 128 + signal when killed, -1 if unknown.
    int wait();

    bool started() const { return pid_ > 0; }

private:
    pid_t pid_ = -1;
    int fd_ = -1;
    bool reaped_ = false;
    int status_ = -1;
};

struct CommandResult {
    int exit_code = -1;     // -1: could not start, 124: timed out, 130: cancelled
    std::string output;     // stdout + stderr, ANSI codes and CRs removed
    bool ok() const { return exit_code == 0; }
};

// Runs argv to completion (no pty), collecting its output. `on_output` (may be
// empty) sees each chunk as it comes, for a live log. `cancel` stops it.
CommandResult run_command(const std::vector<std::string>& argv, int timeout_s,
                          const std::atomic<bool>* cancel = nullptr,
                          const std::function<void(const std::string&)>& on_output = {},
                          const ChildProcess::Env& env = {});

} // namespace feeder
