/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#include "feeder_config.h"

#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <system_error>

namespace feeder {
namespace {

std::string trim(const std::string& s) {
    const auto first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, last - first + 1);
}

bool is_alnum_ascii(char c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

// strtod/strtol on the whole string, C locale semantics for '.'.
std::optional<double> to_double(const std::string& s) {
    if (s.empty()) return std::nullopt;
    char* end = nullptr;
    errno = 0;
    const double v = std::strtod(s.c_str(), &end);
    if (errno != 0 || end == s.c_str() || *end != '\0' || !std::isfinite(v)) return std::nullopt;
    return v;
}

std::optional<int> to_int(const std::string& s) {
    if (s.empty()) return std::nullopt;
    char* end = nullptr;
    errno = 0;
    const long v = std::strtol(s.c_str(), &end, 10);
    if (errno != 0 || end == s.c_str() || *end != '\0' || v < -1000000 || v > 1000000)
        return std::nullopt;
    return static_cast<int>(v);
}

bool one_line(const std::string& s) {
    return std::none_of(s.begin(), s.end(),
                        [](char c) { return c == '\n' || c == '\r' || c == '\0'; });
}

} // namespace

bool valid_sharing_key(const std::string& key) {
    return key.size() == 16 && std::all_of(key.begin(), key.end(), is_alnum_ascii);
}

bool valid_email(const std::string& email) {
    if (email.empty() || email.size() > 254) return false;
    for (const char c : email) {
        const auto u = static_cast<unsigned char>(c);
        if (u <= 0x20 || u >= 0x7f) return false; // no spaces, controls or non-ASCII
        if (c == '"' || c == '\'' || c == '\\' || c == '<' || c == '>' || c == ',' || c == ';')
            return false;
    }
    const auto at = email.find('@');
    if (at == std::string::npos || at == 0 || email.find('@', at + 1) != std::string::npos)
        return false;
    const std::string domain = email.substr(at + 1);
    const auto dot = domain.find('.');
    if (dot == std::string::npos || dot == 0 || domain.back() == '.') return false;
    if (domain.find("..") != std::string::npos) return false;
    return true;
}

bool valid_lat(double lat) { return std::isfinite(lat) && lat >= -90.0 && lat <= 90.0; }
bool valid_lon(double lon) { return std::isfinite(lon) && lon >= -180.0 && lon <= 180.0; }
bool valid_altitude_ft(int feet) { return feet >= -1500 && feet <= 30000; }
bool valid_ppm(int ppm) { return ppm >= -200 && ppm <= 200; }

bool valid_gain(const std::string& gain) {
    const auto& choices = gain_choices();
    return std::find(choices.begin(), choices.end(), gain) != choices.end();
}

bool valid_pf_sharecode(const std::string& code) {
    return code.size() >= 8 && code.size() <= 32 && std::all_of(code.begin(), code.end(), is_alnum_ascii);
}

bool valid_rb_key(const std::string& key) {
    return key.size() >= 16 && key.size() <= 64 && std::all_of(key.begin(), key.end(), is_alnum_ascii);
}

const std::vector<std::string>& gain_choices() {
    // readsb --help lists these for rtl-sdr devices (the R820T/R828D table).
    static const std::vector<std::string> kGains = {
        "auto", "0.0",  "0.9",  "1.4",  "2.7",  "3.7",  "7.7",  "8.7",  "12.5", "14.4",
        "15.7", "16.6", "19.7", "20.7", "22.9", "25.4", "28.0", "29.7", "32.8", "33.8",
        "36.4", "37.2", "38.6", "40.2", "42.1", "43.4", "43.9", "44.5", "48.0", "49.6", "58"};
    return kGains;
}

std::string normalize_key(const std::string& text) {
    std::string out;
    out.reserve(text.size());
    for (const char c : text) {
        if (c == ' ' || c == '\t' || c == '-' || c == '\r' || c == '\n') continue;
        out.push_back(c);
    }
    return out;
}

int metres_to_feet(double metres) {
    return static_cast<int>(std::lround(metres / 0.3048));
}

double feet_to_metres(int feet) { return feet * 0.3048; }

std::string format_coord(double value) {
    char buf[32];
    std::snprintf(buf, sizeof(buf), "%.6f", value);
    // snprintf follows LC_NUMERIC; the app never calls setlocale, but be safe.
    for (char* p = buf; *p; ++p)
        if (*p == ',') *p = '.';
    return buf;
}

std::map<std::string, std::string> parse_ini(const std::string& text) {
    std::map<std::string, std::string> out;
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        const std::string t = trim(line);
        if (t.empty() || t[0] == '#' || t[0] == ';' || t[0] == '[') continue;
        const auto eq = t.find('=');
        if (eq == std::string::npos || eq == 0) continue;
        const std::string key = trim(t.substr(0, eq));
        std::string value = trim(t.substr(eq + 1));
        if (value.size() >= 2 && value.front() == '"' && value.back() == '"')
            value = value.substr(1, value.size() - 2);
        out[key] = value;
    }
    return out;
}

std::string render_fr24feed_ini(const FeederConfig& cfg, const std::string& runtime_dir) {
    // The keys and quoting of the official package and the sdr-enthusiasts
    // container, plus where fr24feed keeps its files: nothing under /run,
    // /var or /dev/shm, so it runs without root (checked with fr24feed 1.0.57).
    const char* mlat = cfg.mlat ? "yes" : "no";
    std::string out;
    out += "receiver=\"beast-tcp\"\n";
    out += "fr24key=\"" + cfg.sharing_key + "\"\n";
    out += "host=\"127.0.0.1:30005\"\n";
    out += "bs=\"no\"\n";
    out += "raw=\"no\"\n";
    out += "logmode=\"0\"\n";
    out += "logpath=\"" + runtime_dir + "\"\n";
    out += std::string("mlat=\"") + mlat + "\"\n";
    out += std::string("mlat-without-gps=\"") + mlat + "\"\n";
    out += "monitor-file=\"" + runtime_dir + "/decoder.txt\"\n";
    out += "write-pid=\"" + runtime_dir + "/fr24feed.pid\"\n";
    return out;
}

std::string render_rbfeeder_ini(const FeederConfig& cfg, const std::string& runtime_dir) {
    // The keys of the official /etc/rbfeeder.ini and of the sdr-enthusiasts
    // container; checked with rbfeeder 1.0.17 run as a normal user with
    // --config (it only warns that it cannot remove /var/run/rbfeeder's pid).
    std::string out = "[client]\n";
    out += "network_mode=true\n";
    out += "log_file=" + runtime_dir + "/rbfeeder.log\n";
    out += "key=" + (valid_rb_key(cfg.rb_key) ? cfg.rb_key : std::string{}) + "\n";
    if (cfg.has_location && valid_lat(cfg.lat) && valid_lon(cfg.lon)) {
        out += "lat=" + format_coord(cfg.lat) + "\n";
        out += "lon=" + format_coord(cfg.lon) + "\n";
        // rbfeeder wants metres.
        if (cfg.has_altitude && valid_altitude_ft(cfg.altitude_ft))
            out += "alt=" + std::to_string(static_cast<int>(std::lround(feet_to_metres(cfg.altitude_ft)))) + "\n";
    }
    out += "use_gnss=false\n";
    out += "\n[network]\n";
    out += "mode=beast\n";
    out += "external_host=127.0.0.1\n";
    out += "external_port=30005\n";
    out += "\n[mlat]\n";
    out += "autostart_mlat=false\n";
    return out;
}

std::vector<std::string> pfclient_args(const FeederConfig& cfg, const std::string& runtime_dir) {
    // The options of the sdr-enthusiasts container (pfclient 5.3), each file
    // in our runtime directory: connection_type 1 = TCP, data_format 1 = Beast.
    std::vector<std::string> args = {
        "--connection_type=1",
        "--address=127.0.0.1",
        "--port=30005",
        "--data_format=1",
        "--sharecode=" + (valid_pf_sharecode(cfg.pf_sharecode) ? cfg.pf_sharecode : std::string{}),
    };
    if (cfg.has_location && valid_lat(cfg.lat) && valid_lon(cfg.lon)) {
        args.push_back("--lat=" + format_coord(cfg.lat));
        args.push_back("--lon=" + format_coord(cfg.lon));
    }
    args.push_back("--pid_file=" + runtime_dir + "/pfclient.pid");
    args.push_back("--config_path=" + runtime_dir + "/pfclient-config.json");
    args.push_back("--log_path=" + runtime_dir + "/pfclient-log");
    args.push_back("--web_port=" + std::to_string(kPfWebPort));
    return args;
}

std::vector<std::string> readsb_args(const FeederConfig& cfg, const std::string& json_dir) {
    // --device-type must come before the SDR options (readsb --help).
    std::vector<std::string> args = {
        "--device-type", "rtlsdr",
        "--gain", valid_gain(cfg.gain) ? cfg.gain : std::string("auto"),
    };
    if (cfg.ppm != 0 && valid_ppm(cfg.ppm)) {
        args.push_back("--ppm");
        args.push_back(std::to_string(cfg.ppm));
    }
    for (const char* a : {"--net", "--net-bind-address", "127.0.0.1", "--net-bo-port", "30005",
                          "--write-json"})
        args.emplace_back(a);
    args.push_back(json_dir);
    for (const char* a : {"--write-json-every", "1", "--quiet"}) args.emplace_back(a);
    if (cfg.has_location && valid_lat(cfg.lat) && valid_lon(cfg.lon)) {
        args.push_back("--lat");
        args.push_back(format_coord(cfg.lat));
        args.push_back("--lon");
        args.push_back(format_coord(cfg.lon));
    }
    return args;
}

std::string serialize_settings(const FeederConfig& cfg) {
    std::string out = "version=1\n";
    out += "sharing_key=" + cfg.sharing_key + "\n";
    out += "email=" + cfg.email + "\n";
    if (cfg.has_location) {
        out += "lat=" + format_coord(cfg.lat) + "\n";
        out += "lon=" + format_coord(cfg.lon) + "\n";
        out += "location_label=" + cfg.location_label + "\n";
    }
    if (cfg.has_altitude) out += "altitude_ft=" + std::to_string(cfg.altitude_ft) + "\n";
    out += std::string("mlat=") + (cfg.mlat ? "yes" : "no") + "\n";
    out += "gain=" + cfg.gain + "\n";
    out += "ppm=" + std::to_string(cfg.ppm) + "\n";
    out += std::string("fr24=") + (cfg.fr24_enabled ? "yes" : "no") + "\n";
    out += std::string("planefinder=") + (cfg.pf_enabled ? "yes" : "no") + "\n";
    out += "pf_sharecode=" + cfg.pf_sharecode + "\n";
    out += std::string("airnav=") + (cfg.rb_enabled ? "yes" : "no") + "\n";
    out += "rb_key=" + cfg.rb_key + "\n";
    return out;
}

FeederConfig parse_settings(const std::string& text) {
    FeederConfig cfg;
    const auto kv = parse_ini(text);
    const auto get = [&](const char* k) -> std::string {
        const auto it = kv.find(k);
        return it == kv.end() ? std::string{} : it->second;
    };
    if (const std::string key = normalize_key(get("sharing_key")); valid_sharing_key(key))
        cfg.sharing_key = key;
    if (const std::string email = get("email"); valid_email(email)) cfg.email = email;
    const auto lat = to_double(get("lat"));
    const auto lon = to_double(get("lon"));
    if (lat && lon && valid_lat(*lat) && valid_lon(*lon)) {
        cfg.has_location = true;
        cfg.lat = *lat;
        cfg.lon = *lon;
        cfg.location_label = get("location_label");
    }
    if (const auto alt = to_int(get("altitude_ft")); alt && valid_altitude_ft(*alt)) {
        cfg.has_altitude = true;
        cfg.altitude_ft = *alt;
    }
    cfg.mlat = get("mlat") == "yes";
    if (const std::string gain = get("gain"); valid_gain(gain)) cfg.gain = gain;
    if (const auto ppm = to_int(get("ppm")); ppm && valid_ppm(*ppm)) cfg.ppm = *ppm;
    cfg.fr24_enabled = get("fr24") != "no"; // on in files from before the FEEDS page
    cfg.pf_enabled = get("planefinder") == "yes";
    if (const std::string code = normalize_key(get("pf_sharecode")); valid_pf_sharecode(code))
        cfg.pf_sharecode = code;
    cfg.rb_enabled = get("airnav") == "yes";
    if (const std::string key = normalize_key(get("rb_key")); valid_rb_key(key)) cfg.rb_key = key;
    return cfg;
}

std::filesystem::path settings_path() {
    std::filesystem::path base;
    if (const char* xdg = std::getenv("XDG_CONFIG_HOME"); xdg && xdg[0] != '\0') {
        base = xdg;
    } else if (const char* home = std::getenv("HOME"); home && home[0] != '\0') {
        base = std::filesystem::path(home) / ".config";
    } else {
        return {};
    }
    return base / "zeroairfeeder" / "settings.ini";
}

std::optional<FeederConfig> load_settings(const std::filesystem::path& path) {
    if (path.empty()) return std::nullopt;
    std::error_code ec;
    if (!std::filesystem::exists(path, ec)) return std::nullopt;
    return parse_settings(read_text_file(path));
}

bool save_settings(const std::filesystem::path& path, const FeederConfig& cfg) {
    if (path.empty() || !one_line(cfg.email) || !one_line(cfg.location_label)) return false;
    std::error_code ec;
    std::filesystem::create_directories(path.parent_path(), ec);
    if (ec) return false;
    std::filesystem::path tmp = path;
    tmp += ".tmp";
    {
        std::ofstream out(tmp, std::ios::trunc);
        if (!out) return false;
        out << serialize_settings(cfg);
        out.flush();
        if (!out) {
            std::filesystem::remove(tmp, ec);
            return false;
        }
    }
    std::filesystem::rename(tmp, path, ec);
    if (ec) {
        std::filesystem::remove(tmp, ec);
        return false;
    }
    return true;
}

Field missing_for_feeding(const FeederConfig& cfg) {
    if (!cfg.fr24_enabled && !cfg.pf_enabled && !cfg.rb_enabled) return Field::NoService;
    if (cfg.fr24_enabled && !valid_sharing_key(cfg.sharing_key)) return Field::Key;
    if (cfg.pf_enabled && !valid_pf_sharecode(cfg.pf_sharecode)) return Field::PfShareCode;
    if (cfg.pf_enabled && !cfg.has_location) return Field::Location;
    return Field::None;
}

Field missing_for_signup(const FeederConfig& cfg) {
    if (!valid_email(cfg.email)) return Field::Email;
    if (!cfg.has_location) return Field::Location;
    if (!cfg.has_altitude) return Field::Altitude;
    return Field::None;
}

std::string read_text_file(const std::filesystem::path& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return {};
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

} // namespace feeder
