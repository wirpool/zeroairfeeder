/*
 * SPDX-FileCopyrightText: 2026 Wirpool
 *
 * SPDX-License-Identifier: MIT
 */

#pragma once

#include <deque>
#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace feeder {

// The answers for FR24's own ADS-B signup wizard (fr24feed --signup --adsb).
struct SignupAnswers {
    std::string email;
    double lat = 0.0;
    double lon = 0.0;
    int altitude_ft = 0;
    bool mlat = false;
    std::string beast_host = "127.0.0.1"; // our readsb Beast output
    int beast_port = 30005;
};

// Drives the official wizard the way a person would: it watches the wizard's
// output for each "Step x.y" prompt and returns the answer to type. Pure logic,
// no I/O, so the tests feed it the wizard's real prompt texts.
//
// A prompt is answered once its question is complete: the "$:" input marker
// has appeared after it, or the output went quiet (on_idle()). An unexpected
// question, a question asked over and over (a rejected value), a password
// prompt or "try again" stops the script with an error.
class SignupScript {
public:
    explicit SignupScript(SignupAnswers answers);

    // New wizard output. Returns the line to send (without the newline) when a
    // prompt is ready to be answered.
    std::optional<std::string> on_output(std::string_view chunk);
    // The wizard printed nothing for a while: answer a prompt that has no "$:".
    std::optional<std::string> on_idle();

    bool failed() const { return failed_; }
    const std::string& error() const { return error_; }

    // The cleaned output (ANSI codes and CRs removed), the last lines first out.
    const std::deque<std::string>& lines() const { return lines_; }
    // The last `n` non-empty lines, joined with `separator`.
    std::string tail(size_t n, const char* separator = " / ") const;

    // The sharing key printed by zeroairfeeder-ctl after the wizard
    // ("ZEROAIRFEEDER_KEY=<16 chars>"), or "" if not seen.
    const std::string& sharing_key() const { return key_; }

private:
    struct Rule {
        const char* token;   // text that identifies the question
        std::string answer;
        bool fails = false;  // answering it means the signup did not work
    };

    std::optional<std::string> try_answer(bool idle);
    void append_clean(std::string_view chunk);
    void fail(std::string message);

    SignupAnswers answers_;
    std::vector<Rule> rules_;
    std::map<std::string, int> asked_;
    std::string pending_;       // output since the last answer
    std::string partial_line_;  // for lines_
    std::deque<std::string> lines_;
    std::string key_;
    bool failed_ = false;
    std::string error_;
    bool in_escape_ = false;
    bool escape_csi_ = false;
};

// Removes ANSI escape sequences and carriage returns.
std::string strip_ansi(std::string_view text);

} // namespace feeder
