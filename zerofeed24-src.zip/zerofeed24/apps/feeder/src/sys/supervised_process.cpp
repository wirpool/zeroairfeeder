/*
 * SPDX-FileCopyrightText: 2026 ZeroFeed24 contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include "supervised_process.h"

#include "signup_script.h" // strip_ansi

#include <chrono>

namespace feeder {
namespace {
constexpr size_t kMaxLines = 150;
}

SupervisedProcess::SupervisedProcess(std::string name, int respawn_ms)
    : name_(std::move(name)), respawn_ms_(respawn_ms) {}

SupervisedProcess::~SupervisedProcess() { stop(); }

void SupervisedProcess::start(std::vector<std::string> argv, ChildProcess::Env env) {
    stop();
    wanted_ = true;
    restarts_ = 0;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        last_exit_line_.clear();
    }
    thread_ = std::thread([this, a = std::move(argv), e = std::move(env)]() mutable {
        loop(std::move(a), std::move(e));
    });
}

void SupervisedProcess::stop() {
    wanted_ = false;
    if (thread_.joinable()) thread_.join();
    running_ = false;
}

std::string SupervisedProcess::last_exit_line() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return last_exit_line_;
}

std::vector<std::string> SupervisedProcess::log_lines() const {
    std::lock_guard<std::mutex> lock(mutex_);
    std::vector<std::string> out;
    out.reserve(lines_.size());
    for (const auto& l : lines_) out.push_back(name_ + ": " + l);
    return out;
}

void SupervisedProcess::add_output(const std::string& chunk) {
    std::lock_guard<std::mutex> lock(mutex_);
    for (const char c : strip_ansi(chunk)) {
        if (c != '\n') {
            if (partial_.size() < 400) partial_.push_back(c);
            continue;
        }
        if (partial_.find_first_not_of(" \t") != std::string::npos) {
            lines_.push_back(partial_);
            if (lines_.size() > kMaxLines) lines_.pop_front();
        }
        partial_.clear();
    }
}

void SupervisedProcess::loop(std::vector<std::string> argv, ChildProcess::Env env) {
    using clock = std::chrono::steady_clock;
    bool first = true;
    while (wanted_) {
        if (!first) ++restarts_;
        first = false;
        {
            ChildProcess child;
            std::string error;
            if (child.start(argv, /*pty=*/false, &error, env)) {
                running_ = true;
                for (;;) {
                    std::string chunk;
                    const int r = child.read(chunk, 200);
                    if (r > 0) add_output(chunk);
                    if (r < 0) break;
                    if (!wanted_) {
                        child.terminate();
                        break;
                    }
                }
                const int code = child.wait();
                running_ = false;
                if (!wanted_) break;
                std::lock_guard<std::mutex> lock(mutex_);
                if (!partial_.empty()) {
                    lines_.push_back(partial_);
                    partial_.clear();
                }
                last_exit_line_ = lines_.empty() ? std::string{} : lines_.back();
                lines_.push_back("exited with code " + std::to_string(code));
                if (lines_.size() > kMaxLines) lines_.pop_front();
            } else {
                std::lock_guard<std::mutex> lock(mutex_);
                last_exit_line_ = "cannot start: " + error;
            }
        }
        // Wait before the next try, but leave at once when stopped.
        const auto until = clock::now() + std::chrono::milliseconds(respawn_ms_);
        while (wanted_ && clock::now() < until)
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

} // namespace feeder
